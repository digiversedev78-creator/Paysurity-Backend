# Goal Description

We are shifting into high gear. You have ordered a three-pronged autonomous execution strategy:
1. Scaffold the mathematical Jest Unit Tests for the Underwriting Engine.
2. Initialize the GCP Terraform Infrastructure scripts.
3. Synchronize the Master RTM artifact to legally bind the as-is project state.

I will orchestrate this using our proven **Multi-Agent Execution** paradigm. I will personally engineer the GCP Terraform infrastructure, while spinning up a dedicated Backend QA Subagent to rigorously test the Mastercard Risk Algorithm.

## User Review Required

> [!CAUTION]
> **Terraform Billing Impact:** The Terraform scripts I am about to scaffold will define enterprise-grade infrastructure (Cloud SQL PostgreSQL clusters, Cloud Run endpoints, and VPCs). While I am merely *writing* the scripts now (not applying them), you must be aware that when you eventually run `terraform apply`, it will incur real Google Cloud billing costs. 

## Open Questions

1. **GCP Project Details:** I am scaffolding the Terraform scripts now, but they require a generic GCP Project ID. Do you want me to use a placeholder like `paysurity-production-123`, or do you have the exact Google Cloud Project ID you want me to hardcode into `variables.tf`?

## Proposed Changes

### [Stream 1: GCP Infrastructure (Main Agent)]

#### [NEW] [terraform/main.tf](file:///D:/Projects/PaySurity-Mother%20Folder/terraform/main.tf)
- Architect the core Google Cloud Provider.
- Scaffold **Cloud SQL** (PostgreSQL) modules to host the Prisma databases for the Orchestrator and Underwriting engines.
- Scaffold **Cloud Run** modules to securely host the Next.js Storefront and NestJS backend APIs.

#### [NEW] [terraform/variables.tf](file:///D:/Projects/PaySurity-Mother%20Folder/terraform/variables.tf)
- Define strictly-typed infrastructure variables (Region, Project ID, Database Passwords) to ensure zero tech debt during deployment.

### [Stream 2: Automated QA (Subagent)]

#### [NEW] [apps/underwriting-engine/src/risk-scoring/risk-scoring.service.spec.ts](file:///D:/Projects/PaySurity-Mother%20Folder/apps/underwriting-engine/src/risk-scoring/risk-scoring.service.spec.ts)
- A dedicated Backend QA Subagent will be spawned to write rigorous Jest unit tests.
- It will mathematically verify that `RiskScoringService` correctly assigns `APPROVED` (Score <= 30), `FLAGGED_FOR_AUDIT` (31-70), and `REJECTED` (>70).

### [Stream 3: RTM True-State Sync (Main Agent)]

#### [MODIFY] [PaySurity_Master_RTM.md](file:///C:/Users/ullah/.gemini/antigravity/brain/f967ce18-5d30-42ce-ab22-8f4eaadfbbea/PaySurity_Master_RTM.md)
- Once the subagent and I finalize the code, I will meticulously update the Master RTM matrix to ensure absolute traceability of the newly completed GCP and QA modules.

## Verification Plan

### Automated Tests
- The subagent will run `pnpm run test` inside the Underwriting Engine to guarantee Exit Code 0.
- I will run `terraform init` and `terraform validate` to guarantee the infrastructure syntax is flawless.

### Manual Verification
- We will review the final `PaySurity_Master_RTM.md` to ensure the project roadmap matches reality.
