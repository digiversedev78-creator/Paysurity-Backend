# 100% Requirement Coverage-Build Roadmap 🚀

This roadmap defines the unambiguous, concrete steps required to bridge the gap from our current **94.6%** coverage to a pristine **100%** coverage-build state for the RideShare platform.

## Current State Analysis
Based on the `Requirements/requirements_status.md` and `walkthrough.md`, the platform is functionally complete from a backend, operational, and web frontend perspective. 

**The missing 5.4% consists entirely of 4 deferred Phase 16 Requirements:**
1. `REQ-16.1`: Native iOS/Android Rider Application
2. `REQ-16.2`: Native iOS/Android Driver Application
3. `REQ-16.3`: Biometric Auth Integration (FaceID/TouchID)
4. `REQ-16.4`: Native Offline Mode & Local Cache Synchronization

## 100% Coverage Action Plan

### Phase 1: Native App Scaffolding (React Native / Expo)
To execute rapidly and utilize the existing React knowledge base, we will scaffold the native applications using **Expo (React Native)**.
- **Action:** Initialize `apps/rider-app-native` and `apps/driver-app-native`.
- **Action:** Configure `app.json` for iOS/Android bundle identifiers.
- **Action:** Setup navigation routing (`expo-router`).

### Phase 2: Gateway Integration & State Management
The backend Gateway is already 100% complete and waiting for native clients. No backend engineering is required.
- **Action:** Implement Supabase SDK for JWT authentication and DB queries.
- **Action:** Bind `DriverSocketGateway` WebSocket connections for real-time dispatch and location tracking.
- **Action:** Integrate Stripe/FluidPay SDKs for native Apple Pay / Google Pay support.

### Phase 3: Hardware & Sensor Bindings (REQ-16.3 & REQ-16.4)
This phase addresses the complex native features that web apps cannot support natively.
- **Action:** Implement `expo-local-authentication` to satisfy **REQ-16.3 (Biometric Auth)**.
- **Action:** Implement `expo-location` with background location tracking permissions for the Driver App.
- **Action:** Implement SQLite (via `expo-sqlite` or WatermelonDB) to satisfy **REQ-16.4 (Offline Mode Queueing)**, ensuring dispatch actions sync when network connectivity is restored.

### Phase 4: Native E2E Test Coverage (Detox / Maestro)
To guarantee the exact same degree of confidence as the web apps, we must write E2E tests for the mobile binaries.
- **Action:** Install Detox or Maestro.
- **Action:** Write E2E flows proving Biometric Login, Ride Request, and Driver Accept via WebSocket.
- **Action:** Verify tests against iOS Simulator and Android Emulator.

### Phase 5: Automated Test Hardening
Closing the gaps in Frontend and Native unit testing.
- **Action:** Install `vitest` and `@testing-library/react` in `apps/rider-app` and `apps/admin-portal`.
- **Action:** Implement unit tests for core UI components and business logic.
- **Action:** Install `jest-expo` and `react-test-renderer` in native apps.
- **Action:** Implement unit tests for native hooks and screens.

### Phase 6: Google Cloud Deployment (Public Launch Prep)
To prepare the platform for public load and evaluation, we will deploy the Gateway to Google Cloud Run and verify the deployment.
- **Action:** Review and execute GCP infrastructure definitions (`cloud-run-gateway.yaml`, `oidc-wif.yaml`).
- **Action:** Build and Push the NestJS Gateway Docker image to Google Artifact Registry.
- **Action:** Deploy the image to Google Cloud Run.
- **Action:** Run database migrations against the provisioned Supabase instance.
- **Action:** Execute `tests/k6/load-test.js` and `tests/chaos/chaos-tests.yaml` against the live staging URL.
- **Action:** Run the Go/No-Go evaluator.

## User Review Required
> [!IMPORTANT]
> To reach 100% automated test coverage across all layers (Web, Native, Backend), we are adding unit testing suites to the frontend apps.
