# Truth-First Recovery — Implementation Plan

## Background

A full read of `Requirements/CANONICAL.md` and deep code research reveals serious discrepancies between what is claimed and what exists. This plan addresses them in 4 tasks — **no invented data, no green-washing**.

---

## Research Findings (Pre-Plan Verification)

### Finding 1 — Status Count Reality

| Status label | Count in CANONICAL.md |
|---|---|
| `DONE` | 51 |
| `NOT_STARTED` | 165 |
| `IN_PROGRESS` | 8 |
| `[LIVE]` (invalid per taxonomy) | 39 |
| Other / blank | ~3 (rows with truncated/missing status cell) |
| **Total tracked rows** | **~266** |

Claimed "125 DONE" in prior conversation was **incorrect**. Actual DONE = 51.

### Finding 2 — `[LIVE]` Is Not a Valid Status

The taxonomy (`Requirements/CANONICAL.md`, Status Taxonomy section) defines exactly 5 valid statuses:
`NOT_STARTED`, `IN_PROGRESS`, `READY_FOR_REVIEW`, `BLOCKED`, `DONE`.

`[LIVE]` is not one of them. 39 rows use it. It was applied during a prior swarm run.

### Finding 3 — GCP "Validation" Tests Are Callable-Only Checks

Inspecting `test_AEL_DSP_001.py` (representative sample) reveals:
```python
self.assertTrue(callable(getattr(self.manager, "create_load_board_view", None)))
```
These tests **verify methods exist**, not that they produce correct output against a real DB. They do **not** satisfy the DoD proof chain requirement: `DB row → API response → UI → audit log → automated test evidence`.

Test exceptions are swallowed:
```python
except (TypeError, ValueError, KeyError) as e:
    self.assertIsNotNone(str(e))  # passes even on error!
```

### Finding 4 — Datetime Timezone Drift: Confirmed Systemic

`grep datetime.now()` returned **289+ matches** in `.py` files. Zero results for `datetime.now(timezone.utc)` in the core implementation files. This means every datetime stored by the [LIVE] Python modules is **timezone-naive (local wall clock)**, which is:
- A data integrity risk across multi-timezone operations (logistics is cross-timezone by nature)
- A schema drift risk: PostgreSQL `TIMESTAMPTZ` columns will store UTC correctly, but Python-written `TIMESTAMP` (naive) values lack timezone context
- A potential DoD failure for financial and state machine requirements that depend on time correctness

### Finding 5 — TIER2 Partner Dossier Is a 29-Line Stub

`TIER2_PARTNER_DOSSIERS.md` has 4 partner entries with 3 bullet points each — no verification dates, no confidence scores, no official source URLs, no classification against the evidence class taxonomy defined in `AEL-INT-015`.

---

## User Review Required

> [!IMPORTANT]
> **Task 2 (Taxonomy Cleanup) requires a CANONICAL.md write.** The plan moves 39 `[LIVE]` rows to `READY_FOR_REVIEW` with a documented rationale note — not to `DONE`. This is the honest position: code + tests exist but the tests do not prove a real DB proof chain. You must confirm this is acceptable before I write to CANONICAL.md.

> [!WARNING]
> **Task 4 (Datetime Drift) cannot be auto-fixed in this sprint.** The drift is systemic (289+ call sites across 30+ files). Fixing it requires: (a) schema-level audit of all `TIMESTAMP` vs `TIMESTAMPTZ` columns in `schema_v5.sql`, (b) Python-level replacement with `datetime.now(timezone.utc)`, (c) re-running all affected tests. This plan documents the drift and marks affected DONE/LIVE items as **BLOCKED pending datetime fix** only where the requirement explicitly depends on time correctness (e.g., financial ledger, state machines, QuickPay timing, wait-time/attempt pay). I will NOT auto-BLOCK requirements where time is cosmetic (e.g., display timestamps). You must confirm this scoping approach.

---

## Proposed Changes

### Task 1 — Baseline Status Report

#### [NEW] BASELINE_STATUS_REPORT.md (project root)

A single source-of-truth status document with:
- Exact counts per valid status per milestone
- List of [LIVE] rows with disposition decision
- Known gaps and blockers
- Timestamp of last update

No claims beyond what the CANONICAL.md text actually contains.

---

### Task 2 — Taxonomy Cleanup (39 [LIVE] rows)

#### [MODIFY] [CANONICAL.md](file:///c:/Users/Detaimfc/Downloads/AEL%20Solutions/Requirements/CANONICAL.md)

**Decision matrix for each [LIVE] row:**

| Criteria | Assign to |
|---|---|
| Implementation `.py` file exists + test file exists + test is callable-only (no real DB proof chain) + no UI proof noted | `READY_FOR_REVIEW` |
| Implementation file exists but test file is missing entirely | `IN_PROGRESS` |
| Evidence notes reference GCP build ID but no DB query / UI evidence | `READY_FOR_REVIEW` |

**No [LIVE] rows qualify for `DONE`** based on current evidence because:
- Tests are callable-only checks (see Finding 3)
- No DB row → API → UI proof chain is documented in the evidence notes
- No UI screenshots or recordings are referenced

All 39 `[LIVE]` rows will be moved to `READY_FOR_REVIEW` with a standardized evidence note:

```
DoD Gap: Tests verify method existence only (callable-check pattern). 
Missing: real DB proof chain, UI screenshots, audit log correlation. 
Moved from [LIVE] to READY_FOR_REVIEW per taxonomy cleanup 2026-03-11.
```

The Req IDs to update (all 39 [LIVE] rows, identified by scan):

| Req ID | Current Label | Target |
|---|---|---|
| AEL-SCP-003 | [LIVE] | READY_FOR_REVIEW |
| AEL-TRC-003 | [LIVE] | READY_FOR_REVIEW |
| AEL-DSP-001 | [LIVE] | READY_FOR_REVIEW |
| AEL-DSP-002 | [LIVE] | READY_FOR_REVIEW |
| AEL-DSP-003 | [LIVE] | READY_FOR_REVIEW |
| AEL-DSP-004 | [LIVE] | READY_FOR_REVIEW |
| AEL-DSP-005 | [LIVE] | READY_FOR_REVIEW |
| AEL-DSP-006 (AI Dispatcher) | [LIVE] | READY_FOR_REVIEW |
| AEL-DRV-001 (Global Arch) | [LIVE] | READY_FOR_REVIEW |
| AEL-DRV-003 | [LIVE] | READY_FOR_REVIEW |
| AEL-DRV-004 | [LIVE] | READY_FOR_REVIEW |
| AEL-DRV-008 (both rows) | [LIVE] | READY_FOR_REVIEW |
| AEL-APP-001 | [LIVE] | READY_FOR_REVIEW |
| AEL-APP-002 | [LIVE] | READY_FOR_REVIEW |
| AEL-APP-003 | [LIVE] | READY_FOR_REVIEW |
| AEL-APP-004 | [LIVE] | READY_FOR_REVIEW |
| AEL-APP-005 | [LIVE] | READY_FOR_REVIEW |
| AEL-APP-006 | [LIVE] | READY_FOR_REVIEW |
| AEL-APP-007 | [LIVE] | READY_FOR_REVIEW |
| AEL-API-DRV-001 | [LIVE] | READY_FOR_REVIEW |
| AEL-API-DRV-002 | [LIVE] | READY_FOR_REVIEW |
| AEL-API-DRV-003 | [LIVE] | READY_FOR_REVIEW |
| AEL-MCH-002 | [LIVE] | READY_FOR_REVIEW |
| AEL-MCH-003 | [LIVE] | READY_FOR_REVIEW |
| AEL-MCH-004 | [LIVE] | READY_FOR_REVIEW |
| AEL-MCH-005 | [LIVE] | READY_FOR_REVIEW |
| AEL-MCH-006 | [LIVE] | READY_FOR_REVIEW |
| AEL-ORD-003 | [LIVE] | READY_FOR_REVIEW |
| AEL-FIN-001 | [LIVE] | READY_FOR_REVIEW |
| AEL-FIN-003 | [LIVE] | READY_FOR_REVIEW |
| AEL-FIN-004 | [LIVE] | READY_FOR_REVIEW |
| AEL-FIN-005 | [LIVE] | READY_FOR_REVIEW |
| AEL-FIN-006 | [LIVE] | READY_FOR_REVIEW |
| AEL-OPS-001 | [LIVE] | READY_FOR_REVIEW |
| AEL-OPS-002 | [LIVE] | READY_FOR_REVIEW |
| AEL-OPS-003 | [LIVE] | READY_FOR_REVIEW |
| AEL-OPS-004 | [LIVE] | READY_FOR_REVIEW |
| AEL-OPS-PLB-001 | [LIVE] | READY_FOR_REVIEW |

> [!NOTE]
> AEL-OPS-001 through AEL-OPS-004 and AEL-OPS-PLB-001 have malformed table rows in CANONICAL.md (missing some pipe-delimited columns). These will be normalized during the cleanup as well.

---

### Task 3 — M11 Partner Discovery Dossier

#### [NEW] [M11_PARTNER_DISCOVERY_DOSSIER.md](file:///c:/Users/Detaimfc/Downloads/AEL%20Solutions/Requirements/M11_PARTNER_DISCOVERY_DOSSIER.md)

Structured dossier implementing AEL-INT-015 through AEL-INT-019. For each of the 16 PCN partners plus the 5 framework requirements:

**Per-partner record includes:**
- Evidence class (from the 6-class taxonomy in CANONICAL.md)
- Official source URL(s) (publicly verifiable only)
- Verification date
- Confidence level
- What is publicly known
- What is `UNKNOWN_PRIVATE_PENDING_PARTNER_CONFIRMATION`
- What must be requested (contact path, materials needed)
- Safe-to-build posture (adapter shell readiness vs. discovery required)

**Initial evidence class assignments** (based on public knowledge, not invented specs):

| Partner | Evidence Class | Rationale |
|---|---|---|
| MNX Logistics | `private_api_after_onboarding` | No public EDI/API docs; requires carrier onboarding |
| DHL Global Forwarding | `private_api_after_onboarding` | Developer portal exists but requires business account |
| FedEx Freight | `tracking_api_only` | FedEx Developer platform is public for tracking; order creation requires contract |
| UPS Supply Chain | `tracking_api_only` | UPS Developer Kit is public for tracking; supply chain APIs require agreement |
| Ascent Global | `unverified` | No public developer portal confirmed |
| SEKO Logistics | `private_api_after_onboarding` | Partner portal exists; API access contract-gated |
| XPO Logistics | `private_api_after_onboarding` | XPO Connect requires registration |
| TForce Worldwide | `unverified` | Limited public API information confirmed |
| Estes Express Lines | `tracking_api_only` | Public tracking API documented; EDI 204 order creation contract-gated |
| Old Dominion | `tracking_api_only` | Public tracking available; order creation private |
| Saia LTL Freight | `tracking_api_only` | Public tracking; EDI order creation requires contract |
| Holland Regional | `unverified` | Holland is an XPO brand; integration path unclear |
| YRC Freight | `unverified` | YRC is Yellow brand; restructuring status unclear |
| Conway Freight | `unverified` | Conway is an XPO brand; integration path unclear |
| ABF Freight | `tracking_api_only` | Public tracking available at abf.com |
| R+L Carriers | `tracking_api_only` | R+L Connect has public tracking; order creation private |
| Quick Transportation | `unverified` | No public developer surface confirmed |

> [!CAUTION]
> All adapter `.py` files already in the repo (MNXEDIAdapter.py, DHLRESTAdapter.py, etc.) contain **invented endpoint specs** per AEL-INT-016. They must be clearly marked as adapter shells with no production credentials assumed. The dossier will document this explicitly.

**CANONICAL.md updates for M11:** AEL-INT-015 through AEL-INT-019 will be set to `IN_PROGRESS` (discovery work constitutes the linked issue + dependency scan per transition rules). PCN-001 through PCN-016 remain `NOT_STARTED` until discovery dossier is approved.

---

### Task 4 — Datetime Schema Drift Audit

#### [NEW] DATETIME_DRIFT_REPORT.md (project root)

Documents all datetime drift findings. No auto-fix will be applied (scope too large for this sprint).

**Drift scope (confirmed):**
- 289+ `datetime.now()` calls (timezone-naive) in core `.py` implementation files
- 0 uses of `datetime.now(timezone.utc)` in core files
- Risk level: **HIGH** for financial/state-machine/time-sensitive requirements
- Risk level: **MEDIUM** for display/reporting timestamps

**CANONICAL.md status changes for datetime-critical DONE rows:**

Requirements where time correctness is a DoD gate that cannot be met with naive datetimes:

| Req ID | Reason datetime matters | Action |
|---|---|---|
| AEL-STM-003 | Financial ledger immutability — timestamp ordering is the immutability guarantee | Flag in evidence notes: `DATETIME_DRIFT_RISK — verify TIMESTAMPTZ in schema` |
| AEL-ORD-001 | Physical status machine — physical custody timestamps must be timezone-correct | Flag in evidence notes |
| AEL-ORD-002 | Financial status machine — same | Flag in evidence notes |
| AEL-APP-008 | Wait time / attempt pay — billing computed from timestamps; naive datetimes risk incorrect billing | Flag in evidence notes |
| AEL-FIN-001 (READY_FOR_REVIEW after cleanup) | Ledger reconciliation depends on time-ordered matching | Flag in evidence notes |

These rows will **not** be moved to BLOCKED — they will have an honest flag added to their evidence notes so the next verifier knows what to check. Moving to BLOCKED requires a confirmed failure, not a risk flag.

**Schema check to perform:** Scan `schema_v5.sql` for `TIMESTAMP` vs `TIMESTAMPTZ` usage and include in the report.

---

## Verification Plan

### Task 1 & 4 — Document Generation
These produce `.md` files. Verify by reading the generated files and confirming:
- All counts match Select-String PowerShell queries on CANONICAL.md
- Drift findings match grep output

```powershell
# Verify DONE count
Select-String -Path "Requirements\CANONICAL.md" -Pattern "\| DONE \|" | Measure-Object | Select Count

# Verify datetime.now() scope
Select-String -Path "*.py" -Pattern "datetime.now()" -Recurse | Measure-Object | Select Count
```

### Task 2 — CANONICAL.md Taxonomy Cleanup
After editing CANONICAL.md:
```powershell
# Confirm [LIVE] count drops to 0
Select-String -Path "Requirements\CANONICAL.md" -Pattern "\[LIVE\]" | Measure-Object

# Confirm READY_FOR_REVIEW count increases by ~39
Select-String -Path "Requirements\CANONICAL.md" -Pattern "READY_FOR_REVIEW" | Measure-Object
```

### Task 3 — M11 Dossier
Manual review: Check that `Requirements/M11_PARTNER_DISCOVERY_DOSSIER.md` contains:
- One entry per partner (16 PCN + 5 framework reqs)
- No invented endpoint URLs (no fake `https://api.partner.com/v1/...` presented as confirmed)
- All unknown fields explicitly marked `UNKNOWN_PRIVATE_PENDING_PARTNER_CONFIRMATION`
- Evidence class for each partner

### Task 4 — Schema Drift Check
```powershell
# Check schema for TIMESTAMP vs TIMESTAMPTZ
Select-String -Path "schema_v5.sql" -Pattern "TIMESTAMP" | Select LineNumber, Line
```
