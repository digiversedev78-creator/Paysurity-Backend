# M4 Completion + M5 Driver Core Implementation Plan

## Background

- **M4 Sprint 1** (commit `f35cc09`) delivered: partner connector framework APIs, quarantine triage UI, partner catalog UI, and wired dispatch loadboard/orders/shipments to real DB.
- **M4 remaining**: AEL-DSP-006a (3D Load Consolidation Visual Interface) — the only `NOT_STARTED` item.
- **M5**: Driver Core + Driver App — 5 driver UI pages and 14 API routes already exist and are wired to real DB (no mock data). Backend Python services exist for all DRV/APP/API-DRV requirements. Most are `DONE` or `READY_FOR_REVIEW`.

## User Review Required

> [!IMPORTANT]
> **AEL-DSP-006a** (3D Load Consolidation) requires a WebGL/Three.js visualization. This is a significant UI effort. The plan below uses a CSS-based pseudo-3D approach that works without heavy 3D libraries. If you want actual Three.js/WebGL rendering, let me know and I'll adjust the approach (heavier dependency, more complex).

> [!IMPORTANT]
> **M5 scope**: Most Driver pages are already DB-wired. The work is primarily:
> 1. Creating missing pages (vehicle profile, preferences, standing)
> 2. Adding nav links to the dispatch sidebar for new M4 pages
> 3. Running the traceability validator to confirm compliance
> 4. TypeScript verification

---

## Proposed Changes

### M4 Completion — 3D Load Consolidation

#### [NEW] [page.tsx](file:///c:/Users/Detaimfc/Downloads/AEL%20Solutions/src/app/dispatch/consolidation/page.tsx)
- Visual 3D load consolidation interface (AEL-DSP-006a)
- CSS-based isometric 3D view showing load items in vehicle containers
- Interactive: click items to select, drag to reposition, color-coded by priority/type
- Stats panel showing space/weight utilization, center of gravity  
- Wired to `/api/dispatch/loads` for real load data
- Promote consolidated plan to dispatch

---

### M4 Navigation Integration

#### [MODIFY] [sidebar.tsx or layout.tsx](file:///c:/Users/Detaimfc/Downloads/AEL%20Solutions/src/app/dispatch/layout.tsx)
- Add nav links for: Quarantine Triage (`/dispatch/quarantine`), Partner Catalog (`/dispatch/partners`), Load Consolidation (`/dispatch/consolidation`)

---

### M5 Driver Core — Missing Pages

#### [NEW] [page.tsx](file:///c:/Users/Detaimfc/Downloads/AEL%20Solutions/src/app/driver/vehicle/page.tsx)
- Vehicle profile + capacity management (AEL-DRV-004)
- Form: vehicle class, dimensions, payload, certifications
- Wired to `/api/driver/onboarding` or new vehicle API

#### [NEW] [page.tsx](file:///c:/Users/Detaimfc/Downloads/AEL%20Solutions/src/app/driver/preferences/page.tsx)
- Driver preferences with strict/flexible flags (AEL-DRV-006)
- Day/night, out-of-hometown, home-by, destination-book controls
- Wired to driver profile API

#### [NEW] [page.tsx](file:///c:/Users/Detaimfc/Downloads/AEL%20Solutions/src/app/driver/standing/page.tsx)
- Driver standing + appeals (AEL-DRV-007)
- Shows current standing, history, appeal/unfreeze workflow
- Wired to driver stats API

#### [NEW] [route.ts](file:///c:/Users/Detaimfc/Downloads/AEL%20Solutions/src/app/api/driver/vehicle/route.ts)
- Vehicle profile CRUD API (AEL-DRV-004)

#### [NEW] [route.ts](file:///c:/Users/Detaimfc/Downloads/AEL%20Solutions/src/app/api/driver/preferences/route.ts)
- Driver preferences API (AEL-DRV-006)

---

### M5 Driver App Missing Features

#### [NEW] [page.tsx](file:///c:/Users/Detaimfc/Downloads/AEL%20Solutions/src/app/driver/voice/page.tsx)
- Voice assistant UI placeholder (AEL-APP-003)
- Tap-to-wake with command history

#### [NEW] [page.tsx](file:///c:/Users/Detaimfc/Downloads/AEL%20Solutions/src/app/driver/auto-accept/page.tsx)
- Auto-accept rules configuration (AEL-APP-004)
- Rule builder UI: rate minimum, distance, vehicle type
- Wired to new auto-accept API

---

### Database Migration

#### [NEW] [010_driver_vehicle_preferences.sql](file:///c:/Users/Detaimfc/Downloads/AEL%20Solutions/migrations/010_driver_vehicle_preferences.sql)
- `driver_vehicles` table (class, dimensions, payload, certs)
- `driver_preferences` table (strict/flex flags, day/night, home-by)
- `driver_auto_accept_rules` table

---

## Verification Plan

### Automated Tests

1. **TypeScript compilation** — must pass with 0 errors:
   ```
   cd "c:\Users\Detaimfc\Downloads\AEL Solutions"
   npx tsc --noEmit
   ```

2. **Traceability validation** — all new files must have `=== REQUIREMENT TRACEABILITY ===` markers:
   ```
   cd "c:\Users\Detaimfc\Downloads\AEL Solutions"
   python scripts/validate_traceability.py
   ```

3. **Existing unit tests** — must not regress:
   ```
   cd "c:\Users\Detaimfc\Downloads\AEL Solutions"
   npx vitest run --reporter=verbose
   ```

### Manual Verification
- Start dev server (`npm run dev` on port 3000)
- Navigate to `/dispatch/quarantine` — verify triage page renders
- Navigate to `/dispatch/partners` — verify catalog page renders
- Navigate to `/dispatch/consolidation` — verify 3D consolidation loads
- Navigate to `/dispatch/loadboard` — verify real DB data (not mock)
- Navigate to `/driver/vehicle` — verify vehicle form renders
- Navigate to `/driver/preferences` — verify preferences form renders
