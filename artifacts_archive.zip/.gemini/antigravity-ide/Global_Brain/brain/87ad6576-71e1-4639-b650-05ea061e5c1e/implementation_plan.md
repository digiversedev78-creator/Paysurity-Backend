# Repo Cleanup Plan

This plan outlines moving diagnostic logs, audit reports, and temporary files into a structured archive to declutter the repository root.

## Proposed Changes

### [Repository Organization]

#### [NEW] [diagnostics](file:///c:/Users/Detaimfc/Downloads/AmericanEagle/archive/diagnostics/)
- Create the `/archive/diagnostics/` directory.

#### [MOVE] Diagnostic & Backup Files/Folders
- Move all files and folders starting with `_` (e.g., `_CLOSE_PRS_BACKUP_*`, `_EBT_*`, `_tmp_*`) from the root to `archive/diagnostics/`.
- Move specific files: `AEL_FIXED.jsonl`, `BULK_CODE_FOR_AI.txt`, `Security_Leaks.txt`, `handshake.log`.

#### [MOVE] Audit Files
- Move all files matching `*_Audit.txt` (case-insensitive) and `FINAL_AUDIT_REPORT.txt` from the root to `archive/diagnostics/`.

## Verification Plan

### Manual Verification
- Run `ls` (or `list_dir`) in the root to ensure the files are gone.
- Run `ls archive/diagnostics/` to confirm all files were moved successfully.
