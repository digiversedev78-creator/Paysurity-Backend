# American Eagle Logistics (AEL) — As-Is State Report & Automated Build Plan

## 1. As-Is State: Bottom-Up Code Analysis

### What Exists (Confirmed via Direct File Inspection)

#### Infrastructure / DevOps
| File | Status | Notes |
|---|---|---|
| `Dockerfile` | ✅ Exists | Basic Cloud Run container setup |
| `cloudbuild.yaml` | ✅ Exists | Basic Cloud Build config — not wired to full CI |
| `.github/` (37 files) | ⚠️ Partial | Directory exists; workflows not functionally complete |
| `requirements.txt` | ✅ Exists | Python deps (minimal) |
| `package.json` (root) | ✅ Exists | Minimal root node config |

#### Database / SQL Layer
| File | Status | Notes |
|---|---|---|
| `schema_v1.sql` | ✅ Complete | `organizations`, `users`, `driver_profiles`, `vehicles`, `audit_logs`, `documents` + fraud risk ENUM + insurance-expiry trigger |
| `schema_v2.sql` | ✅ Exists | Incremental additions |
| `schema_v3.sql` | ✅ Complete | `financial_ledger`, `driver_settlements`, `shipper_invoices`, ENUMs for financial/settlement status, seed data for 2 Super Admins |
| `schema_v4_ledger.sql` | ✅ Exists | Ledger immutability additions |
| `sql_expansion_v4.sql` | ✅ Exists | Further expansions |
| PostGIS functions | ✅ Exists | `proximity_functions.sql`, `postgis_proximity.sql`, `calculate_dispatch_miles` in `api.js` |

> **Verdict:** Core schema is roughly 40% of what's needed. Missing: `orders` with physical/financial status machines, partner connectors table, QR code tracking, shipment stops, POL/POD records, pricing policy matrix, compliance tracker, notification logs, 3D packing results, driver preferences, home-by, destination book.

#### Backend Services
| File | Status | Notes |
|---|---|---|
| `api.js` | ✅ Working | PostGIS distance calc — the ONE fully working feature |
| `app.py` / `index.py` | ⚠️ Stub | Flask/FastAPI stubs, no real logic |
| `dispatch_assigner.py` | ⚠️ Stub | Placeholder |
| `settlement_calculator.py` | ⚠️ Stub | Placeholder |
| `order_ingest_api.py` | ⚠️ Stub | Placeholder |
| `user_auth_adapter.py` | ⚠️ Stub | No real auth |
| `public_gateway_adapter.py` | ⚠️ Stub | Placeholder |

#### Frontend (`src/frontend/`)
| Route | Status | Notes |
|---|---|---|
| `app/page.tsx` | ❌ Default | Stock Next.js "edit page.tsx" placeholder |
| `app/loadboard/page.tsx` | ⚠️ Demo | Hardcoded 3-row table; Patriot palette applied; no real data |
| `app/admin/` | ❌ Stub | Empty page.tsx |
| `app/dashboard/` | ❌ Stub | Empty page.tsx |
| `app/driver-portal/` | ❌ Stub | Empty page.tsx |
| `app/ledger/` | ❌ Stub | Empty page.tsx |
| `app/shipper-portal/` | ❌ Stub | Empty page.tsx |
| `components/Navbar.tsx` | ✅ Exists | Basic nav with Patriot palette |
| shadcn/ui | ❌ Missing | Not installed; `AEL-UI-001` mandates it |
| TanStack Table | ❌ Missing | Not installed |
| React Hook Form + Zod | ❌ Missing | Not installed |
| pnpm lockfile | ❌ Missing | `AEL-UI-003` requires pnpm; npm used instead |

#### Swarm Infrastructure (`ae-agent/`)
| Component | Status | Notes |
|---|---|---|
| `main.py` (orchestrator) | ✅ Exists | Basic Python orchestrator |
| `swarm_bus/MANIFEST.json` | ✅ Exists | 4 tickets, all COMPLETED |
| Workers 2–5 | ✅ Exist | `ai_instructions.json` per worker |

---

### Requirements Coverage Map (89 Req IDs)

| Module | Count | Done | Partial | Missing |
|---|---|---|---|---|
| AEL-CORE (Auth, Audit) | 4 | 0 | 1 (schema only) | 3 |
| AEL-WEB (Marketing, Blog, CTAs) | 3 | 0 | 0 | 3 |
| AEL-SHP (Shipper flows) | 5 | 0 | 0 | 5 |
| AEL-INT (Partner connectors) | 7 | 0 | 0 | 7 |
| AEL-DSP (Dispatch) | 5 | 0 | 1 (loadboard stub) | 4 |
| AEL-DRV (Driver onboarding) | 7 | 0 | 1 (schema only) | 6 |
| AEL-APP (Driver app) | 8 | 0 | 0 | 8 |
| AEL-MCH (Matching/packing) | 4 | 1 (PostGIS dist) | 0 | 3 |
| AEL-ORD (Order/status machine) | 5 | 0 | 1 (schema only) | 4 |
| AEL-FIN (Payout/ledger) | 3 | 0 | 1 (ledger schema) | 2 |
| AEL-PRC (Pricing matrix) | 1 | 0 | 0 | 1 |
| AEL-TST (Testing) | 3 | 0 | 0 | 3 |
| AEL-SEC / AEL-DAT / AEL-NOT | 4 | 0 | 0 | 4 |
| AEL-OPS / AEL-CMP / AEL-MKT / Other | 14 | 0 | 0 | 14 |
| **TOTAL** | **73 sampled** | **~2%** | **~6%** | **~92%** |

> **Bottom Line: ~2% DONE. ~6% structurally started (schema or stub only). ~92% Not Started.**

---

## 2. GCP 4-Workstation Automated Build Plan

The strategy is to run **4 parallel AI Workstations on GCP Cloud Run** — each is an autonomous agent instance (Antigravity) that owns a build module and writes code, runs tests, commits to Git, and reports status back via the shared swarm bus.

### Architecture: GCP-Powered Swarm

```
┌─────────────────────────────────────────┐
│         GCP PROJECT (AEL-BUILD)         │
│                                         │
│  ┌──────────────────────────────────┐   │
│  │     Cloud Run: Worker-1          │   │
│  │     ORCHESTRATOR / PM            │   │
│  │     - Reads MANIFEST             │   │
│  │     - Assigns tickets to W2-W5   │   │
│  │     - Monitors status bus        │   │
│  │     - Commits progress reports   │   │
│  └──────────────────────────────────┘   │
│                                         │
│  ┌──────────┐  ┌──────────┐            │
│  │Worker-2  │  │Worker-3  │            │
│  │BACKEND   │  │FRONTEND  │            │
│  │AEL-CORE  │  │AEL-WEB   │            │
│  │AEL-ORD   │  │AEL-DSP   │            │
│  │AEL-FIN   │  │AEL-APP   │            │
│  └──────────┘  └──────────┘            │
│  ┌──────────┐  ┌──────────┐            │
│  │Worker-4  │  │Worker-5  │            │
│  │INFRA/INT │  │QA/TESTS  │            │
│  │AEL-MCH   │  │AEL-TST   │            │
│  │AEL-INT   │  │AEL-SEC   │            │
│  │AEL-DEP   │  │AEL-OPS   │            │
│  └──────────┘  └──────────┘            │
│                                         │
│  Shared: Cloud SQL (PostgreSQL)         │
│  Shared: Cloud Storage (GCS)            │
│  Shared: Secret Manager                 │
│  Shared: Firestore (swarm_bus state)    │
│  Shared: Artifact Registry (images)     │
└─────────────────────────────────────────┘
         ↕ GitHub (via GH Actions)
    Main Repo: PaySurity-Biz/American-Eagle
```

### Workstation Assignments

#### Worker-1 (Orchestrator — always running)
- Reads `ae-agent/swarm_bus/MANIFEST.json`
- Assigns tickets to Workers 2–5 via Firestore
- Monitors worker heartbeat and status
- Opens GitHub Issues + PRs per ticket
- Generates evidence-based progress reports (AEL-TST-003)
- Triggers re-runs if a worker stalls

#### Worker-2 — Backend Core
**Owns:** `AEL-CORE`, `AEL-ORD`, `AEL-FIN`, `AEL-PRC`, `AEL-SEC`

Tickets:
- `T-010` Full schema migration (orders state machines, pricing policy, notification logs)
- `T-011` Auth service (JWT/RBAC, MFA, Super Admin bootstrap)
- `T-012` Physical + Financial status machines (API layer)
- `T-013` QuickPay rules engine
- `T-014` Pricing policy matrix API
- `T-015` Immutable financial ledger + reconciliation endpoint
- `T-016` GCS signed-URL service (POL/POD/driver docs)
- `T-017` PII governance + retention policies

#### Worker-3 — Frontend
**Owns:** `AEL-WEB`, `AEL-DSP`, `AEL-APP`, `AEL-SHP`, `AEL-UI`

Tickets:
- `T-020` Install shadcn/ui, TanStack Table, RHF+Zod, pnpm migration
- `T-021` Public marketing homepage (SEO, CTAs, blog slot)
- `T-022` Shipper portal (booking wizard, shipment tracking timeline)
- `T-023` Dispatch dashboard (map, loadboard with filters, quarantine triage)
- `T-024` Driver portal (loadboard, offers, POL/POD upload, earnings)
- `T-025` Admin panel (user management, compliance tracker, test runner)
- `T-026` QR code landing page + routing (shipper vs driver branch)

#### Worker-4 — Infrastructure & Integrations
**Owns:** `AEL-INT`, `AEL-MCH`, `AEL-DEP`, `AEL-NOT`

Tickets:
- `T-030` Partner connector framework (email parser, SFTP, EDI, voice stub)
- `T-031` Canonical Tender normalization + idempotency
- `T-032` 3D packing solver heuristic
- `T-033` Driver matching engine (vehicle fit, equipment tags, standing, priority branded)
- `T-034` Notification policy engine (push, email, quiet hours, escalation)
- `T-035` GitHub Actions CI/CD (PR gate, staging deploy, prod deploy, progress report)
- `T-036` Cloud Run service definitions (staging + prod environments)

#### Worker-5 — QA, Ops & Compliance
**Owns:** `AEL-TST`, `AEL-OPS`, `AEL-CMP`, `AEL-REL`

Tickets:
- `T-040` Unit test suite (auth, pricing, status machines, matching)
- `T-041` Integration tests (end-to-end booking + dispatch + POD flow)
- `T-042` Load tests (stress test dispatch, notifications)
- `T-043` Operational exception playbooks (no-show, damage, breakdown, wrong address)
- `T-044` Broker compliance tracker (USDOT, MC, BOC-3, BMC-84)
- `T-045` TSA/IAC air cargo compliance tracker
- `T-046` Traceability matrix (`traceability.csv` + `validate-traceability.js`)
- `T-047` `ghost_hunter.py` module (per CANONICAL.md requirement)

---

## 3. GCP Setup Steps (Using Your Credits)

### Step 1 — GCP Project & IAM (One-Time)
```bash
gcloud projects create ael-build-swarm --name="AEL Build Swarm"
gcloud config set project ael-build-swarm
gcloud services enable \
  run.googleapis.com \
  sqladmin.googleapis.com \
  storage.googleapis.com \
  secretmanager.googleapis.com \
  cloudbuild.googleapis.com \
  artifactregistry.googleapis.com \
  firestore.googleapis.com
```

### Step 2 — Swarm Bus (Firestore)
Use Firestore (Native mode) as the live status bus replacing the flat MANIFEST.json file. Workers read/write their ticket status here. Zero-config, zero cost at low scale.

### Step 3 — Worker Container
Each worker is a Docker container running the Antigravity agent with:
- GitHub token (to commit code)
- GCP Service Account key (to access Cloud SQL, GCS, Secret Manager)
- Worker identity env var (`WORKER_ID=worker-2`)
- Ticket assignment from Firestore

```yaml
# Example Cloud Run service for Worker-2
service: ael-worker-2
image: gcr.io/ael-build-swarm/ael-worker:latest
env:
  WORKER_ID: worker-2
  MANIFEST_SOURCE: firestore
  GITHUB_REPO: PaySurity-Biz/American-Eagle
memory: 2Gi
cpu: 2
min-instances: 1
max-instances: 1
```

### Step 4 — Cost Estimate (GCP Credits)
| Resource | Est. Monthly Cost | Notes |
|---|---|---|
| Cloud Run (4 workers, 2 CPU, 2GB, 1 instance each) | ~$80–$120 | Always-on during build sprint |
| Cloud SQL (PostgreSQL, db-f1-micro) | ~$25 | Shared dev instance |
| Cloud Storage | ~$1–$3 | POL/POD + schema files |
| Secret Manager | ~$1 | Secrets storage |
| Firestore | ~$0 | Free tier covers swarm bus |
| **Total** | **~$110–$150/mo** | Well within typical GCP credit grants |

---

## 4. Phase Roadmap (Weeks)

| Week | Focus | Target Req IDs | Workers |
|---|---|---|---|
| 1 | Foundation: Schema + Auth + pnpm + shadcn setup | AEL-CORE, AEL-UI-001/002/003, AEL-ADM-001/002 | W2, W3 |
| 2 | Order + Pricing + Shipper Portal | AEL-ORD, AEL-PRC, AEL-SHP | W2, W3 |
| 3 | Dispatch + Driver + Matching | AEL-DSP, AEL-DRV, AEL-MCH, AEL-APP | W2, W3, W4 |
| 4 | Connectors + Ledger + Notifications | AEL-INT, AEL-FIN, AEL-NOT | W2, W4 |
| 5 | QA + Tests + Compliance + DevOps | AEL-TST, AEL-OPS, AEL-CMP, AEL-DEP | W4, W5 |
| 6 | Polish + Traceability + Evidence + Production Deploy | AEL-REL, AEL-REQ-TRC, AEL-DOD-002 | All |

---

## 5. MANIFEST.json v2 — Full Ticket Backlog

The file `ae-agent/swarm_bus/MANIFEST.json` must be replaced with the full backlog of ~38 tickets above (T-010 through T-047), each with:
- `TicketID`, `Worker`, `Task`, `Module`, `ReqIDs`, `Status: NOT_STARTED`

Worker-1 (Orchestrator) will iterate through this list, dispatch to workers, and update statuses.

---

## 6. Definition of Done Gate

A ticket is only marked `DONE` when:
1. Code is merged via PR to `main`
2. CI passes (unit + integration tests)
3. `traceability.csv` updated with PR + CI run ID
4. Staging URL confirmed working (smoke test passes)
5. Audit logs present for any state mutations

> [!IMPORTANT]
> No worker may mark a ticket DONE based on narration alone. Evidence links are mandatory per `AEL-DOD-002` and `AEL-TST-003`.
