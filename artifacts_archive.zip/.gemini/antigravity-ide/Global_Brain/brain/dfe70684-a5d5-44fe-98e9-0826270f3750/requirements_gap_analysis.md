# 🔍 Requirements Gap Analysis — v1.1.0 vs. Canonical Requirements

**Analysis Date:** 2026-03-13T19:46 CST
**Scope:** All 3 Reqs Splits (19 requirement documents, 4,000 total requirements)
**Baseline:** PS-Platform v1.1.0-PRODUCTION (22 modules, 20 migrations)

---

## Executive Summary

> [!CAUTION]
> **The current implementation covers approximately 8–12% of the 4,000 canonical requirements.** The platform has solid foundational infrastructure (auth, events, payments, orders, loyalty, tax, settlements, wallets) but is missing the vast majority of the detailed functional, non-functional, and compliance requirements specified in the canonical requirement set.

| Metric | Value |
|---|---|
| **Total Requirements** | **4,000** |
| **MUST Priority** | **2,978** (74.5%) |
| **SHOULD Priority** | **242** (6.1%) |
| **COULD Priority** | **771** (19.3%) |
| **Modules Implemented** | 22 |
| **Estimated Reqs Covered** | ~320–480 (8–12%) |
| **Estimated Gap** | **~3,520–3,680 requirements** |

---

## Per-Document Gap Analysis

### SPLIT 1

---

#### 01_FOUNDATION_ADM.md — Foundational Platform & Admin
**Requirements:** 2,314 (1,440 Must / 165 Should / 709 Could)

This is the largest document and covers the entire platform foundation. It spans 27 sub-domains:

| Sub-Domain | Reqs (est.) | Implemented? | Coverage | Gap Detail |
|---|---|---|---|---|
| **Go-live triggers** | ~20 | ⚠️ Partial | ~40% | `LaunchService` handles activation but missing `merchant.go_live_at` field, trigger rules |
| **Job Runner & Idempotency** | ~40 | ⚠️ Partial | ~30% | BullMQ + DLQ exists but no idempotent job scheduler, no re-entry guard (PSR-V6-00596) |
| **AI Features** | ~50 | ⚠️ Partial | ~25% | `ps-ai.js` NLP exists, `ai-feedback` logging exists, but no AI blog ingestion/generation/publishing, no social automation |
| **Accessibility** | ~30 | ❌ Missing | 0% | No WCAG 2.1 AA compliance, no screen reader support, no keyboard navigation testing |
| **Admin Console** | ~300 | ❌ Missing | ~5% | No admin UI. Missing: user management dashboard, tenant administration, configuration UI, job run dashboard, provenance logging |
| **Audit & Logging** | ~150 | ⚠️ Partial | ~25% | `AuditInterceptor` + `security_events` table exist. Missing: audit log viewer, log retention policies, tamper-proof storage, full CRUD audit, PII masking in logs |
| **Feature Management & Configuration** | ~80 | ❌ Missing | ~5% | No feature flag system, no A/B testing, no gradual rollout, no tenant-level config overrides UI |
| **Files & Documents** | ~60 | ❌ Missing | 0% | No file upload service, no document management, no invoice PDF generation pipeline, no S3/GCS integration |
| **Identity & Access** | ~120 | ⚠️ Partial | ~20% | JWT auth exists, `JwtAuthGuard` functional. Missing: RBAC with granular permissions, OAuth2/OIDC, SSO, MFA/2FA, password policy, session management, user self-service |
| **Internationalization (i18n)** | ~40 | ❌ Missing | 0% | No i18n framework, no translation system, no locale-aware formatting |
| **Miscellaneous** | ~200 | ❌ Unknown | <5% | Mixed requirements that need individual classification |
| **Notifications & Messaging** | ~100 | ⚠️ Partial | ~15% | `NotificationService.send()` exists. Missing: email templates, SMS provider integration, push notifications, notification preferences, delivery tracking, in-app notifications |
| **Observability & Health** | ~80 | ⚠️ Partial | ~30% | Health endpoint exists, drift monitor exists. Missing: Prometheus/Grafana metrics, distributed tracing (OpenTelemetry), structured logging dashboard, SLA monitoring |
| **Quality & CI/CD** | ~60 | ❌ Missing | ~5% | No CI pipeline manifests, no automated E2E tests, no deployment automation, no staging environments |
| **Reporting & Data Platform** | ~100 | ⚠️ Partial | ~20% | `AnalyticsService` + `AggregatorService` exist. Missing: custom report builder, data export (CSV/PDF), scheduled reports, data warehouse ETL |
| **Tenancy & Accounts** | ~120 | ⚠️ Partial | ~15% | Multi-tenant schema exists (`tenants` table, RLS). Missing: tenant provisioning workflow, plan/billing management, account hierarchy, white-labeling engine |
| **Training & Support** | ~40 | ❌ Missing | 0% | No help center, no knowledge base, no onboarding wizard, no in-app guides |
| **Re-homed from AFR** | ~100 | ❌ Missing | 0% | Affiliate/reseller requirements not implemented |
| **Re-homed from ONB** | ~200+ | ⚠️ Partial | ~10% | Various onboarding requirements partially covered by `LaunchService` |
| **Addenda (templates, wallet config, AI blog, social)** | ~50+ | ❌ Missing | <5% | Statement templates, wallet policy feature flags, AI blog pipeline all missing |

**Gap: ~2,000+ requirements**

---

#### 15_SECURITY_PRIVACY.md — Security & Privacy
**Requirements:** 23 (23 Must / 0 Should / 0 Could)

| Sub-Domain | Reqs | Implemented? | Coverage |
|---|---|---|---|
| Security admin surfaces | ~5 | ❌ Missing | 0% — No security dashboard UI |
| Security event logging | ~4 | ✅ Done | ~80% — `security_events` table + `BANK_ACCOUNT_CHANGED` + DLQ logging |
| API protections | ~4 | ⚠️ Partial | ~50% — JWT guards exist, missing rate limiting per-endpoint, API key management |
| Operational diagnostics | ~3 | ✅ Done | ~70% — Health check exists |
| API inventory & change control | ~2 | ❌ Missing | 0% — No API versioning strategy, no change control process |
| Secure uploads | ~2 | ❌ Missing | 0% — No file upload security |
| Secrets & key management | ~2 | ⚠️ Partial | ~30% — `.env` based, no Vault/KMS integration |
| Remote POS support controls | ~3 | ❌ Missing | 0% |
| Build security gates | ~3 | ❌ Missing | 0% — No SAST/DAST in CI |

**Gap: ~15 requirements**

---

#### 16_COMPLIANCE_LEGAL.md — Compliance & Legal
**Requirements:** 166 (154 Must / 9 Should / 3 Could)

| Sub-Domain | Reqs | Implemented? | Coverage |
|---|---|---|---|
| Policies & governance | ~20 | ❌ Missing | 0% — No policy management system |
| Control frameworks | ~15 | ❌ Missing | 0% — No SOX/SOC control mapping |
| Rules engine | ~25 | ❌ Missing | 0% — No compliance rules engine |
| Financial compliance (BSA/AML) | ~20 | ❌ Missing | 0% — No AML screening, no SAR filing |
| PCI program & evidence | ~25 | ⚠️ Partial | ~20% — PAN redaction exists, PCI audit archive exists. Missing: SAQ workflows, evidence collection automation |
| SOC 2 readiness | ~15 | ❌ Missing | 0% — No SOC 2 evidence automation |
| Secrets & encryption | ~10 | ⚠️ Partial | ~20% — `sanitizeGatewayResponse` exists |
| Audit trails | ~15 | ⚠️ Partial | ~30% — `AuditInterceptor` + `security_events` exists |
| Evidence collection | ~10 | ⚠️ Partial | ~15% — PCI archive service exists |
| Documents & records | ~5 | ❌ Missing | 0% |
| Legal operations | ~5 | ❌ Missing | 0% |
| Reporting & exports | ~10 | ❌ Missing | 0% |
| Dashboards | ~10 | ❌ Missing | 0% |

**Gap: ~140 requirements**

---

#### 17_MOBILE.md — Mobile
**Requirements:** 14 (14 Must / 0 Should / 0 Could)

| Area | Status | Gap |
|---|---|---|
| Native iOS app | ❌ Missing | No React Native / Swift project |
| Native Android app | ❌ Missing | No Kotlin / Flutter project |
| Mobile POS mode | ❌ Missing | No mobile-optimized POS |
| Push notifications | ❌ Missing | No Firebase/APNs integration |
| Biometric auth | ❌ Missing | No TouchID/FaceID |
| Offline mode | ❌ Missing | No local storage sync |

**Gap: 14 requirements (all 14)**

---

#### 20_DEFERRED_VERTICALS.md — Deferred Verticals
**Requirements:** 5 (3 Must / 0 Should / 2 Could)

Explicitly deferred to Phase 2+. **No action required.**

---

#### 90_CROSSCUTTING_INVARIANTS.md — Crosscutting Invariants
**Requirements:** 17 (11 Must / 5 Should / 1 Could)

| Invariant | Implemented? | Coverage |
|---|---|---|
| Multi-tenant isolation | ✅ Done | ~70% — RLS on all tables |
| Idempotency keys | ✅ Done | ~60% — On payments, settlements, refunds |
| ISO 20022 compliance | ✅ Done | ~50% — Cents-based, PostalAddress24 |
| Audit logging on mutations | ⚠️ Partial | ~40% — AuditInterceptor global but not all mutations tracked |
| PAN redaction | ✅ Done | ~80% — Global middleware |
| Trace ID propagation | ✅ Done | ~70% — TraceIdMiddleware |
| Model B provider fidelity | ✅ Done | ~60% — VIRTUAL_SETTLEMENT_SHADOW |

**Gap: ~6 requirements**

---

### SPLIT 2

---

#### 02_UI_DESIGN_SYSTEM.md — UI Design System
**Requirements:** 10 (1 Must / 4 Should / 5 Could)

| Area | Status | Coverage |
|---|---|---|
| Multi-merchant SaaS theming | ⚠️ Partial | ~30% — 4 brand palettes exist but no dynamic theme engine |
| White-label engine | ❌ Missing | 0% — Hardcoded brand colors, no tenant CSS customization |
| Design system components | ⚠️ Partial | ~20% — Microsites use inline CSS, no component library (Storybook) |
| Branding consistency testing | ❌ Missing | 0% |

**Gap: ~7 requirements**

---

#### 03_PUBLIC_WEBSITE_COM.md — Public Website & Marketing
**Requirements:** 92 (81 Must / 6 Should / 5 Could)

| Section | Reqs | Status | Coverage |
|---|---|---|---|
| PaySurity.com main site | ~25 | ❌ Missing | 0% — No marketing website |
| Vertical hub pages | ~15 | ❌ Missing | 0% — No /restaurant, /retail, /grocery landing pages |
| AI blog ingestion/generation | ~10 | ❌ Missing | 0% — No blog CMS |
| Social automation | ~8 | ❌ Missing | 0% |
| QR attribution | ~5 | ❌ Missing | 0% |
| SEO optimization | ~10 | ❌ Missing | 0% |
| Contact/demo forms | ~8 | ❌ Missing | 0% — `LaunchService.signup` exists as API but no web form |
| Pricing page | ~5 | ❌ Missing | 0% |
| Trust badges / testimonials | ~6 | ❌ Missing | 0% |

**Gap: ~88 requirements**

---

#### 04_MERCHANT_SERVICES_MER.md — Merchant Services & Portal
**Requirements:** 169 (157 Must / 9 Should / 3 Could)

| Section | Reqs | Status | Coverage |
|---|---|---|---|
| Merchant dashboard UI | ~40 | ❌ Missing | ~5% — `dashboard-live.html` is admin-only, not per-merchant |
| Merchant profile management | ~15 | ⚠️ Partial | ~20% — Basic CRUD exists, no self-service portal |
| Statement generation | ~15 | ❌ Missing | 0% |
| Dispute management | ~15 | ❌ Missing | 0% |
| Fee schedule configuration | ~10 | ❌ Missing | 0% |
| Deposit/funding management | ~10 | ❌ Missing | 0% |
| Merchant communications | ~10 | ❌ Missing | 0% |
| Merchant API keys | ~10 | ❌ Missing | 0% |
| Chargeback workflow | ~15 | ❌ Missing | 0% |
| Equipment management | ~10 | ❌ Missing | 0% |
| Sub-merchant management | ~10 | ❌ Missing | 0% |
| Reporting & analytics (per-merchant) | ~10 | ⚠️ Partial | ~15% — AnalyticsService exists but no per-merchant views |

**Gap: ~155 requirements**

---

#### 05_MERCHANT_ONBOARDING_ONB.md — Merchant Onboarding
**Requirements:** 42 (20 Must / 11 Should / 12 Could)

| Section | Reqs | Status | Coverage |
|---|---|---|---|
| Onboarding wizard | ~10 | ❌ Missing | 0% — No multi-step signup flow |
| KYB/KYC verification | ~8 | ❌ Missing | 0% — No identity verification |
| Underwriting | ~5 | ❌ Missing | 0% |
| Document collection | ~5 | ❌ Missing | 0% |
| Pre-approval screener | ~4 | ❌ Missing | 0% |
| Vertical auto-detection | ~5 | ⚠️ Partial | ~20% — Industry field exists but no auto-routing |
| POS module selection | ~5 | ❌ Missing | 0% |

**Gap: ~38 requirements**

---

#### 06_MERCHANT_SAVINGS_ESTIMATOR_SAV.md — Savings Estimator
**Requirements:** 40 (22 Must / 6 Should / 12 Could)

| Area | Status | Gap |
|---|---|---|
| Savings calculator widget | ❌ Missing | No competitive rate comparison tool |
| Fee comparison engine | ❌ Missing | No integration with competitor pricing |
| ROI projector | ❌ Missing | No business case generator |
| Lead capture integration | ❌ Missing | Not connected to signup flow |

**Gap: 40 requirements (all 40)**

---

#### 07_AFFILIATES_RESELLERS_REFERRALS_AFR.md — Affiliates, Resellers & Referrals
**Requirements:** 97 (92 Must / 2 Should / 3 Could)

| Area | Status | Gap |
|---|---|---|
| Affiliate program | ❌ Missing | No affiliate tracking, no commission engine |
| Reseller portal | ❌ Missing | No white-label reseller management |
| Referral tracking | ❌ Missing | No referral codes, no attribution |
| Commission calculations | ❌ Missing | No payout logic for affiliates |
| Partner dashboard | ❌ Missing | No partner-specific analytics |

**Gap: 97 requirements (all 97)**

---

### SPLIT 3

---

#### 08_PAYMENT_ORCHESTRATION_ORC.md — Payment Orchestration
**Requirements:** 100 (97 Must / 4 Should / 0 Could)

| Section | Reqs | Status | Coverage |
|---|---|---|---|
| Provider abstraction & routing | ~15 | ⚠️ Partial | ~20% — Single gateway simulation, no multi-provider routing |
| Core transaction lifecycle | ~20 | ⚠️ Partial | ~30% — `createPaymentIntent` + `refundPayment` exist but missing: authorize, capture, void, increment |
| Token vault & PCI boundary | ~10 | ⚠️ Partial | ~20% — `sanitizeGatewayResponse` exists but no token vault service |
| Webhooks & eventing | ~10 | ⚠️ Partial | ~40% — EventBus exists but no inbound webhook receiver from gateway |
| Reconciliation & disputes | ~10 | ⚠️ Partial | ~25% — Drift monitor exists but no dispute management |
| API surface | ~10 | ⚠️ Partial | ~20% — Basic endpoints exist |
| Logging & traceability | ~10 | ⚠️ Partial | ~40% — TraceId, AuditInterceptor |
| Testing | ~5 | ❌ Missing | 0% — No ORC integration tests |
| ORC adapter contract | ~10 | ❌ Missing | 0% — No `IProviderAdapter` interface with FluidPay implementation |

**Gap: ~70 requirements**

---

#### 09_ECOMMERCE_ECO.md — E-Commerce
**Requirements:** 129 (117 Must / 5 Should / 7 Could)

| Section | Reqs | Status | Coverage |
|---|---|---|---|
| Catalog & inventory | ~25 | ⚠️ Partial | ~15% — Inventory alerts exist, no catalog management |
| Checkout & orders | ~25 | ⚠️ Partial | ~20% — OrderService exists but no checkout flow |
| Shipping & fulfillment | ~15 | ❌ Missing | 0% |
| Storefront & admin | ~15 | ⚠️ Partial | ~10% — Microsites exist but no storefront admin |
| Procurement & POs | ~10 | ❌ Missing | 0% |
| PaySurity Checkout widget | ~15 | ❌ Missing | 0% — No embeddable checkout |
| Cart widget | ~10 | ⚠️ Partial | ~15% — Microsites have "Add to Cart" but client-side only |
| Shopify/WooCommerce plugins | ~15 | ❌ Missing | 0% |

**Gap: ~110 requirements**

---

#### 10_POS_RETAIL_POS.md — POS Retail
**Requirements:** 305 (303 Must / 2 Should / 0 Could)

| Section | Reqs | Status | Coverage |
|---|---|---|---|
| Core POS | ~60 | ⚠️ Partial | ~15% — POS HTML register views exist, missing: tender types, cash drawer, receipt printing |
| Devices & peripherals | ~40 | ❌ Missing | 0% — No printer, scanner, scale, pin pad integration |
| Inventory (deep) | ~50 | ⚠️ Partial | ~10% — Basic alerts exist, missing: purchase orders, vendor management, COGS tracking, stock transfers |
| Offline & sync | ~30 | ❌ Missing | 0% — No offline capability |
| Orders & workflow | ~40 | ⚠️ Partial | ~15% — Basic order creation exists |
| Staffing & time | ~30 | ⚠️ Partial | ~10% — Employee roles exist but no time clock, scheduling |
| Tax (deep POS) | ~20 | ⚠️ Partial | ~30% — 50-state tax tables exist |
| Device fleet management | ~15 | ❌ Missing | 0% |
| Retail vertical profiles | ~10 | ❌ Missing | 0% |
| Hardware kits + tap-to-phone | ~10 | ❌ Missing | 0% |

**Gap: ~270 requirements**

---

#### 11_POS_RESTAURANT_POSR.md — POS Restaurant
**Requirements:** 65 (56 Must / 4 Should / 2 Could)

| Section | Reqs | Status | Coverage |
|---|---|---|---|
| Table management | ~15 | ⚠️ Partial | ~10% — Table map UI exists in POS view, no server-side table state |
| KDS (Kitchen Display) | ~10 | ⚠️ Partial | ~15% — KDS status updates in OrderService, no dedicated KDS view |
| Menu management | ~10 | ⚠️ Partial | ~15% — Menu data in microsites, no admin CRUD |
| Course firing | ~5 | ❌ Missing | 0% |
| Split checks | ~5 | ⚠️ Stub | ~5% — UI button exists, no backend logic |
| QR ordering | ~5 | ⚠️ Partial | ~20% — QR scan simulation exists |
| Reservations | ~5 | ❌ Missing | 0% |
| Server sections | ~5 | ❌ Missing | 0% |
| Modifiers/customization | ~5 | ❌ Missing | 0% |

**Gap: ~55 requirements**

---

#### 12_POS_GROCERY_POSG.md — POS Grocery
**Requirements:** 67 (59 Must / 4 Should / 1 Could)

| Section | Reqs | Status | Coverage |
|---|---|---|---|
| Weighed items / PLU | ~10 | ❌ Missing | 0% |
| Bottle deposit / CRV | ~5 | ❌ Missing | 0% |
| Age verification (tobacco, alcohol) | ~5 | ⚠️ Partial | ~20% — UI prompt exists, no real verification |
| EBT/SNAP/WIC support | ~10 | ❌ Missing | 0% |
| Deli/bakery departments | ~5 | ❌ Missing | 0% |
| Store layout mapping | ~5 | ❌ Missing | 0% |
| Batch scanning | ~5 | ⚠️ Stub | ~5% — Barcode scanner UI exists, no backend |
| Grocery-specific promotions | ~10 | ❌ Missing | 0% |
| Recall management | ~5 | ❌ Missing | 0% |
| Vendor/DSD receiving | ~7 | ❌ Missing | 0% |

**Gap: ~62 requirements**

---

#### 13_DIGITAL_WALLETS_WAL.md — Digital Wallets
**Requirements:** 203 (190 Must / 8 Should / 5 Could)

| Section | Reqs | Status | Coverage |
|---|---|---|---|
| Core wallet platform | ~30 | ⚠️ Partial | ~20% — `WalletService` + `addOrUpdateAsset` + `getWallet` exist |
| Employer-employee wallets | ~25 | ❌ Missing | 0% |
| Identity & compliance (KYC/AML) | ~20 | ❌ Missing | 0% |
| Parent-child wallets | ~20 | ❌ Missing | 0% |
| Funding & sources | ~20 | ❌ Missing | 0% — No ACH/debit funding |
| Transfers & P2P | ~20 | ❌ Missing | 0% |
| Cards (virtual/physical) | ~20 | ❌ Missing | 0% — No card issuance |
| Cash-out | ~15 | ❌ Missing | 0% |
| Payouts | ~15 | ⚠️ Partial | ~15% — `schedulePayout` exists |
| Economics/monetization | ~15 | ❌ Missing | 0% |

**Gap: ~180 requirements**

---

#### 14_PAYROLL_PAY.md — Payroll
**Requirements:** 145 (139 Must / 4 Should / 3 Could)

| Section | Reqs | Status | Coverage |
|---|---|---|---|
| Deductions & benefits | ~25 | ❌ Missing | 0% — No 401k, health, garnishments |
| Payments & ACH | ~20 | ⚠️ Partial | ~15% — `createPayrollRun` + `approveAndSubmit` exist |
| Payroll runs & admin | ~30 | ⚠️ Partial | ~10% — Basic run creation, no full lifecycle |
| Payroll taxes & reporting | ~30 | ❌ Missing | 0% — No W-2, no 1099, no federal/state withholding |
| Time & attendance | ~25 | ❌ Missing | 0% — No time clock, no scheduling, no overtime |
| Phase 1 filing decision gate | ~15 | ❌ Missing | 0% |

**Gap: ~130 requirements**

---

## Gap Heatmap

```
Document                           Total   Gap    Coverage   Priority
─────────────────────────────────  ─────   ─────  ────────   ────────
01_FOUNDATION_ADM                  2,314   ~2,000  ~14%       🟥 CRITICAL
02_UI_DESIGN_SYSTEM                   10      ~7   ~30%       🟨 MEDIUM
03_PUBLIC_WEBSITE_COM                 92     ~88    ~4%       🟥 CRITICAL
04_MERCHANT_SERVICES_MER             169    ~155    ~8%       🟥 CRITICAL
05_MERCHANT_ONBOARDING_ONB            42     ~38    ~10%      🟥 CRITICAL
06_MERCHANT_SAVINGS_ESTIMATOR         40     ~40    ~0%       🟧 HIGH
07_AFFILIATES_RESELLERS_AFR           97     ~97    ~0%       🟧 HIGH
08_PAYMENT_ORCHESTRATION_ORC         100     ~70    ~30%      🟥 CRITICAL
09_ECOMMERCE_ECO                     129    ~110    ~15%      🟥 CRITICAL
10_POS_RETAIL_POS                    305    ~270    ~11%      🟥 CRITICAL
11_POS_RESTAURANT_POSR                65     ~55    ~15%      🟥 CRITICAL
12_POS_GROCERY_POSG                   67     ~62    ~7%       🟧 HIGH
13_DIGITAL_WALLETS_WAL               203    ~180    ~11%      🟥 CRITICAL
14_PAYROLL_PAY                       145    ~130    ~10%      🟥 CRITICAL
15_SECURITY_PRIVACY                   23     ~15    ~35%      🟧 HIGH
16_COMPLIANCE_LEGAL                  166    ~140    ~16%      🟥 CRITICAL
17_MOBILE                             14     ~14    ~0%       🟧 HIGH
20_DEFERRED_VERTICALS                  5       0   DEFERRED   ⬜ N/A
90_CROSSCUTTING_INVARIANTS            17      ~6    ~65%      🟨 MEDIUM
                                   ─────   ─────
TOTAL                              4,000   ~3,477   ~13%
```

---

## Prioritized Implementation Plan

### 🟥 Q1 — CRITICAL (Revenue-Blocking)

These must be addressed first — they are the core product features:

| # | Workstream | Reqs | Key Deliverables |
|---|---|---|---|
| 1 | **Payment Orchestration (ORC)** | ~70 | `IProviderAdapter` interface, FluidPay adapter, authorize/capture/void lifecycle, token vault, inbound webhook receiver, multi-provider routing |
| 2 | **Merchant Portal (MER)** | ~155 | Merchant dashboard SPA, profile self-service, statement generation, dispute management, fee schedules, API key management |
| 3 | **Public Website (COM)** | ~88 | PaySurity.com marketing site, vertical hubs, pricing page, demo request form, blog CMS, SEO |
| 4 | **E-Commerce (ECO)** | ~110 | Catalog admin, checkout workflow, shipping integration, PaySurity Checkout widget, Shopify/WooCommerce plugins |
| 5 | **POS Retail Deep (POS)** | ~270 | Cash drawer, receipt printing, peripheral integration, inventory deep (POs, vendors, COGS), offline mode, staffing/time clock |
| 6 | **POS Restaurant Deep (POSR)** | ~55 | Table state management, KDS dedicated view, course firing, split check backend, modifiers, reservations |
| 7 | **Digital Wallets Full (WAL)** | ~180 | Funding sources, P2P transfers, virtual/physical cards, parent-child wallets, employer wallets, KYC/AML, cash-out |
| 8 | **Payroll Complete (PAY)** | ~130 | Deductions/benefits, tax withholding (W-2, 1099), time clock, scheduling, ACH disbursements, filing |
| 9 | **Compliance & Legal (COM)** | ~140 | Rules engine, SOC 2 evidence, PCI SAQ workflows, BSA/AML screening, policy management, legal ops |
| 10 | **Foundation Admin (ADM)** | ~500 | Admin console SPA, tenant management, RBAC with permissions, feature flags, file/document management, notification templates |
| 11 | **Onboarding (ONB)** | ~38 | Multi-step wizard, KYB/KYC integration, underwriting, document collection, vertical auto-routing |

**Estimated Effort:** 12–16 sprints (24–32 weeks)

---

### 🟧 Q2 — HIGH (Market Differentiation)

| # | Workstream | Reqs | Key Deliverables |
|---|---|---|---|
| 12 | **Foundation ADM (remainder)** | ~1,500 | Full admin platform: audit viewer, job scheduler, observability, CI/CD, i18n, training/support |
| 13 | **POS Grocery Deep (POSG)** | ~62 | PLU/weighed items, EBT/SNAP, bottle deposit, deli departments, vendor DSD |
| 14 | **Savings Estimator (SAV)** | ~40 | Competitive rate calculator, ROI projector, lead capture |
| 15 | **Affiliates/Resellers (AFR)** | ~97 | Affiliate tracking, commission engine, reseller portal, referral codes, partner dashboard |
| 16 | **Security Admin (SEC)** | ~15 | Security dashboard, API inventory, key management (Vault/KMS), SAST/DAST gates |
| 17 | **Mobile Apps (MOB)** | ~14 | React Native / Flutter app, mobile POS, biometric auth, push notifications, offline sync |

**Estimated Effort:** 8–12 sprints (16–24 weeks)

---

### 🟨 Q3 — MEDIUM (Polish & Scale)

| # | Workstream | Reqs | Key Deliverables |
|---|---|---|---|
| 18 | **UI Design System** | ~7 | Component library (Storybook), dynamic theming engine, accessibility testing |
| 19 | **Crosscutting Invariants** | ~6 | Full audit logging coverage, enhanced idempotency, distributed tracing |
| 20 | **Foundation remainders** | variable | Internationalization, accessibility (WCAG 2.1 AA), training portal |

**Estimated Effort:** 4–6 sprints (8–12 weeks)

---

## What IS Covered (Strengths)

> [!NOTE]
> While the gap is large, the existing implementation provides a solid architectural foundation:

| Strength | Details |
|---|---|
| ✅ **Multi-tenant architecture** | RLS on 30+ tables, tenant isolation |
| ✅ **Event-driven backbone** | BullMQ + EventBusService + DLQ consumers |
| ✅ **Security fundamentals** | PAN redaction middleware, sanitizeGatewayResponse, JWT auth |
| ✅ **ISO 20022 compliance** | Cents-based, PostalAddress24, structured addresses |
| ✅ **50-state tax engine** | Full US tax coverage with exemptions |
| ✅ **Multi-currency** | 20 FX pairs, cross-border settlement |
| ✅ **Employee permission matrix** | 6 roles × 15 permissions |
| ✅ **Settlement pipeline** | Batch creation, automatic payouts |
| ✅ **Loyalty system** | Points earn/redeem with wallet integration |
| ✅ **Self-healing infrastructure** | DLQ with 3-retry escalation, drift monitor |
| ✅ **Pen test / PCI audit** | 12-point pen test, PAN stress test, load test |
| ✅ **Merchant demo sites** | 4 high-fidelity microsites + POS registers |
| ✅ **AI assistant** | NLP-based ordering assistant with feedback logging |
| ✅ **Production dashboard** | Real-time TPV, health, drift monitoring |

---

## Recommended Next Steps

1. **Prioritize MUST requirements** — 2,978 of the 4,000 are MUST priority. Focus exclusively on these first.
2. **Build the ORC adapter contract** — This is the foundation for all payment flows. Without `IProviderAdapter` and a real FluidPay adapter, the entire payment stack is simulated.
3. **Merchant Portal SPA** — Without a self-service merchant dashboard, the platform cannot onboard real merchants.
4. **Admin Console** — The 2,314 ADM requirements indicate the admin platform is the largest single deliverable.
5. **Don't attempt all 4,000 at once** — Decompose into the Q1/Q2/Q3 priority waves above.

> [!IMPORTANT]
> **The current v1.1.0 build is an excellent technical proof-of-concept with strong architectural patterns.** However, it covers approximately 13% of the canonical 4,000 requirements. The gap analysis above provides a roadmap to systematically close the remaining ~3,477 requirements across 20 prioritized workstreams.
