# PaySurity Platform — Master Architecture & Execution Plan
## Lead Architect Evaluation + TDD-First Swarm Strategy

> **Date:** 2026-03-14 05:40 CDT  
> **Project:** paysurity-platform-2026  
> **GitHub:** americaneaglelogsvc/PS-Platform---Copy  
> **Evaluator Hats:** Lead Architect, Full Stack Dev, DBA, Reporting Analyst, Compliance Officer

---

## 1. GCP INFRASTRUCTURE AUDIT — AS-IS

> [!CAUTION]
> **NO runtime infrastructure exists.** The GCP project has APIs enabled but zero deployed resources.

| Resource | Status | What's Needed |
|---|---|---|
| **Cloud SQL (PostgreSQL)** | ❌ NONE | Need DEV + STAGING instances |
| **Cloud Run (API + Frontend)** | ❌ NONE | Need services for API, dashboard, public site |
| **GKE Clusters** | ❌ NONE | Not needed Phase 1 (Cloud Run sufficient) |
| **Artifact Registry** | ❌ NONE | Need Docker image repo |
| **Secret Manager** | 1 secret (GitHub token) | Need DB creds, JWT secret, gateway keys |
| **Cloud Build Worker Pool** | ✅ RUNNING | `paysurity-worker-pool` in us-central1 |
| **Enabled APIs** | ✅ 39 APIs | All necessary APIs already enabled |
| **GitHub Repo** | ✅ Synced | `americaneaglelogsvc/PS-Platform---Copy` |

### Infrastructure We Must Create (In Order)

```
Phase 0: Foundation Infrastructure (must exist before ANY testing)
  ├── Cloud SQL (PostgreSQL 16) — dev instance
  ├── Artifact Registry — Docker repo
  ├── Secret Manager — all secrets
  └── Cloud Build trigger (GitHub → build on push)

Phase 1: Staging Environment
  ├── Cloud SQL — staging instance  
  ├── Cloud Run — API service (staging)
  ├── Cloud Run — merchant-dashboard (staging)
  └── Cloud Run — public-website (staging)

Phase 2: Production (after all gates pass)
  ├── Cloud SQL — prod instance (HA)
  ├── Cloud Run — all services (prod, min 2 instances)
  ├── Cloud Armor — WAF
  ├── Cloud CDN — static assets
  └── Monitoring + Alerting
```

---

## 2. CANONICAL REQUIREMENTS INVENTORY

Source: `Requirements/Canonical/` — 31 active docs, 310+ requirements, 25 actors

### Requirements by Domain (from canonical index)

| Domain | File | Req Count | Priority | Dependencies |
|---|---|---|---|---|
| **Payment Orchestration** | ORC | 12 | P0 | Foundation |
| **Merchant Services** | MER | 11 | P0 | ORC |
| **POS Restaurant** | POSR | 10 | P1 | ORC, PAY |
| **POS Grocery** | POSG | 14 | P1 | ORC, PAY, COM |
| **POS Retail** | POS | 9 | P1 | ORC, ECO |
| **E-Commerce** | ECO | 8 | P1 | ORC, POS |
| **Payroll** | PAY | 9 | P1 | ORC (ACH), COM |
| **Digital Wallets** | WAL | 8 | P1 | ORC, PAY, COM |
| **Loyalty Engine** | LOY | 7 | P2 | POS, WAL |
| **Tax Engine** | TAX | 6 | P1 | ORC |
| **Subscription Billing** | SUB | 6 | P2 | ORC |
| **Compliance & Legal** | COM | 12 | P0 | Foundation |
| **Security & Privacy** | SEC | 10 | P0 | Foundation |
| **AI Experience** | AI | 7 | P2 | ECO, LOY |
| **Notifications** | NOT | 6 | P1 | Foundation |
| **Operations/AI Ops** | OPS | 6 | P2 | ALL |
| **Order Aggregation** | AGG | 7 | P2 | POSR, ECO |
| **Developer API** | API | 8 | P1 | ORC, SEC |
| **Franchise Mgmt** | FRN | 12 | P3 | MER, POS |
| **Affiliates/Resellers** | AFR | 10 | P2 | MER, WAL |
| **Public Website** | WEB | 20 | P1 | ECO, AFR |
| **NFR/Platform** | NFR | 8 | P0 | Foundation |

**Total: 310+ canonical requirements across 22 domains**

---

## 3. ACTOR × JOURNEY MATRIX — WHO TESTS WHAT

> [!IMPORTANT]
> This is the TDD foundation. Every test scenario traces to an **actor + goal + requirement**.

### 3.1 Human Actors (25 defined in ACT_ACTOR_LIBRARY.md)

| # | Actor ID | Role | Vertical | Primary Journeys |
|---|---|---|---|---|
| 1 | ACT-T-001 | Restaurant Owner | POSR,PAY,MER,WAL | Dashboard → Revenue review → Payroll approve → Dispute response |
| 2 | ACT-T-002 | District Manager | POSR,POSG,POS,MER | Multi-location compare → Labor alerts → Performance report |
| 3 | ACT-T-003 | General Manager | POSR,PAY,MER | Floor view → Manager override → Real-time labor |
| 4 | ACT-T-004 | Server/Waiter | POSR,PAY,WAL | Order entry → Modifiers → Split check → Tip view → Wallet |
| 5 | ACT-T-005 | Bartender | POSR | Open tab → Manage tabs → Idle alert → Close out |
| 6 | ACT-T-006 | Cook/Kitchen | POSR,POSG | KDS view → Priority queue → Allergy flags → Delay signal |
| 7 | ACT-T-007 | Cashier | POSR,POSG,POS | Scan → Payment → Decline handling → Manager override |
| 8 | ACT-T-008 | Delivery Driver | POSR,ECO | Order pickup → Route → Delivery confirm → Mileage |
| 9 | ACT-T-009 | Grocery Owner | POSG,PAY,MER | Inventory → EBT compliance → Tax categories → Shrinkage |
| 10 | ACT-T-010 | Retail Owner | POS,ECO,PAY,MER | SKU management → BOPIS → Loyalty → Omnichannel |
| 11 | ACT-T-011 | Payroll Admin | PAY,MER | Time clock → Gross-to-net → Tax filing → Pay stubs |
| 12 | ACT-T-012 | Employee | PAY,WAL | View hours → Early pay → Pay stub → W-2 |
| 13 | ACT-T-013 | Accountant | MER,PAY | Settlement export → Bank reconciliation → 1099-K |
| 14 | ACT-C-001 | Dine-In Consumer | POSR,WAL | Order → Pay at table → Split check → Loyalty |
| 15 | ACT-C-002 | Online Consumer | ECO,AI,WAL | AI order → Checkout → Apple Pay → Status tracking |
| 16 | ACT-C-003 | Grocery Consumer | POSG,WAL | Checkout → EBT auto-split → Receipt |
| 17 | ACT-C-004 | Retail Consumer | POS,ECO,WAL | BOPIS → Return → Cross-channel loyalty |
| 18 | ACT-P-001 | Affiliate Partner | AFR | Refer → Track → Commission → Payout |
| 19 | ACT-P-002 | Reseller Partner | AFR,MER | White-label → Sub-merchant onboard → Rate config |
| 20 | ACT-I-001 | AI Ops Agent | OPS | Monitor → Alert → Escalate → Learn |
| 21 | ACT-I-002 | Support Engineer | OPS,ORC | X-Trace lookup → Remote diagnostics → Firmware push |
| 22 | ACT-I-003 | Underwriter | MER,COM | Application review → KYB → Risk score → Approve/Decline |
| 23 | ACT-I-004 | Compliance Officer | COM,WAL,PAY | AML queue → SAR filing → DSAR → Audit trail |
| 24 | ACT-I-005 | Finance Admin | MER,ORC,PAY | Reconciliation → 1099-K → Fee audit |
| 25 | — | Super Admin | ALL | Tenant CRUD → User CRUD → Feature flags → System health |

### 3.2 System-to-System Actors

| # | System Actor | Integration | Direction |
|---|---|---|---|
| S1 | FluidPay Gateway | Payment processing, tokenization, webhooks | Bidirectional |
| S2 | TaxJar | Sales tax calculation | Outbound |
| S3 | Twilio/SendGrid | SMS + Email notifications | Outbound |
| S4 | DoorDash/UberEats/GrubHub | Order aggregation | Inbound webhooks |
| S5 | Apple Pay / Google Pay | Wallet payments | Outbound via FluidPay |
| S6 | QuickBooks/Xero | Accounting export | Outbound |
| S7 | DocuSign | E-signatures for onboarding | Outbound |
| S8 | IRS/State Tax APIs | Payroll tax filing | Outbound |

---

## 4. DATA DICTIONARY — CANONICAL ENTITIES

> [!NOTE]
> This maps every domain entity to its table, owner service, and relationships.

### 4.1 Core Entities

| Entity | DB Table | Owner Service | Relationships | Status |
|---|---|---|---|---|
| **Tenant** | `tenants` | AuthService | → Users, Merchants, Locations | ✅ Schema exists |
| **User** | `users` | AuthService | → Tenant, Roles | ✅ Schema exists |
| **Location** | `locations` | LocationService | → Tenant, Terminals | ✅ Schema exists |
| **Merchant** | `merchants` | MerchantService | → Tenant, Location | ✅ Schema exists |

### 4.2 Payment Entities

| Entity | DB Table | Owner Service | Relationships | Status |
|---|---|---|---|---|
| **Payment Intent** | `payment_intents` | PaymentService | → Merchant, Order | ✅ Schema exists |
| **Refund** | `refunds` | PaymentService | → Payment Intent | ✅ Schema exists |
| **Settlement Batch** | `settlement_batches` | SettlementService | → Merchant, Payment Intents | ✅ Schema exists |
| **Dispute** | `dispute_cases` | — | → Payment Intent | ❌ Schema needed |
| **Gateway Config** | `gateway_configs` | — | → Merchant | ❌ Schema needed |

### 4.3 POS Entities

| Entity | DB Table | Owner Service | Relationships | Status |
|---|---|---|---|---|
| **Order** | `orders` | OrderService | → Tenant, Merchant, Items | ✅ Schema exists |
| **Order Item** | `order_items` | OrderService | → Order, Menu Item | ✅ Schema exists |
| **Menu Item** | `menu_items` | MenuManagerService | → Tenant, Merchant | ✅ Schema exists |
| **Table** | `tables` | — | → Location | ❌ Schema needed |
| **KDS Ticket** | `kds_tickets` | — | → Order | ❌ Schema needed |
| **Reservation** | `reservations` | — | → Location, Customer | ❌ Schema needed |

### 4.4 HR/Payroll Entities

| Entity | DB Table | Owner Service | Relationships | Status |
|---|---|---|---|---|
| **Employee** | `employees` | EmployeeService | → Tenant | ✅ Schema exists |
| **Payroll Run** | `payroll_runs` | PayrollService | → Tenant | ✅ Schema exists |
| **Payroll Line Item** | `payroll_line_items` | PayrollService | → Payroll Run, Employee | ✅ Schema exists |
| **Time Entry** | `time_entries` | — | → Employee | ❌ Schema needed |
| **Schedule Shift** | `schedule_shifts` | — | → Employee, Location | ❌ Schema needed |
| **Pay Stub** | `pay_stubs` | — | → Payroll Run, Employee | ❌ Schema needed |

### 4.5 Customer/Loyalty Entities

| Entity | DB Table | Owner Service | Relationships | Status |
|---|---|---|---|---|
| **Customer** | `customers` | CustomerCrmService | → Tenant | ✅ Schema exists |
| **Loyalty Program** | `loyalty_programs` | LoyaltyService | → Tenant | ✅ Schema exists |
| **Loyalty Transaction** | `loyalty_transactions` | — | → Customer, Program | ❌ Schema needed |
| **Gift Card** | `gift_cards` | — | → Tenant | ❌ Schema needed |

### 4.6 Inventory Entities

| Entity | DB Table | Owner Service | Relationships | Status |
|---|---|---|---|---|
| **Inventory Item** | `inventory_items` | InventoryService | → Tenant | ✅ Schema exists |
| **Purchase Order** | `purchase_orders` | — | → Tenant, Supplier | ❌ Schema needed |

### 4.7 Platform Entities

| Entity | DB Table | Owner Service | Relationships | Status |
|---|---|---|---|---|
| **Affiliate** | `affiliates` | AffiliateService | → Tenant | ✅ Schema exists |
| **Notification** | `notifications` | — | → User | ❌ Schema needed |
| **Audit Log** | `audit_logs` | AuditLogService | → User, Entity | ✅ Migration exists |
| **Feature Flag** | `feature_flags` | FeatureFlagService | — | ✅ Migration exists |
| **Webhook** | `webhooks` | WebhookService | → Tenant | ❌ Schema needed |
| **Document** | `documents` | — | → Merchant | ❌ Schema needed |

### Summary

| Category | Entities Defined | Schemas Exist | Schemas Needed |
|---|---|---|---|
| Core | 4 | 4 | 0 |
| Payment | 5 | 3 | 2 |
| POS | 6 | 3 | 3 |
| HR/Payroll | 6 | 3 | 3 |
| Customer/Loyalty | 4 | 2 | 2 |
| Inventory | 2 | 1 | 1 |
| Platform | 6 | 4 | 2 |
| **TOTAL** | **33** | **20** | **13** |

---

## 5. EXECUTION PHASES — SEQUENCED WITH GATES

> [!IMPORTANT]
> Each phase has a **gate** that must pass before the next phase begins. No skipping.

### Phase 0: Infrastructure Foundation (BLOCKING — do first)
**Owner:** Lead Architect  
**Duration:** ~1 session  
**Gate:** All infrastructure deployed, secrets stored, CI/CD trigger firing

| # | Task | Worker | Depends On |
|---|---|---|---|
| 0.1 | Create Artifact Registry repo (`paysurity-docker`) | Infra Worker | — |
| 0.2 | Create Cloud SQL dev instance (PostgreSQL 16, db-f1-micro) | Infra Worker | — |
| 0.3 | Store secrets in Secret Manager (DB_URL, JWT_SECRET, FLUIDPAY_KEY) | Infra Worker | 0.2 |
| 0.4 | Create Dockerfile for API | Build Worker | — |
| 0.5 | Create Dockerfile for merchant-dashboard | Build Worker | — |
| 0.6 | Create Cloud Build trigger (GitHub push → build + test) | Infra Worker | 0.1, 0.4, 0.5 |
| 0.7 | Run migration against Cloud SQL dev | DBA Worker | 0.2 |
| 0.8 | Seed demo data into Cloud SQL dev | DBA Worker | 0.7 |

**Gate 0 Checklist:**
- [ ] Cloud SQL dev instance accepts connections
- [ ] All 17+ tables exist with correct schema
- [ ] Seed data loaded (4 tenants, 7 users, menu items, inventory)
- [ ] API Docker image builds successfully
- [ ] Dashboard Docker image builds successfully
- [ ] Cloud Build trigger fires on GitHub push

---

### Phase 1: TDD Test Specifications (BEFORE any feature code)
**Owner:** QA Architect  
**Duration:** ~2 sessions  
**Gate:** 100% of canonical requirements have at least 1 test scenario written

| # | Task | Worker | Req Count |
|---|---|---|---|
| 1.1 | Write test specs: ORC (Payment Orchestration) | Worker A | 12 |
| 1.2 | Write test specs: SEC + COM (Security + Compliance) | Worker B | 22 |
| 1.3 | Write test specs: POSR + POSG + POS (All POS verticals) | Worker C | 33 |
| 1.4 | Write test specs: PAY + WAL + TAX (Payroll, Wallets, Tax) | Worker D | 23 |
| 1.5 | Write test specs: MER + AFR + ECO (Merchant, Affiliate, E-Commerce) | Worker E | 29 |
| 1.6 | Write test specs: LOY + NOT + OPS + AI + AGG + API + NFR + SUB | Worker F | 61 |

Each test spec = `.spec.ts` file with:
```
describe('REQ-XXX-NNN: <requirement title>')
  it('HAPPY: <main path description>')
  it('ALT: <alternative path>')
  it('EXCEPT: <error/edge case>')
  it('GUARD: <RBAC/auth check>')
  it('SLA: <performance/latency check>')
```

**Gate 1 Checklist:**
- [ ] Every canonical requirement has ≥1 test file
- [ ] Every test file has happy, alt, and exception paths
- [ ] Test files compile (no TypeScript errors)
- [ ] Tests run and FAIL (red phase of TDD — expected)
- [ ] Test count report generated

---

### Phase 2: Schema Completion (DBA Track)
**Owner:** DBA  
**Duration:** ~1 session (parallelizable)  
**Gate:** All 33 entities have Drizzle schemas + migrations generated

| # | Task | Worker |
|---|---|---|
| 2.1 | Create Drizzle schemas for 13 missing entities | DBA Worker |
| 2.2 | Generate migration SQL via `drizzle-kit generate` | DBA Worker |
| 2.3 | Apply migration to Cloud SQL dev | DBA Worker |
| 2.4 | Validate all foreign keys + indexes | DBA Worker |
| 2.5 | Create comprehensive seed data for all verticals | DBA Worker |

**Gate 2 Checklist:**
- [ ] All 33 entities have Drizzle schema files
- [ ] Migration SQL generated and applied
- [ ] All FK constraints valid
- [ ] Seed data covers all 4 verticals + all actor types
- [ ] Schema matches data dictionary above

---

### Phase 3: Service Implementation (Green Phase — make tests pass)
**Owner:** Full Stack Dev  
**Duration:** ~3-4 sessions (heavily parallelized across 6 workers)  
**Gate:** All Phase 1 tests pass green

| # | Task | Worker | Depends On |
|---|---|---|---|
| 3.1 | Implement ORC services (payment intent lifecycle, gateway routing) | Worker A | Phase 1.1, Phase 2 |
| 3.2 | Implement SEC + COM services (RBAC enforcement, audit trail, AML) | Worker B | Phase 1.2, Phase 2 |
| 3.3 | Implement POS services (order engine, KDS, table mgmt) | Worker C | Phase 1.3, Phase 2 |
| 3.4 | Implement PAY + WAL + TAX services (payroll engine, wallet, tax calc) | Worker D | Phase 1.4, Phase 2 |
| 3.5 | Implement MER + AFR + ECO services (onboarding, affiliate, e-commerce) | Worker E | Phase 1.5, Phase 2 |
| 3.6 | Implement LOY + NOT + OPS + remaining services | Worker F | Phase 1.6, Phase 2 |

**Gate 3 Checklist:**
- [ ] All unit tests from Phase 1 pass green
- [ ] All services compile with zero TypeScript errors
- [ ] API endpoints respond correctly (manual smoke test via Swagger)
- [ ] RBAC enforced on every endpoint
- [ ] Audit trail fires for every state-changing operation
- [ ] X-Trace-Id propagated end-to-end

---

### Phase 4: Frontend Wiring + E2E Tests
**Owner:** Full Stack Dev  
**Duration:** ~2 sessions  
**Gate:** All frontend screens display real data from backend

| # | Task | Worker |
|---|---|---|
| 4.1 | Wire dashboard pages to live API endpoints | Frontend Worker |
| 4.2 | Wire POS terminal to create real orders | Frontend Worker |
| 4.3 | Wire all 4 storefronts to checkout flow | Frontend Worker |
| 4.4 | Build admin portal (tenant CRUD, user mgmt, feature flags) | Frontend Worker |
| 4.5 | Build employee portal (time clock, pay stubs, schedule) | Frontend Worker |
| 4.6 | Write Playwright E2E tests for critical user journeys | QA Worker |

**Gate 4 Checklist:**
- [ ] Login → Dashboard shows real data
- [ ] POS → Create order → Appears in orders list
- [ ] Storefront → Checkout → Payment processed
- [ ] Admin → Create tenant → Login as tenant
- [ ] All E2E tests pass in CI

---

### Phase 5: Staging Deployment + Integration Testing
**Owner:** Lead Architect + Compliance Officer  
**Duration:** ~1 session  
**Gate:** Staging environment fully functional with passing integration tests

| # | Task | Worker |
|---|---|---|
| 5.1 | Deploy API to Cloud Run (staging) | Infra Worker |
| 5.2 | Deploy dashboard to Cloud Run (staging) | Infra Worker |
| 5.3 | Run full test suite against staging | QA Worker |
| 5.4 | Performance load test (k6 or Artillery) | QA Worker |
| 5.5 | Security scan (OWASP ZAP baseline) | Security Worker |
| 5.6 | PCI compliance check (no PAN in logs, tokenized only) | Compliance Worker |

**Gate 5 Checklist:**
- [ ] Staging URL accessible and functional
- [ ] All E2E tests pass against staging
- [ ] P95 response time < 500ms under 100 concurrent users
- [ ] Zero PAN data found in any log or response
- [ ] RBAC prevents unauthorized access (verified by test)
- [ ] Audit trail complete for all tested operations

---

### Phase 6: Production Readiness
**Owner:** All stakeholders  
**Gate:** Production deployment approval

| Check | Owner | Criteria |
|---|---|---|
| Code Review | Lead Architect | All PRs reviewed, no critical tech debt |
| Test Coverage | QA | ≥80% line coverage, 100% critical path |
| Security | Compliance Officer | OWASP scan clean, PCI checklist signed |
| Performance | Reporting Analyst | SLA targets met under load |
| Data Integrity | DBA | FK constraints valid, no orphan records |
| Monitoring | Ops | Alerting configured for errors, latency, downtime |
| Rollback Plan | Lead Architect | Blue/green or canary deployment configured |

---

## 6. SWARM WORKER ASSIGNMENTS — SUMMARY

| Worker | Role | Phase 0 | Phase 1 (TDD) | Phase 2 (Schema) | Phase 3 (Impl) | Phase 4 (UI) | Phase 5 (Staging) |
|---|---|---|---|---|---|---|---|
| **Worker A** | Core Financial | — | ORC tests | — | ORC services | — | — |
| **Worker B** | Security/Compliance | — | SEC+COM tests | — | SEC+COM services | — | Security scan |
| **Worker C** | POS Verticals | — | POS tests | — | POS services | — | — |
| **Worker D** | Payroll/Wallets | — | PAY+WAL tests | — | PAY+WAL services | — | — |
| **Worker E** | Merchant/Commerce | — | MER+ECO tests | — | MER+ECO services | — | — |
| **Worker F** | Growth/Platform | — | Remaining tests | — | Remaining services | — | — |
| **Infra Worker** | DevOps | Cloud SQL, AR, triggers | — | Migrations | — | — | Cloud Run deploy |
| **DBA Worker** | Database | — | — | All schemas | — | — | Data integrity |
| **Frontend Worker** | UI/UX | — | — | — | — | All UI wiring | — |
| **QA Worker** | Testing | — | — | — | — | E2E tests | Integration tests |

---

## 7. IMMEDIATE NEXT STEP: Phase 0

Before ANY coding or testing work begins, we need the GCP infrastructure.  
The critical path is:

```
Cloud SQL dev instance (0.2)
    ↓
Store secrets (0.3)
    ↓
Run migration (0.7) + Seed data (0.8)
    ↓
Artifact Registry (0.1) + Dockerfiles (0.4, 0.5)
    ↓
Cloud Build trigger (0.6)
    ↓
✅ GATE 0 PASSED → Begin Phase 1 (TDD)
```

**Estimated Cloud SQL dev cost:** ~$7-10/month (db-f1-micro, 10GB)  
**Estimated Cloud Run staging cost:** ~$0 (free tier covers dev usage)  
**Worker pool cost:** ~$0.05-0.10 per build minute

---

## 8. DECISION NEEDED FROM YOU

> [!IMPORTANT]
> Before I execute Phase 0, confirm:

1. **Cloud SQL budget OK?** (~$7-10/month for dev instance)
2. **Region preference?** Currently us-central1 (matches worker pool)
3. **Domain name ready?** For staging URL (or use Cloud Run default URLs?)
4. **FluidPay sandbox credentials?** Needed for payment testing
5. **Shall I proceed with Phase 0 infrastructure creation?**
