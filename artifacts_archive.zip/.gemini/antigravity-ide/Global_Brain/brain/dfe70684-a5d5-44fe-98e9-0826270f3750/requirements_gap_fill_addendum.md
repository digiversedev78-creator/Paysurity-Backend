# PaySurity Platform — Requirements Gap Fill Addendum
## Closing ALL 15 Identified Gaps Before Swarm Launch

> **Date:** 2026-03-14  
> **Status:** COMPLETE — All gaps addressed  
> **Authority:** These requirements are BINDING additions to the canonical set

---

## GAP 1: Tip Handling (CRITICAL)
### REQ-POSR-011: Tip Management
**Vertical:** BistroBeast | **Actor:** Waiter, Owner, Consumer

**Acceptance Criteria:**
1. Pre-auth = subtotal + estimated tip (20% default, configurable)
2. Tip adjustment allowed within 24hr of original auth
3. Tip entry by: server (cash tip), customer (on-screen), QR pay (mobile)
4. Tip pools: configurable split ratios (e.g., 70% server, 15% busser, 15% bar)
5. Tip reports: daily tip-out sheet per employee, pay period totals
6. Tipped minimum wage compliance tracking
7. Tip cannot exceed 100% of subtotal (fraud guard)

**Tests:** 8 scenarios

---

## GAP 2: Void vs Refund Distinction (CRITICAL)
### REQ-ORC-013: Void Transaction
**Vertical:** All POS | **Actor:** Manager, Cashier

**Acceptance Criteria:**
1. Void: only BEFORE end-of-day settlement batch closes
2. Void: cancels authorization, no charge on customer card
3. Void: requires PIN or manager override
4. Refund: only AFTER settlement (next day+)
5. System auto-determines: pre-settlement → void; post-settlement → refund
6. Both logged to audit trail with reason code

**Tests:** 6 scenarios

---

## GAP 3: Receipt Management (CRITICAL)
### REQ-POS-010: Receipt Generation & Delivery
**Vertical:** All POS + E-Commerce | **Actor:** Cashier, Consumer

**Acceptance Criteria:**
1. Print: thermal printer format (80mm/58mm)
2. Email: customer email prompted, branded template
3. SMS: short link to digital receipt
4. No-receipt option: customer can decline
5. Content: merchant, date/time, items, subtotal, tax, tip, total, last-4, auth code, X-Trace-Id
6. Duplicate reprint/resend from order history
7. Gift receipt (excludes prices)
8. Return receipt (shows original transaction ref)

**Tests:** 8 scenarios

---

## GAP 4: End-of-Day / Z-Report (CRITICAL)
### REQ-POS-011: Shift Close & Z-Report
**Vertical:** All POS | **Actor:** Cashier, Manager

**Acceptance Criteria:**
1. X-Report: mid-shift read-only snapshot, does NOT reset counters
2. Z-Report: end-of-shift final report, resets counters, locks shift
3. Cash count entry: cashier enters physical cash
4. Over/short calculation: expected vs counted
5. Settlement batch trigger on Z-report
6. Report: total sales, returns, voids, net, cash/card/EBT breakdown
7. Manager approval if over/short > $5.00
8. Blind close option (count without seeing expected)

**Tests:** 8 scenarios

---

## GAP 5: Cash Drawer Management (CRITICAL)
### REQ-POS-012: Cash Drawer Operations
**Vertical:** All POS | **Actor:** Cashier, Manager

**Acceptance Criteria:**
1. Open drawer: only on cash transaction, no-sale (manager PIN), or paid-out
2. Starting bank: configurable per shift (default $200)
3. Paid-in: cash added mid-shift
4. Paid-out: cash removed (requires reason)
5. No-sale: opens drawer without transaction — logged, requires manager code
6. Cash drop: safe drops during shift
7. Drawer assignment: one per cashier per shift

**Tests:** 7 scenarios

---

## GAP 6: Split Payment / Multi-Tender (CRITICAL)
### REQ-ORC-014: Multi-Tender Payment
**Vertical:** All POS | **Actor:** Cashier, Consumer

**Acceptance Criteria:**
1. Split by tender: $20 Card A + $15 Card B + $5 cash
2. Split by guest: each guest pays own items
3. Split evenly: divide total by N guests
4. EBT + cash/card: SNAP items on EBT, remainder on card
5. Gift card + card: gift card first, remainder on card
6. Partial payment: if first tender fails, remaining balance clear
7. Each tender on receipt
8. All tenders linked to same order in audit trail

**Tests:** 8 scenarios

---

## GAP 7: Offline POS Mode (CRITICAL)
### REQ-NFR-009: Offline POS Operation
**Vertical:** All POS | **Actor:** Cashier, Manager

**Acceptance Criteria:**
1. Detect internet loss within 5 seconds
2. Queue transactions locally (IndexedDB + service worker)
3. Store-and-forward: offline card transactions processed on reconnect
4. Offline limit: configurable max $/transaction (default $50)
5. Offline limit: configurable max total queue (default $500)
6. Cash: fully functional offline
7. Sync on reconnect: all queued sent, conflicts resolved
8. Visual indicator: online/offline status
9. Menu/inventory cached locally
10. Offline mode auto-disabled for refunds/voids

**Tests:** 10 scenarios

---

## GAP 8: Accounting Export (IMPORTANT)
### REQ-MER-012: Accounting Integration
**Vertical:** All | **Actor:** Accountant, Owner

**Acceptance Criteria:**
1. Export daily journal entries to QuickBooks Online format
2. Export to Xero CSV format
3. Map categories to chart of accounts
4. Auto daily sync via QBO OAuth2 API
5. Manual CSV download for any system
6. Settlement reconciliation: bank deposit = export total
7. Tax liability entries auto-calculated

**Tests:** 7 scenarios

---

## GAP 9: Data Portability (IMPORTANT)
### REQ-COM-013: Merchant Data Export
**Vertical:** Platform | **Actor:** Owner, Compliance Officer

**Acceptance Criteria:**
1. Full data export in CSV/JSON
2. Includes: transactions, customers, inventory, orders, employees, settings
3. Tenant isolation enforced
4. Available within 30 days of request
5. On closure: data preserved 7 years (IRS), then auto-purged
6. Format documented with field descriptions

**Tests:** 6 scenarios

---

## GAP 10: FluidPay Error Mapping (IMPORTANT)
### REQ-ORC-015: Gateway Error Taxonomy
**Vertical:** Payment | **Actor:** System, Support Engineer

**Acceptance Criteria:**
1. Map all FluidPay decline codes to user-friendly messages
2. Categories: hard decline (no retry), soft decline (retry OK), system error
3. Cashier sees friendly message, not raw code
4. Raw + mapped code both logged
5. Decline analytics by merchant/period
6. Decline code reference in merchant portal

**Tests:** 6 scenarios

---

## GAP 11: Gateway Failover (IMPORTANT)
### REQ-ORC-016: Payment Gateway Resilience
**Vertical:** Payment | **Actor:** System, Support Engineer

**Acceptance Criteria:**
1. Health check: ping FluidPay every 30 seconds
2. Circuit breaker: 5 consecutive failures → open circuit
3. Queue mode: transactions queued during outage (max 5 min)
4. Alert: support notified within 60 seconds
5. Fallback UX: "Payment temporarily unavailable"
6. Recovery: auto-retry queued on circuit close
7. Phase 2: secondary gateway as hot failover

**Tests:** 7 scenarios

---

## GAP 12: PCI SAQ-A (IMPORTANT)
### REQ-COM-014: PCI DSS SAQ-A Compliance
**Vertical:** Platform | **Actor:** Compliance Officer

**Acceptance Criteria:**
1. SAQ-A qualification (card data never touches PaySurity servers)
2. All payment forms use FluidPay hosted fields (iframe tokenization)
3. No PAN/CVV/magstripe in any system, log, or DB — EVER
4. Annual SAQ-A self-assessment filed
5. Quarterly ASV scan passed
6. PCI compliance dashboard

**Tests:** 6 scenarios

---

## GAP 13: FDA Tobacco Compliance (IMPORTANT)
### REQ-POSG-015: Age-Restricted Product Compliance
**Vertical:** PayRetail, GrocerEase | **Actor:** Cashier, Manager

**Acceptance Criteria:**
1. Tobacco/vape/alcohol items flagged in catalog
2. POS prompts age verification — CANNOT be bypassed
3. DOB entry: age ≥ 21 for tobacco/alcohol (state-dependent)
4. ID scan option: parse driver's license barcode
5. Manager override NOT allowed for underage — hard block
6. Compliance log: every verification recorded
7. Regulatory audit trail exportable

**Tests:** 7 scenarios

---

## GAP 14: Table Management (IMPORTANT)
### REQ-POSR-012: Table & Seating Management
**Vertical:** BistroBeast | **Actor:** Manager, Waiter

**Acceptance Criteria:**
1. Floor plan editor: drag-drop table layout
2. Table status: available, seated, ordered, served, check-dropped, dirty
3. Server assignment per table
4. Wait time display when full
5. Table merge for large parties
6. Turn time tracking (revenue optimization)
7. Walk-in vs reservation indicator

**Tests:** 7 scenarios

---

## GAP 15: i18n Infrastructure Stub (Deferred Phase 2)
### REQ-NFR-010: Internationalization Infrastructure
**Vertical:** Platform | **Actor:** All

**Acceptance Criteria:**
1. All user-facing strings externalized to locale files (en-US default)
2. Locale selection stored per user preference
3. Date/time/currency formatting respects locale
4. Phase 2: add es-MX, fr-CA
5. No hardcoded strings in components

**Tests:** 5 scenarios

---

## Updated Totals

| Metric | Before | After |
|---|---|---|
| Canonical requirements | 310+ | **325+** |
| Test scenarios | ~735 | **~840** |
| Coverage gaps | 15 | **0** |
| Day-1 blockers | 7 | **0** |
