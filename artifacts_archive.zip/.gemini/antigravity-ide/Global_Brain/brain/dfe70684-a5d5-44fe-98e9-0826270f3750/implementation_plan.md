# Root Cause Analysis & Strategy Reset

## What Went Wrong (Root Causes)

### Primary Cause: Swarm File Concatenation Anti-Pattern

Every previous swarm worker was instructed to generate multiple TypeScript files in a **single LLM response**. The model would output them as markdown code blocks fenced by ` ```typescript `. When written to disk, these became concatenated into the **first file in the list**, with all subsequent files embedded as markdown artifacts inside it.

This caused **5 distinct corruption patterns**:

| Pattern | Description | Files Affected |
|---|---|---|
| **Code fence corruption** | ` ```typescript ` embedded mid-file | 7 files |
| **Supporting-files append** | `// --- Supporting Files ---` divider with junk appended | 69 files |  
| **Truncated + appended schema** | Drizzle schema SQL injected after `export class` | (e.g. `payment.module.ts`) |
| **Empty/hollow files** | Entire file content = path string (`apps/api/src/...`) | 4+ files |
| **Missing files entirely** | Module referenced in `app.module.ts` but never written | 2+ files |

### Secondary Cause: No Local Build Gate Before Cloud Build

We were push → Cloud Build → observe error → fix → repeat. Each Cloud Build takes 5-8 minutes. With 15+ iterations, that's 90+ minutes just waiting for CI feedback on problems that could have been caught locally in seconds.

### Tertiary Cause: `package.staging.json` Doesn't Mirror Real `package.json`

The staging package strips `workspace:*` deps but also inadvertently strips real runtime dependencies like `compression`. Without a local simulation, we didn't catch missing deps until the container started (or failed to start) in Cloud Run.

---

## Answers to Your Questions

### Should we split into per-vertical repos?

**No — not yet.** The monorepo is the right structure. The problem is not the monorepo; it's the Docker build not understanding pnpm workspace protocols. We've already solved this with `package.staging.json`. **Splitting into multiple repos now would be premature and add enormous complexity.** Each vertical would need its own CI pipeline, shared library versioning, and cross-service contracts.

### Was the swarm approach fundamentally wrong?

The swarm **strategy** is sound. The **worker instructions** were wrong — they didn't enforce single-file-per-task discipline.

---

## Anti-Corruption Protocol for All Future Swarm Workers

> [!IMPORTANT]
> **ALL future swarm worker prompts MUST include these constraints verbatim:**

```
ANTI-CORRUPTION RULES (MANDATORY):
1. WRITE ONE FILE PER RESPONSE. Never concatenate multiple files in one message.
2. Every file response must contain ONLY valid TypeScript — no markdown, no ``` fences, no comments like "// next file:".
3. If a file path is given, write ONLY the content of that EXACT file.
4. NEVER append Drizzle schema, SQL, or secondary file content after the class closes.
5. NEVER truncate a file — every class/function opened must be properly closed.
6. After writing, the file should compile standalone with: npx tsc --noEmit --skipLibCheck on that single file.
7. Do NOT generate test files (.spec.ts, .e2e-spec.ts) in any production task.
```

---

## Proposed Changes (What We Do Next)

### Phase 1: Fix the 2 Missing Modules + Verify Locally (30 min)

These 2 modules are imported in `app.module.ts` but don't exist on disk:
- `apps/api/src/modules/user/user.module.ts`
- `apps/api/src/modules/tenant/tenant.module.ts`

**Action:** Create minimal but real stubs for both, then **run `nest build` locally** to confirm zero SWC errors before touching Cloud Build again.

---

### Phase 2: Local Simulation of the Full Docker Build (20 min)

Before submitting ANYTHING to Cloud Build:

```powershell
# 1. Copy package.staging.json as package.json to a temp dir
# 2. npm install --legacy-peer-deps 
# 3. Copy src/
# 4. Run nest build
# 5. Run node dist/main.js and verify it binds to PORT=3000 
```

This catches MODULE_NOT_FOUND and startup errors locally instead of burning 8 minutes per Cloud Build.

---

### Phase 3: One Final Cloud Build (10 min wait)

After phases 1+2 pass locally, submit a single clean Cloud Build. The pipeline (Docker build → AR push → Cloud Run deploy) has been proven to work individually. The only remaining issue is ensuring `app.module.ts` can boot.

---

## Verification Plan

### Automated (Local)
```powershell
# In apps/api/
./node_modules/.bin/nest build --config nest-cli.json
# Exit code 0 = SWC compiled all included TS files cleanly

PORT=8080 node dist/main.js &
Start-Sleep 5
Invoke-WebRequest http://localhost:8080/health
# Expected: {"status":"ok",...}
```

### Cloud Build Verification
- Step 0 (Docker build): consistently passes (~2:30)
- Step 1-2 (AR push): consistently passes (~20s)  
- Step 3 (Cloud Run deploy): blocked by container startup
- Step 4 (Health curl): first time ever running

### Manual Staging Verification
After deploy: 
- `GET https://paysurity-api-111328865246.us-central1.run.app/health` → `{"status":"ok"}`
- `GET https://paysurity-api-111328865246.us-central1.run.app/api/docs` → Swagger UI

---

## What NOT to Do

> [!CAUTION]
> - DO NOT run another Cloud Build until local `nest build` + `node dist/main.js` both pass
> - DO NOT add more anti-corruption fix scripts (we have enough) — fix at the source
> - DO NOT split into per-vertical repos during this phase

---

## Swarm Worker Pool Instructions Going Forward

Worker pools will follow a **"One File, One Task"** discipline:

| Worker Role | Task Granularity | Anti-Corruption Rule |
|---|---|---|
| `CODER-N` | 1 TypeScript file per task | Single file, no fences, no appends |
| `VERIFIER-N` | 1 module per task | Run `tsc --noEmit` on the file |
| `INFRA-N` | 1 config file per task | Validate JSON/YAML before writing |
| `ORCHESTRATOR` (you) | Coordinate, review gate outputs | Never trust swarm output without verification |

