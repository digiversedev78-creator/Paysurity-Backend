# PaySurity 2026 — Implementation Plan & System Audit
**Date:** 2026-03-13 07:42 CST | **Role:** AG Lead Architect / Orchestrator  
**Ref:** PROJECT_PLAN.md | **Target:** Model B ISO Platform with Fintech-Grade UI

---

## Part 1: As-Is Codebase Maturity Audit

### 1.1 Infrastructure Status

| Component | Status | Evidence |
|---|---|---|
| **NestJS API** | ✅ **LIVE** | Boots on port 4000, all modules load, health returns 200 |
| **PostgreSQL** | ✅ **LIVE** | 15 tables across 8 migrations, BistroBeest seeded |
| **Redis** | ✅ **LIVE** | BullMQ connected, eviction policy warning (cosmetic) |
| **TypeScript** | ✅ **0 errors** | `tsc --noEmit` passes clean |
| **Build** | ✅ **FIXED** | Root cause: base tsconfig `incremental: true` caused stale cache. Fixed with explicit `incremental: false` + `noEmit: false` in API tsconfig |
| **Docker** | ✅ **RUNNING** | `paysurity_2026_postgres` (5436), `paysurity_2026_redis` (6381) |
| **CI/CD** | ✅ **CREATED** | `cloudbuild.yaml` → `paysurity-worker-pool`, 8 steps with compliance gate |
| **Frontends** | ✅ **SCAFFOLDED** | merchant-dashboard (4001), public-website (4003), admin-portal (4004) |

### 1.2 Database Schema (15 Tables)

```mermaid
erDiagram
    tenants ||--o{ merchants : "1:N (org→brand)"
    merchants ||--o{ locations : "1:N (brand→store)"
    merchants ||--o{ payment_intents : "1:N"
    tenants ||--o{ users : "1:N"
    tenants ||--o{ digital_wallets : "1:N"
    tenants ||--o{ settlement_instructions : "1:N"
    payment_intents ||--o{ settlement_instructions : "1:N"
    locations ||--o{ users : "location scope"
    tenants ||--o{ audit_events : "1:N"
    tenants ||--o{ security_events : "1:N"
    tenants ||--o{ platform_config : "1:N"
    tenants ||--o{ merchant_config : "1:N"
    tenants ||--o{ tenant_feature_flags : "1:N"
```

### 1.3 Security & Compliance Posture

| Domain | Requirement | Status | Details |
|---|---|---|---|
| **PCI DSS §3.4** | No PAN stored | ✅ COMPLIANT | `sanitize-gateway-response.ts` redacts PAN/CVV/track data before JSONB persistence |
| **PCI DSS §6.5** | Input validation | ✅ COMPLIANT | Global `ValidationPipe` with `whitelist: true`, `forbidNonWhitelisted: true` |
| **PCI DSS §10** | Audit trail | ✅ COMPLIANT | `audit_events` table + `AuditInterceptor` on all state-changing requests |
| **PCI DSS §8** | Authentication | ✅ COMPLIANT | JWT RS256, MFA support, account lockout, session management |
| **Model B ISO** | No fund holding | ✅ COMPLIANT | `MERCHANT_FLOAT` → `VIRTUAL_SETTLEMENT_SHADOW`, gateway-reported balances only |
| **Model B ISO** | Fee splitting | ✅ COMPLIANT | `payment_intents.platform_fee_cents` + `settlement_instructions` table |
| **ISO 20022** | Structured addresses | ✅ COMPLIANT | Migration 005: `street_name`, `building_number`, `post_code`, `town_name`, `country_sub_division` |
| **GDPR** | Data minimization | 🟡 PARTIAL | EIN encrypted via GCP Secret Manager refs, but GDPR data deletion workflow not implemented |
| **RBAC** | Role-based access | ✅ COMPLIANT | 12 roles, `@Roles()` decorator, `RolesGuard` |
| **RLS** | Tenant isolation | ✅ COMPLIANT | PostgreSQL RLS policies on all tenant-scoped tables |

### 1.4 API Integrations

| Integration | Status | Adapter |
|---|---|---|
| **FluidPay** (Primary Gateway) | ✅ IMPLEMENTED | `FluidPayAdapter` implements `IProviderAdapter` with circuit breaker |
| **FluidPay Sandbox Keys** | ✅ CONFIGURED | Private: `api_2wuAs...`, Public: `pub_2wuB3...` |
| **TaxJar** | 📋 SPEC READY | TAX canonical spec complete, adapter not yet built |
| **Stripe Identity** (KYB) | 📋 SPEC READY | MER canonical spec complete, adapter not yet built |
| **Twilio** (SMS/Notifications) | 📋 SPEC READY | NOT canonical spec complete, adapter not yet built |
| **Google Maps** (Address validation) | ❌ NOT STARTED | Needed for ISO 20022 address validation |

### 1.5 Event Pipeline

| Component | Status |
|---|---|
| BullMQ Event Bus | ✅ LIVE (4 queues: payment-events, loyalty-events, notification-events, dead-letter-queue) |
| `payment.captured` → `loyalty.earn` consumer | ✅ IMPLEMENTED with DLQ |
| `payment.captured` → `notification.receipt` consumer | ✅ IMPLEMENTED |
| All other event consumers | ❌ NOT YET (wired in vertical sprints) |

---

## Part 2: Modular Decomposition — Plan to Launch

### 2.1 Module Dependency Graph

```
                    ┌─────────────────────────────┐
                    │      FOUNDATION (Sprint 0)   │ ✅ COMPLETE
                    │  Auth, RBAC, RLS, EventBus   │
                    │  Health, Config, Migrations   │
                    └──────────┬──────────────────┘
                               │
              ┌────────────────┼────────────────┐
              │                │                │
    ┌─────────▼──────┐  ┌─────▼──────┐  ┌──────▼─────────┐
    │ ORC (Payment)  │  │ MER (Onb.) │  │ SEC (Security) │
    │ FluidPay Adapt.│  │ KYB Flow   │  │ MFA, Sessions  │
    │ Fee Split      │  │ Hierarchy  │  │ Ghost Audit    │
    └───────┬────────┘  └─────┬──────┘  └──────┬─────────┘
            │                 │                │
   ┌────────┼────────┐       │       ┌────────┼────────┐
   │        │        │       │       │                 │
┌──▼──┐  ┌──▼──┐  ┌──▼──┐   │    ┌──▼──┐           ┌──▼──┐
│POSR │  │POSG │  │ POS │   │    │ LOY │           │ NOT │
│Rest.│  │Groc.│  │Retl.│   │    │Loyal│           │Notif│
└──┬──┘  └──┬──┘  └──┬──┘   │    └──┬──┘           └──┬──┘
   │        │        │      │       │                  │
   └────────┼────────┘      │       │                  │
            │               │       │                  │
    ┌───────▼───────┐  ┌────▼────┐  │     ┌────────────▼────┐
    │  TAX Engine   │  │  SUB    │  │     │  WEB/MOB/AI     │
    │  TaxJar       │  │Subscr.  │  │     │  Consumer UX    │
    └───────────────┘  └─────────┘  │     └─────────────────┘
                                    │
                     ┌──────────────▼──────────────┐
                     │  PAY (Payroll) → WAL (Wallet)│
                     │  NACHA ACH, Instant Credits   │
                     └──────────────────────────────┘
```

### 2.2 Sprint Plan with Parallel Execution

#### Sprint 1: Core Engine (Est. 2 weeks)

| Module | Parallelizable? | Worker Pool Task | Dependencies |
|---|---|---|---|
| **ORC-001** Payment Orchestration Service | ✅ YES | `orc-payment-service` | Foundation ✅ |
| **MER-001** Merchant Onboarding Flow | ✅ YES | `mer-onboarding-flow` | Foundation ✅ |
| **SEC-001** Session Management + MFA | ✅ YES | `sec-session-mfa` | Auth ✅ |
| **AUTH-DTO** Fix Login DTO validation | ✅ YES | `auth-dto-fix` | Auth ✅ |

> These 4 modules have ZERO cross-dependencies. All can run in parallel on the worker pool.

#### Sprint 2: POS Verticals (Est. 2 weeks)

| Module | Parallelizable? | Worker Pool Task | Dependencies |
|---|---|---|---|
| **POSR-001** Restaurant POS (Orders, KDS, Tables) | ✅ YES | `posr-restaurant-pos` | ORC ← |
| **POSG-001** Grocery POS (Barcode, EBT, Scale) | ✅ YES | `posg-grocery-pos` | ORC ← |
| **POS-R-001** Retail POS (Returns, Gift Cards) | ✅ YES | `pos-retail-pos` | ORC ← |
| **LOY-001** Loyalty Engine (Points, Tiers) | ✅ YES | `loy-loyalty-engine` | EventBus ✅ |

> POSR/POSG/POS-Retail are independent verticals — fully parallel. LOY depends only on EventBus (done).

#### Sprint 3: Financial Suite (Est. 2 weeks)

| Module | Parallelizable? | Worker Pool Task | Dependencies |
|---|---|---|---|
| **TAX-001** Tax Engine (TaxJar) | ✅ YES | `tax-engine-taxjar` | ORC ← |
| **SUB-001** Subscriptions & Billing | ✅ YES | `sub-subscriptions` | MER ← |
| **PAY-001** Payroll (NACHA ACH) | ✅ YES | `pay-payroll-nacha` | MER ← |
| **WAL-001** Digital Wallets (Model B) | ⚠️ SEQUENTIAL | `wal-wallets-modelb` | PAY ← |

> TAX, SUB, PAY can run in parallel. WAL must wait for PAY (payroll credits feed wallets).

#### Sprint 4: Consumer Experience (Est. 2 weeks)

| Module | Parallelizable? | Worker Pool Task | Dependencies |
|---|---|---|---|
| **WEB-001** Public Website (Marketing) | ✅ YES | `web-public-site` | None |
| **MOB-001** Consumer Mobile/PWA | ✅ YES | `mob-consumer-pwa` | WAL ← |
| **AI-001** AI Assistant (NLU Ordering) | ✅ YES | `ai-assistant-nlu` | POSR ← |
| **NOT-001** Notification Service | ✅ YES | `not-notifications` | EventBus ✅ |

#### Sprint 5: Operations & Compliance (Est. 1 week)

| Module | Parallelizable? | Worker Pool Task | Dependencies |
|---|---|---|---|
| **OPS-001** Daily Briefs, Analytics | ✅ YES | `ops-daily-briefs` | All POS ← |
| **AGG-001** Platform Aggregation | ✅ YES | `agg-platform-agg` | All ← |
| **COM-001** GDPR/CCPA Compliance | ✅ YES | `com-compliance` | All ← |
| **FRN-001** Franchise Management | ✅ YES | `frn-franchise-mgmt` | MER ← |

---

## Part 3: Orchestrator Assembly Protocol

### 3.1 AG's Role as Central Assembler

```
┌─────────────────────────────────────────────────────┐
│                   AG ORCHESTRATOR                    │
│  ┌─────────────┐  ┌──────────┐  ┌───────────────┐  │
│  │ Arch Review  │  │ Merge    │  │ Compliance    │  │
│  │ Gate         │  │ Gate     │  │ Gate (PCI/B)  │  │
│  └──────┬──────┘  └────┬─────┘  └──────┬────────┘  │
│         │              │               │            │
│         ▼              ▼               ▼            │
│  ┌──────────────────────────────────────────────┐   │
│  │           develop branch (integration)        │   │
│  └──────────────────────┬───────────────────────┘   │
│                         │                            │
│              ┌──────────▼──────────┐                │
│              │ Playwright E2E Pass │                │
│              │ Worker Pool Build   │                │
│              └──────────┬──────────┘                │
│                         │                            │
│              ┌──────────▼──────────┐                │
│              │   main branch       │                │
│              │   (market ready)    │                │
│              └─────────────────────┘                │
└─────────────────────────────────────────────────────┘
          ↑              ↑              ↑
   ┌──────┴───┐   ┌──────┴───┐   ┌─────┴────┐
   │ Worker 1 │   │ Worker 2 │   │ Worker N │
   │ ORC-001  │   │ MER-001  │   │ SEC-001  │
   │ feature/ │   │ feature/ │   │ feature/ │
   └──────────┘   └──────────┘   └──────────┘
```

### 3.2 Assembly Checklist (Per Module Integration)

Every module from the worker pool must pass ALL gates before merge:

| # | Gate | Check | Tool |
|---|---|---|---|
| 1 | **Compile** | `tsc --noEmit` = 0 errors | CI step 3 |
| 2 | **Schema** | Migration applies cleanly, idempotency_key on all write tables | CI step 5 |
| 3 | **Model B** | No `MERCHANT_FLOAT`, no balance calculations for settlements | CI step 8 |
| 4 | **PCI** | No PAN storage, sanitizer on all gateway responses | CI step 8 |
| 5 | **ISO 20022** | All addresses use structured fields | Manual review |
| 6 | **RLS** | All tenant-scoped tables have RLS policy | Manual review |
| 7 | **Event** | Cross-vertical communication via EventBus only (no direct imports) | Manual review |

### 3.3 Worker Pool Dispatch Format

```yaml
# Example: Dispatch ORC-001 to worker pool
steps:
  - id: 'orc-001-payment-service'
    name: 'node:20'
    args: ['pnpm', 'run', 'scaffold:orc']
    env:
      - 'MODULE=ORC'
      - 'REQUIREMENT=ORC-001'
      - 'CANONICAL_FILE=Requirements/Canonical/ORC_PAYMENT_ORCHESTRATION.md'
      - 'MIGRATION_SEQ=009'
      - 'BRANCH=feature/orc-001-payment-service'
options:
  pool:
    name: 'projects/paysurity-platform-2026/locations/us-central1/workerPools/paysurity-worker-pool'
```

---

## Part 4: Critical Path & Risk Matrix

### 4.1 Launch-Blocking Items

| # | Item | Risk | Mitigation | Sprint |
|---|---|---|---|---|
| 1 | FluidPay sandbox → production API key | 🔴 HIGH | Apply for production account | Pre-launch |
| 2 | WAL `MERCHANT_FLOAT` legal review | 🔴 HIGH | Legal counsel on Model B compliance | Sprint 0 ✅ (mitigated) |
| 3 | ISO 20022 address validation | 🟡 MED | Google Maps API integration for address normalization | Sprint 3 |
| 4 | Playwright E2E suite | 🟡 MED | Must exist before any `main` merge | Sprint 2 |
| 5 | GDPR deletion workflow | 🟡 MED | COM-001 module | Sprint 5 |
| 6 | Redis eviction policy | 🟢 LOW | Change to `noeviction` in docker-compose | Sprint 1 |

### 4.2 Maximum Parallelism Map

```
Week 1-2:  [ORC-001] [MER-001] [SEC-001] [AUTH-FIX]  ← 4 parallel workers
Week 3-4:  [POSR-001] [POSG-001] [POS-R] [LOY-001]  ← 4 parallel workers
Week 5-6:  [TAX-001] [SUB-001] [PAY-001] [NOT-001]  ← 4 parallel workers
Week 7:    [WAL-001] [WEB-001] [MOB-001] [AI-001]   ← 4 parallel workers
Week 8:    [OPS-001] [AGG-001] [COM-001] [FRN-001]  ← 4 parallel workers
Week 9:    E2E Testing + Market Faucet Validation
Week 10:   Production deployment on GCP
```

**Total: 20 modules across 8 weeks with 4 parallel workers = 80% time compression vs sequential.**

---

## Part 5: Immediate Next Actions

1. ✅ ~~Fix API build (tsc incremental cache)~~ — **DONE**
2. ✅ ~~Create cloudbuild.yaml with worker pool~~ — **DONE**
3. ✅ ~~Implement merchants hierarchy~~ — **DONE** (Migration 007)
4. ✅ ~~Model B Ledger De-escalation~~ — **DONE** (Migration 006)
5. ✅ ~~IProviderAdapter + FluidPayAdapter~~ — **DONE**
6. ✅ ~~BullMQ Event Bus + DLQ~~ — **DONE**
7. 🔜 **Fix Auth DTO** (login validation pipe rejecting email/password) — Sprint 1 first task
8. 🔜 **Dispatch Sprint 1 modules** to worker pool
9. 🔜 **Create Playwright E2E** base config for Market Faucet testing
