# Orchestrated Remediation — Implementation Plan

Addressing all 5 directives from the orchestrator request: isolation lock, GCP scaling, immediate remediation, AppModule decomposition, and enterprise-service scaffolding.

## User Review Required

> [!IMPORTANT]
> **GCP provisioning (Private Pool, Cloud Build)** requires authenticated `gcloud` CLI access. I will generate the config files and commands, but **you must run the `gcloud` commands** yourself since I don't have GCP credentials.

> [!CAUTION]
> **`.env.production` removal from git history** — I will `git rm --cached` the file and add it to `.gitignore`, but secrets that were ever committed should be considered compromised and **rotated**.

> [!WARNING]
> **AppModule decomposition (92 → ~10 modules)** is the largest change. This refactors the core structure of the gateway service. I will keep all existing service/controller code unchanged — only the module wiring changes.

---

## Proposed Changes

### Phase 1: Immediate Remediation

---

#### [MODIFY] [.gitignore](file:///c:/Users/Detaimfc/Downloads/UrWayDispatch/.gitignore)

The current `.gitignore` has `.env.*` with `!.env.example` exception, but `.env.production` was force-committed at some point. The file needs to be:
1. Removed from git tracking via `git rm --cached .env.production`
2. Verified that `.gitignore` correctly covers it (it already does via `.env.*`)

#### [RENAME] `1022_phase1_production_gates.sql` → `1026_phase1_production_gates.sql`

Both files share prefix `1022`. The airport-queue-system file creates geofence tables with no dependencies on production-gates. The production-gates file creates QR codes, DLQ extensions, disclosures, leads, repayment plans — all independent of the airport queue.

**Resolution**: Rename the production-gates file to `1026` (next available number after `1025`). This preserves execution order since its tables don't depend on `1022`'s airport queue tables.

#### Git branch `infra/test-stabilization`

Create branch, `git add tests/`, commit with message `feat: stabilize test infrastructure (jest + playwright)`.

---

### Phase 2: GCP Infrastructure

---

#### [NEW] [cloudbuild-private-pool.yaml](file:///c:/Users/Detaimfc/Downloads/UrWayDispatch/infra/gcp/cloudbuild-private-pool.yaml)

Cloud Build Private Pool config for `e2-standard-32` instances. Will include the YAML definition and the `gcloud` commands to provision it on project `rideoo-487904`.

---

### Phase 3: AppModule Decomposition

---

All new module files are created under `services/gateway/src/app/modules/`.

#### [NEW] `dispatch.module.ts`
Services: `DispatchService`, `DispatchEnhancementsService`, `OfferService`, `AirportGeofenceService`, `FlightAwarenessService`, `MarketplaceLiquidityService`
Controllers: `DispatchController`, `DispatchSseController`, `AirportQueueController`

#### [NEW] `payment.module.ts`
Services: `PaymentService`, `FluidpayService`, `PayoutService`, `RefundService`, `SplitPayService`, `LedgerService`, `TaxService`, `BillingCronService`, `PricingService`, `PricingPolicyService`
Controllers: `PaymentController`, `PayoutController`, `PaysurityWebhookController`, `PricingController`

#### [NEW] `tenant.module.ts`
Services: `TenantService`, `TenantAnalyticsService`, `TenantApiKeyService`, `SkinningService`, `BrandingInvoiceService`, `VipAnalyticsService`, `ConfigValidatorService`
Controllers: `TenantController`, `TenantDashboardController`, `SkinningController`

#### [NEW] `driver.module.ts`
Services: `DriverService`, `EnhancedDriverService`, `FleetOwnerService`, `VehicleConfigService`, `OcrDocumentService`, `BackgroundCheckService`
Controllers: `DriverController`, `OnboardingController`, `VehicleConfigController`
Gateways: `DriverSocketGateway`

#### [NEW] `rider.module.ts`
Services: `RiderDisputeService`, `BookingAntifraudService`, `HourlyBookingService`, `ReservationsService`, `PassengerNeedsService`, `RatingService`, `QrAttributionService`
Controllers: `RiderController`, `ReservationsController`, `PassengerNeedsController`

#### [NEW] `compliance.module.ts`
Services: `ComplianceService`, `ConsentService`, `DataSubjectRequestService`, `DisclosureService`, `LegalConsentService`, `PlatformTermsService`
Controllers: `ComplianceController`, `DisclosureController`

#### [NEW] `corporate.module.ts`
Services: `CorporateAccountService`, `ApprovalService`
Controllers: `CorporateController`

#### [NEW] `microsite.module.ts`
Services: `MicrositeService`, `FaqService`, `LeadService`
Controllers: `MicrositeController`, `FaqController`, `LeadController`, `SeoController`

#### [NEW] `notification.module.ts`
Services: `NotificationService`, `PushNotificationService`, `SmsService`, `EmailService`, `InTripMessagingService`, `MessageRetentionService`, `VoiceService`

#### [NEW] `infra.module.ts`
Services: `DatabaseService`, `SupabaseService`, `RealtimeService`, `CircuitBreakerService`, `HeartbeatService`, `MetricsService`, `JobQueueService`, `S3Service`, `SecretManagerService`, `GeoZoneService`, `TimezoneService`, `EventsEngineService`, `EnvValidationService`, `GlobalMonitorService`

#### [MODIFY] [app.module.ts](file:///c:/Users/Detaimfc/Downloads/UrWayDispatch/services/gateway/src/app/app.module.ts)

Replace 92 providers + 28 controllers with ~10 module imports. Keep cross-cutting concerns (guards, middleware, filters, interceptors) in AppModule.

---

### Phase 4: Enterprise Service Scaffolding

---

#### [NEW] `services/enterprise-service/src/main.ts`
NestJS bootstrap with Swagger, CORS, validation pipe. Mirrors gateway structure.

#### [NEW] `services/enterprise-service/src/app/app.module.ts`
Root module with ConfigModule, health controller.

#### [NEW] `services/enterprise-service/src/app/controllers/health.controller.ts`
Basic health endpoint.

#### [NEW] `services/enterprise-service/src/app/services/database.service.ts`
TypeORM-based database connection service.

#### [NEW] `services/enterprise-service/tsconfig.json`
TypeScript config for NestJS project.

---

## Verification Plan

### Automated Tests

1. **Gateway TypeScript compilation** — after AppModule decomposition:
   ```bash
   cd services/gateway && npx tsc --noEmit
   ```
   Expected: zero errors.

2. **Gateway unit tests** — existing specs in `services/gateway/src/app/services/*.spec.ts`:
   ```bash
   cd services/gateway && npm test
   ```
   Expected: all existing tests pass (approval.service, disclosure.service, dispute.service, hourly-booking, lead, payout, qr-attribution, rating, split-pay, trip-state-machine, roles.guard).

3. **Enterprise-service compilation**:
   ```bash
   cd services/enterprise-service && npx tsc --noEmit
   ```

4. **Migration ordering check** — verify no duplicate migration numbers:
   ```bash
   ls supabase/migrations/ | Sort-Object | Select-String "^1022"
   ```
   Expected: only one file with prefix `1022`.

5. **Git status check** — confirm `.env.production` is no longer tracked:
   ```bash
   git ls-files --error-unmatch .env.production
   ```
   Expected: error (file not tracked).

### Manual Verification

1. **User must run `gcloud` commands** to provision the Cloud Build Private Pool
2. **User should rotate** any secrets that appeared in `.env.production` commit history
3. **User should review** the 10 domain modules match their mental model of the architecture
