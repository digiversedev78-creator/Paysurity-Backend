# AEL Solutions — Full Completion Plan
> **Date:** March 14, 2026  
> **Goal:** 100% requirements completion → market-ready launch  
> **Starting state:** 91/160 DONE (57%), but honest functional readiness ~30-35%

---

## What Actually Exists (Updated Assessment)

After deeper inspection, the codebase is more substantial than initially assessed:

| Layer | What Exists | Reality |
|-------|-------------|---------|
| **Express Backend** (`server/index.js`) | 3,728 lines, 40 API routes, real PG queries, traceability middleware, tenant freeze logic | ✅ Real server, just not connected to Next.js frontend |
| **Next.js Frontend** | 77 pages, 77 API routes, glassmorphism UI | ✅ Running on port 3000 |
| **Database Schema** | `schema_v5.sql` + 19 V004 migrations | ✅ Ready to deploy |
| **Python Business Modules** | 177 `.py` files with tests | ⚠️ Standalone — not wired to Express |
| **Database Connection** | `.env.local` has `DATABASE_URL=postgresql://admin:password123@localhost:5433/ael_dev_db` | ⚠️ Local PostgreSQL needed |

> [!IMPORTANT]
> **Key insight:** The Next.js frontend (port 3000) and Express backend (port 3000) are **separate applications** that haven't been connected. The Express server has real DB queries but the Next.js API routes return demo data instead of proxying to Express.

---

## Execution Plan — 6 Phases

### Phase 1: Foundation Bridge (Day 1-2)
**Goal:** Connect Next.js frontend ↔ Express backend ↔ PostgreSQL

| # | Task | Req IDs | Effort | What to Do |
|---|------|---------|--------|------------|
| 1.1 | Stand up local PostgreSQL | — | 1h | Docker `postgres:15` on port 5433, apply `schema_v5.sql` + V004 migrations |
| 1.2 | Boot Express backend on port 8001 | — | 30m | Change Express `PORT` to 8001, verify it connects to PG |
| 1.3 | Set `BACKEND_URL=http://localhost:8001` in Next.js | — | 15m | `.env.local` update — all 77 API routes already proxy to `BACKEND_URL` |
| 1.4 | Verify end-to-end data flow | — | 1h | Seed demo tenants, hit Next.js → Express → PG → real data in UI |
| 1.5 | Deploy PostgreSQL to Cloud SQL | — | 2h | GCP Cloud SQL instance, apply migrations, update `.env` |

**Phase 1 Outcome:** Real data flowing from DB through Express to Next.js UI.

---

### Phase 2: Auth + Shipper + Orders (Day 2-4)
**Goal:** Fix the 8 phantom DONEs + implement core booking flow

| # | Task | Req IDs | Status Today | Effort | Deliverable |
|---|------|---------|-------------|--------|-------------|
| 2.1 | **Real JWT auth** — sign-up, sign-in, session tokens, MFA stub | AEL-ADM-002 | NOT_STARTED | 4h | `POST /api/auth/signup`, `POST /api/auth/signin`, JWT middleware, bcrypt passwords |
| 2.2 | **Shipment creation** — pickup/dropoff, windows, pieces, weight | AEL-SHP-002 | NOT_STARTED | 4h | `POST /api/shipments` writing to `orders` table, create page component |
| 2.3 | **Stops & address changes** — pre/post-booking | AEL-SHP-003 | NOT_STARTED | 3h | `PUT /api/shipments/:id/stops`, audit log on changes |
| 2.4 | **Prepay flag & payment state** | AEL-SHP-004 | NOT_STARTED | 2h | `payment_status` column, QuickPay eligibility flag |
| 2.5 | **Shipment tracking timeline** | AEL-SHP-005 | NOT_STARTED | 3h | `GET /api/shipments/:id/timeline`, shipper-facing status page |
| 2.6 | **Physical status machine** | AEL-ORD-001 | NOT_STARTED | 4h | Immutable `order_physical_events` INSERT chain, state validation |
| 2.7 | **Financial status machine** | AEL-ORD-002 | NOT_STARTED | 4h | Independent `order_financial_events` INSERT chain |
| 2.8 | **Financial ledger immutability** | AEL-STM-003 | NOT_STARTED | 2h | Enforce NO UPDATE/DELETE rules on `ledger_entries` (migration already has this) |
| 2.9 | **Driver earnings UI** | AEL-FIN-002 | NOT_STARTED | 3h | Driver-facing earnings page showing receivables from `driver_settlements` |

**Phase 2 Outcome:** A real user can sign up, create a shipment, track it, and a driver can see earnings.

---

### Phase 3: TSA & Compliance (Day 4-6)
**Goal:** All 10 TSA requirements + 2 Compliance requirements

| # | Task | Req IDs | Effort | Deliverable |
|---|------|---------|--------|-------------|
| 3.1 | **TSA IAC schema injection** | AEL-TSA-001 | 2h | Add `tsa_iac_number`, `iacssp_doc_url`, `iac_renewal_date` to `tenant_configs` and `organizations` |
| 3.2 | **Tenant-scoped encryption** | AEL-TSA-002 | 3h | `pgcrypto` encryption for TSA columns, GCP Secret Manager key per tenant |
| 3.3 | **READY_FOR_TENDER hard-gate** | AEL-TSA-003 | 2h | Middleware check: if `passenger_air_eligible=true`, require valid IAC + IACSSP + STA |
| 3.4 | **Compliance Vault UI** | AEL-TSA-004 | 3h | Upload IACSSP letters, view IAC renewals, manage TSA certs (page already generated) |
| 3.5 | **KSMS vetting worker** | AEL-TSA-005 | 3h | Background job polling shipper Known Shipper status, auto-block flagged shippers |
| 3.6 | **Driver STA validation on login** | AEL-TSA-006 | 2h | Check `sta_expiry_date >= NOW()` on driver login, hide air-cargo loads if expired |
| 3.7 | **Digital Chain of Custody** | AEL-TSA-007 | 4h | Consent to Search form + biometric signature capture + seal photo upload at pickup |
| 3.8 | **One-click audit export** | AEL-TSA-008 | 3h | `GET /api/compliance/tsa/export` → ZIP (AWB, CTS forms, seal photos) |
| 3.9 | **ComplianceValidator service** | AEL-TSA-009 | 2h | `checkEligibility(shipmentId, driverId, tenantId) → Boolean` |
| 3.10 | **WhiteLabel AWB generator** | AEL-TSA-010 | 3h | Overlay tenant IAC number onto AWB PDF, audit log provider |
| 3.11 | **Broker compliance tracker** | AEL-CMP-001 | 3h | Registration, filings, renewals tracking page + API |
| 3.12 | **Air cargo / IAC tracking** | AEL-CMP-002 | 2h | Document/renewal tracking for air cargo programs |

**Phase 3 Outcome:** Full TSA compliance suite — tenant admins can manage certs, drivers get STA-gated loads, audit exports work.

---

### Phase 4: Promote READY_FOR_REVIEW → DONE (Day 6-9)
**Goal:** The 45 READY_FOR_REVIEW items need test evidence + verifier proof

These split into categories:

#### 4A: Items with implementation + tests (41 items) — need verifier proof only
Run existing tests against real DB, capture evidence, update CANONICAL.md.

```
AEL-DSP-001..005, AEL-DRV-003/004/008, AEL-APP-001..007,
AEL-MCH-002..006, AEL-ORD-003, AEL-FIN-001/003..006,
AEL-MKT-001..002, AEL-CMP-001..002, AEL-PYF-001..002,
AEL-INS-001, AEL-TST-001..002, AEL-QA-001..004,
AEL-DEVOPS-001..002
```

| Sub-task | Count | Effort |
|----------|-------|--------|
| Run Python test suites, capture results | 41 | 2h |
| Run Vitest API tests against real backend | 20+ | 1h |
| Screenshot/video evidence for UI requirements | 15 | 2h |
| Update CANONICAL.md status → DONE | 41 | 1h |

#### 4B: Items with implementation but NO tests (44 items) — need tests written

| Category | Items | Effort |
|----------|-------|--------|
| Partner connectors (PCN-001..010, 014..017) | 15 | 4h |
| Integration (INT-003..005, 010..019) | 12 | 3h |
| DevOps (003..006) | 4 | 1h |
| Driver (DRV-006/007/009) | 3 | 1h |
| Governance/Branding/Web misc | 10 | 2h |

**Phase 4 Outcome:** 86+ items at DONE with real evidence.

---

### Phase 5: BLOCKED Items + Scope Expansion (Day 9-10)
**Goal:** Resolve blocked items and implement scope expansion

| # | Task | Req IDs | Status | Effort | Resolution |
|---|------|---------|--------|--------|------------|
| 5.1 | Cross-border currency (merged into FIN-005) | AEL-FIN-007 | BLOCKED | 0h | Already merged — confirm and close |
| 5.2 | Holland → consolidated into PCN-006 | AEL-PCN-011 | BLOCKED | 0h | Mark DONE (alias) |
| 5.3 | Conway → consolidated into PCN-006 | AEL-PCN-013 | BLOCKED | 0h | Mark DONE (alias) |
| 5.4 | YRC Freight (RETIRED) | AEL-PCN-012 | BLOCKED | 0h | Mark N/A |
| 5.5 | Expanded delivery modes | AEL-SCP-005 | NOT_STARTED | 3h | Add robot/CDL/53ft-semi to vehicle class enum + pricing matrix |

**Phase 5 Outcome:** All BLOCKED items resolved.

---

### Phase 6: Deploy + Polish + Launch Gate (Day 10-12)
**Goal:** Production deployment and launch readiness

| # | Task | Effort | Deliverable |
|---|------|--------|-------------|
| 6.1 | **Cloud Run deployment** — containerize Next.js + Express | 3h | Dockerfile, `cloudbuild-deploy.yaml`, Cloud Run service |
| 6.2 | **Cloud SQL production** — apply all migrations, seed reference data | 2h | Production DB with tenant `american-eagle-logistics` |
| 6.3 | **Domain + SSL** — `app.aelsolutions.com` | 1h | DNS + managed SSL cert |
| 6.4 | **CI/CD pipeline** — GitHub Actions → Cloud Build → Cloud Run | 2h | Automated deploy on merge to main |
| 6.5 | **Email integration** — SendGrid/Mailgun for notifications | 2h | Welcome, dispatch, delivery emails |
| 6.6 | **Payment integration** — Stripe or ACH for settlements | 4h | Real payment processing for QuickPay |
| 6.7 | **E2E tests** — Playwright for critical paths | 4h | Sign-up → book → dispatch → deliver → settle |
| 6.8 | **Security scan** — OWASP ZAP, dependency audit | 2h | Clean security report |
| 6.9 | **CANONICAL.md final audit** — all 160 requirements at DONE | 2h | 100% completion with evidence |

**Phase 6 Outcome:** Production-deployed, tested, and market-ready.

---

## Timeline Summary

```mermaid
gantt
    title AEL Solutions Full Completion Timeline
    dateFormat YYYY-MM-DD
    
    section Phase 1: Foundation Bridge
    PostgreSQL + Express boot       :p1a, 2026-03-14, 1d
    Next.js → Express proxy         :p1b, after p1a, 0.5d
    Cloud SQL deploy                :p1c, after p1b, 0.5d

    section Phase 2: Auth + Shipper + Orders
    Real JWT auth (ADM-002)         :p2a, after p1c, 0.5d
    Shipper flow (SHP-002..005)     :p2b, after p2a, 1.5d
    Order state machines (ORD-001/002) :p2c, after p2b, 1d
    Earnings UI (FIN-002, STM-003)  :p2d, after p2c, 0.5d

    section Phase 3: TSA & Compliance
    TSA schema + encryption (001-002) :p3a, after p2d, 0.5d
    TSA gates + vault (003-004)     :p3b, after p3a, 0.5d
    TSA workers + DCoC (005-007)    :p3c, after p3b, 1d
    Audit export + validator (008-010) :p3d, after p3c, 0.5d
    Compliance (CMP-001/002)        :p3e, after p3d, 0.5d

    section Phase 4: Test Evidence
    Run test suites (41 items)      :p4a, after p3e, 0.5d
    Write missing tests (44 items)  :p4b, after p4a, 1.5d
    Update CANONICAL.md             :p4c, after p4b, 0.5d

    section Phase 5: Blocked Resolution
    Resolve BLOCKED + SCP-005       :p5, after p4c, 0.5d

    section Phase 6: Deploy + Launch
    Cloud Run + Cloud SQL prod      :p6a, after p5, 1d
    CI/CD + Email + Payments        :p6b, after p6a, 1d
    E2E tests + security scan       :p6c, after p6b, 1d
    Final audit → 100%              :p6d, after p6c, 0.5d
```

---

## Requirement Count by Phase

| Phase | Requirements Moved to DONE | Running Total |
|-------|---------------------------|---------------|
| Current | 91 (57% — includes 8 phantoms) | 91/160 |
| Phase 1 (Foundation) | 0 (infrastructure) | 91/160 |
| Phase 2 (Auth + Shipper + Orders) | +9 (SHP-002..005, ORD-001/002, STM-003, FIN-002, ADM-002) | 100/160 |
| Phase 3 (TSA + Compliance) | +12 (TSA-001..010, CMP-001/002) | 112/160 |
| Phase 4 (Evidence + Tests) | +44 (READY_FOR_REVIEW → DONE) | 156/160 |
| Phase 5 (Blocked) | +3 (FIN-007, PCN-011/013 aliases + SCP-005) | 159/160 |
| Phase 6 (Deploy) | +1 (final cleanup) | **160/160** |

---

## Execution Rules

1. **Vertical development** — each requirement gets: code → test → evidence → CANONICAL update in one commit
2. **No phantom DONEs** — every status change backed by file + test + screenshot
3. **Real database** — no demo seed data for DONE status (per AEL-GOV-004)
4. **Commit per requirement** — `feat(AEL-XXX-NNN): <description>` with traceability header
5. **Lessons learned** — update after each phase

---

## Starting Now

> [!TIP]
> Phase 1 is the **highest leverage** — one day of work makes every other phase faster because all 77 API routes already have `BACKEND_URL` proxy code. Once Express is receiving traffic, every subsequent requirement just needs the Express endpoint + DB query.

**Ready to begin Phase 1: Stand up PostgreSQL → boot Express on 8001 → bridge Next.js.**
