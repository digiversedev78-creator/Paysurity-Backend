# GCP Swarm Trigger — Implementation Plan

## Goal

Trigger the GCP Cloud Build worker pool (`ael-mega-factory`) to run all remaining staging prep tasks in parallel, instead of running them sequentially on the local machine.

## Current State

| Item | Status |
|------|--------|
| Worker Pool | `ael-mega-factory` — **RUNNING** ✅ |
| GCP Project | `ael-transport-prod` |
| Region | `us-central1` |
| Git HEAD | `b27f51a` — pushed to `origin/main` ✅ |
| Cloud Build Config | `cloudbuild-swarm-fullstack.yaml` (3 lanes, 10+ workers) |
| Dispatcher Script | `scripts/swarm_dispatch.py` |

## Proposed Changes

### Step 1: Pre-Flight (local)

Add copyright headers + npm audit fix locally, commit + push so the swarm has the latest code.

#### [MODIFY] Source files (batch)
- Add `// © 2026 AEL Solutions LLC. All rights reserved.` header to all `.ts`, `.tsx`, `.js` files
- Run `npm audit fix` for non-breaking vulnerability patches

### Step 2: Trigger Fullstack Swarm

```bash
python scripts/swarm_dispatch.py --mode fullstack
```

This triggers `cloudbuild-swarm-fullstack.yaml` which runs **3 parallel lanes**:

| Lane | Workers | What It Does |
|------|---------|-------------|
| **TypeScript** | `ts-install` → `ts-typecheck` → `ts-unit-tests` → `ts-build` | npm ci, tsc --noEmit, vitest, next build |
| **Python** | 5 workers: Driver, Dispatch, Integration, Finance, Remaining | pytest across all test suites |
| **Integration** | `db-migrate` → `integration-tests` | DB migrations + integration test suite |

Plus: `py-traceability` (validate_traceability.py) and `aggregate-results` (final report).

### Step 3: Monitor

```bash
python scripts/swarm_dispatch.py --monitor BUILD_ID --poll-interval 15
```

The script auto-monitors after triggering. Expected duration: ~5-10 minutes.

## Verification Plan

### Automated (via Cloud Build)
- **TypeScript typecheck**: `npx tsc --noEmit` passes
- **Vitest unit tests**: All 25+ tests pass
- **Python tests**: All 186+ tests pass
- **Next.js build**: Production build succeeds
- **Traceability scan**: All requirements have valid traces

### Manual Verification
1. After swarm completes, check build status: `gcloud builds describe BUILD_ID --project=ael-transport-prod`
2. Download swarm report from GCS: `gsutil cp gs://ael-transport-prod-artifacts/swarm-reports/BUILD_ID/swarm-report.json .`
3. Verify all steps show `SUCCESS` status

> [!IMPORTANT]
> If the swarm fails due to Vertex AI quota or worker pool capacity, we fall back to running locally (which still works fine, just slower).
