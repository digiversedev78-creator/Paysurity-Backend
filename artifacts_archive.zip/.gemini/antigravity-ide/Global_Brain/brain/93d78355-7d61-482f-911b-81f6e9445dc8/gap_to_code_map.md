# UrWay Dispatch — Gap-to-Code Map (Deep Audit)

> **Generated:** 2026-03-14 23:35 CST  
> **Method:** Recursive static analysis of `services/gateway/src/app/services/`  
> **Classification basis:** Active Lines of Logic × DB table row counts

---

## Summary

| Classification | Count | Meaning |
|----------------|-------|---------|
| ✅ **FUNCTIONAL** | **38** | Queries DB tables with >0 rows — proven exercised |
| 🟡 **SKELETON** | **39** | Compiles, has real Supabase queries, but targets empty tables or lacks external API credentials |
| 🔴 **MOCK** | **5** | Returns hardcoded/computed data, no real DB or API interaction |
| 🔧 **UTILITY** | **1** | Helper wrapper (supabase.service.ts) |

**Total: 83 service files | 669KB | ~12,800 logic lines**

---

## ✅ FUNCTIONAL Services (38) — Hit Populated Tables

| # | File | KB | Lines | Tables Hit | External |
|---|------|----|-------|------------|----------|
| 1 | admin.service.ts | 13.7 | 313 | tenants, trips, drivers, driver_profiles | — |
| 2 | advanced-analytics.service.ts | 22.8 | 520 | trips, drivers, tenants, system_metrics | — |
| 3 | background-check.service.ts | 3.7 | 95 | driver_profiles | — |
| 4 | billing-cron.service.ts | 9.5 | 218 | tenants, trips, ledger_entries | — |
| 5 | branding-invoice.service.ts | 7.8 | 173 | tenants, tenant_onboarding | — |
| 6 | compliance.service.ts | 13.5 | 337 | tenants, driver_profiles, driver_identities | — |
| 7 | consent.service.ts | 10.4 | 266 | tenants, riders | — |
| 8 | database.service.ts | 10 | 169 | tenants | — |
| 9 | dispatch.service.ts | 28.5 | 754 | trips, drivers, driver_profiles, riders, ledger_entries | — |
| 10 | dispatch-enhancements.service.ts | 21.9 | 524 | trips, drivers, driver_profiles | — |
| 11 | dispute.service.ts | 17.2 | 439 | trips, tenants | — |
| 12 | distribution.service.ts | 10.8 | 247 | tenants, trips, ledger_entries | — |
| 13 | driver.service.ts | 21.3 | 519 | drivers, driver_profiles, trips, vehicles | — |
| 14 | enhanced-driver.service.ts | 7 | 164 | driver_profiles, driver_identities | — |
| 15 | fraud-detection.service.ts | 20 | 525 | trips, riders, drivers | — |
| 16 | global-monitor.service.ts | 10.5 | 242 | system_metrics | — |
| 17 | heartbeat.service.ts | 4.2 | 88 | driver_profiles | — |
| 18 | identity.service.ts | 3.3 | 76 | driver_identities | — |
| 19 | in-trip-messaging.service.ts | 7.3 | 195 | trips | — |
| 20 | ledger.service.ts | 3.3 | 75 | tenants, ledger_entries | — |
| 21 | marketplace-liquidity.service.ts | 9.4 | 198 | tenants, drivers, trips | — |
| 22 | metrics.service.ts | 4.7 | 108 | trips, drivers, system_metrics | — |
| 23 | notification.service.ts | 10.2 | 247 | tenants, riders | — |
| 24 | ocr-document.service.ts | 8.3 | 170 | driver_profiles | HTTP |
| 25 | offer.service.ts | 12.4 | 303 | trips, driver_profiles, drivers | — |
| 26 | parallel-session.service.ts | 8 | 170 | trips | — |
| 27 | payment.service.ts | 14 | 325 | trips, tenants, ledger_entries | — |
| 28 | payout.service.ts | 22 | 523 | trips, tenants, ledger_entries, driver_profiles | — |
| 29 | pricing.service.ts | 6.2 | 163 | trips | — |
| 30 | qr-attribution.service.ts | 11.2 | 275 | tenant_onboarding | — |
| 31 | referral-distribution.service.ts | 9.6 | 190 | tenant_onboarding, trips, ledger_entries | — |
| 32 | refund.service.ts | 5.4 | 129 | trips, ledger_entries | — |
| 33 | reservations.service.ts | 6.8 | 208 | quotes, trips, riders | — |
| 34 | rider-dispute.service.ts | 6.2 | 164 | trips | — |
| 35 | skinning.service.ts | 5 | 122 | tenants, tenant_onboarding | — |
| 36 | split-pay.service.ts | 5.9 | 157 | trips | — |
| 37 | tax.service.ts | 9.1 | 186 | ledger_entries, driver_profiles, driver_identities | — |
| 38 | tenant.service.ts | 16.3 | 395 | tenants, tenant_onboarding | — |
| + 4 more | tenant-analytics, vip-analytics | — | — | trips, tenants, driver_profiles | — |

---

## 🟡 SKELETON Services (39) — Dispatch Candidates

| # | File | KB | Lines | Gap Type | Target |
|---|------|----|-------|----------|--------|
| 1 | airport-geofence.service.ts | 17.7 | 353 | Empty tables | tenant_airport_geofences, driver_zone_transitions |
| 2 | approval.service.ts | 6.3 | 142 | Empty tables | approval_requests |
| 3 | audit.service.ts | 2.9 | 80 | Empty tables | audit_events |
| 4 | booking-antifraud.service.ts | 4.4 | 111 | Empty tables | booking_velocity_log |
| 5 | circuit-breaker.service.ts | 5.9 | 143 | Empty tables | circuit_breaker_state |
| 6 | config-validator.service.ts | 3.9 | 110 | No DB calls | Utility |
| 7 | corporate-account.service.ts | 10.7 | 263 | Empty tables | corporate_accounts, corporate_employees |
| 8 | data-subject-request.service.ts | 3.6 | 104 | Empty tables | data_subject_requests |
| 9 | disclosure.service.ts | 4.5 | 114 | Empty tables | disclosures |
| 10 | **email.service.ts** | 9.3 | 203 | **No SendGrid key** | External API |
| 11 | env-validation.service.ts | 3.3 | 84 | Empty tables | env_config_audit |
| 12 | events-engine.service.ts | 7.8 | 194 | Empty tables | events, marketplace_ads |
| 13 | faq.service.ts | 6.9 | 188 | Empty tables | faq_categories, faq_articles |
| 14 | feature-gate.service.ts | 3.9 | 100 | Empty tables | feature_gates |
| 15 | fleet-owner.service.ts | 14.3 | 329 | Empty tables | fleet_owners, fleet_vehicles |
| 16 | flight-awareness.service.ts | 5.9 | 153 | Empty tables | flight_cache |
| 17 | **fluidpay.service.ts** | 7 | 204 | **Not E2E tested** | FluidPay API |
| 18 | geozone.service.ts | 8.6 | 213 | Empty tables | geo_zones |
| 19 | hourly-booking.service.ts | 8.2 | 208 | Empty tables | hourly_bookings |
| 20 | job-queue.service.ts | 10 | 189 | Empty tables | job_queue |
| 21 | lead.service.ts | 3.4 | 100 | Empty tables | leads |
| 22 | legal-consent.service.ts | 3.9 | 115 | Empty tables | legal_consents |
| 23 | luxury-standards.service.ts | 3.3 | 85 | Empty tables | driver_luxury_checklists |
| 24 | message-retention.service.ts | 3.6 | 87 | Empty tables | message_retention_config |
| 25 | microsite.service.ts | 6.6 | 164 | Empty tables | tenant_microsites |
| 26 | outbound-webhook.service.ts | 5.7 | 144 | Empty tables | tenant_webhooks |
| 27 | passenger-needs.service.ts | 13.7 | 284 | No DB calls | Utility |
| 28 | platform-terms.service.ts | 6.4 | 144 | Empty tables | platform_terms_acceptances |
| 29 | policy.service.ts | 10.8 | 291 | Empty tables | tenant_policies |
| 30 | pricing-policy.service.ts | 9.5 | 183 | Empty tables | tenant_pricing_policies |
| 31 | **push-notification.service.ts** | 7 | 189 | **No FCM key** | FCM API |
| 32 | rating.service.ts | 5.4 | 140 | Empty tables | trip_ratings |
| 33 | secret-manager.service.ts | 3.1 | 63 | No credentials | GCP Secrets |
| 34 | **sms.service.ts** | 5.7 | 82 | **No Twilio key** | Twilio API |
| 35 | supabase.service.ts | 2 | 49 | Wrapper | — |
| 36 | tenant-api-key.service.ts | 3.3 | 82 | Empty tables | tenant_api_keys |
| 37 | timezone.service.ts | 3 | 79 | Empty tables | tenant_timezone_config |
| 38 | trip-state-machine.ts | 2.8 | 88 | No DB calls | Utility |
| 39 | vehicle-config.service.ts | 9.5 | 249 | Empty tables | tenant_vehicle_configs |

---

## 🔴 MOCK Services (5)

| File | KB | Issue |
|------|----|-------|
| realtime.service.ts | 4.2 | Event emitter — no persistent state |
| s3.service.ts | 5.8 | No AWS credentials |
| voice.service.ts | 3.2 | No voice API integration |
| background-check.service.ts | 3.7 | Queries driver_profiles but classified as background check — no real check API |
| identity.service.ts | 3.3 | Queries driver_identities but no real ID verification API |

---

## 🏗️ GCP Access Verified

| Resource | Status |
|----------|--------|
| **GCP Project** | `paysurity-platform-2026` |
| **Account** | `americaneaglelogsvc@gmail.com` (ACTIVE) |
| **Cloud Run** | ✅ Enabled |
| **Cloud Build** | ✅ Enabled |
| **Artifact Registry** | ✅ Enabled |
| **Container Registry** | ✅ Enabled |
| **GKE** | ✅ Enabled |
| **gcloud CLI** | v558.0.0 |

---

## Worker Pool Dispatch Plan

### Phase 1: Seed Data Workers
Dispatch workers to create SQL seed scripts for the 35 empty tables. Each worker gets:
- Table schema (from migration files)
- Service file that references it (for context on expected data shape)
- Task: Generate realistic seed data (10-50 rows per table)

### Phase 2: External API Workers  
Dispatch workers to configure and test:
- FluidPay end-to-end charge
- SendGrid email send
- Twilio SMS send
- FCM push notification

### Phase 3: Integration Test Workers
Dispatch workers to write E2E tests for each SKELETON service, using the seeded data.
