# 8-Worker Sprint Assignment Table
**Baseline:** 312 / 1343 tests passing (23%) | 1 / 81 suites green  
**Goal:** ≥ 80 / 81 suites green, 80%+ tests passing  
**Method:** Each Builder + Tester pair owns a non-overlapping slice of the 80 failing suites.  
**Anchor:** Every fix uses the surgical pattern proven on `audit.service.ts`:  
1. Read full service implementation  
2. Fix query-chain order in service OR fix terminal mock method in test  
3. Run targeted Jest to confirm green  
4. Commit & push

---

## Pre-Sprint State Analysis

| Layer | Count | Notes |
|-------|:-----:|-------|
| Services (`services/gateway/src/app/services/`) | 128 | All functional, no skeletons |
| Integration tests (`test/swarm/*.spec.ts`) | 81 | 1 passing, 80 failing |
| Supabase migrations (`supabase/migrations/`) | 35 | Applied to Cloud SQL |
| Apps (`apps/`) | 5 | admin-portal, driver-app, driver-app-native, rider-app, rider-app-native |
| Requirements | 695 lines | AUTH, RIDER, DRIVER, ADMIN, ENT, INT, PERF, SEC, DEV, BIZ |

### Root Cause Categories in Failing Tests

| Category | Count | Symptom |
|----------|:-----:|---------|
| **A** – Query-chain order mismatch (`limit` before `eq`) | ~35 suites | `X.eq is not a function` |
| **B** – Wrong terminal resolver method | ~25 suites | `Expected X, received resolved instead of rejected` |
| **C** – Real DB / network calls leaking through | 3 suites | Timeout > 30s (`database`, `data-subject-request`, `outbound-webhook`) |
| **D** – Truncated file (missing closing braces) | ~7 suites | `SyntaxError: Unexpected token '}'` |

---

## 8-Worker Assignment Table

> **Workers 1–4**: Builders (fix service query chains + test mocks)  
> **Workers 5–8**: Testers (run targeted Jest after each Builder fix, validate, commit)  
> **Rule**: Zero file overlap — each suite appears in exactly one row.

| Worker ID | Role | Req IDs Targeted | Target Files (Service → Test) | Testing Strategy |
|:---------:|:----:|:-----------------|:-----------------------------|:----------------|
| **W-1 Builder** | Fix Category A (chain order) Batch 1 | AUTH-001, DRIVER-001, DRIVER-002, DRIVER-003 | `driver.service.ts` → `driver.integration.spec.ts`<br>`consent.service.ts` → `consent.integration.spec.ts`<br>`background-check.service.ts` → `background-check.integration.spec.ts`<br>`compliance.service.ts` → `compliance.integration.spec.ts`<br>`ocr-document.service.ts` → `ocr-document.integration.spec.ts` | Move `limit()` after all `eq()` calls in service; mock terminal = last chained method |
| **W-5 Tester** | Validate W-1 fixes | AUTH-001, DRIVER-001–003 | Same 5 spec files | `npx jest --testPathPattern="driver\|consent\|background-check\|compliance\|ocr-document"` → assert PASS |
| **W-2 Builder** | Fix Category A Batch 2 | RIDER-001, RIDER-002, RIDER-003, RIDER-004 | `dispatch.service.ts` → `dispatch.integration.spec.ts`<br>`pricing.service.ts` → `pricing.integration.spec.ts`<br>`pricing-policy.service.ts` → `pricing-policy.integration.spec.ts`<br>`realtime.service.ts` → `realtime.integration.spec.ts`<br>`trip-state-machine` → `trip-state-machine.integration.spec.ts` | Ingest full service + full test; fix chain order; ensure mock resolvers are terminal |
| **W-6 Tester** | Validate W-2 fixes | RIDER-001–004 | Same 5 spec files | `npx jest --testPathPattern="dispatch\|pricing\|realtime\|trip-state"` → assert PASS |
| **W-3 Builder** | Fix Category B (terminal resolver) + Category D (truncation) | ADMIN-001, ADMIN-002, ADMIN-003, ENT-001, INT-001 | `admin.service.ts` → `admin.integration.spec.ts`<br>`tenant.service.ts` → `tenant.integration.spec.ts`<br>`ledger.service.ts` → `ledger.integration.spec.ts`<br>`payment.service.ts` → `payment.integration.spec.ts`<br>`fluidpay.service.ts` → `fluidpay.integration.spec.ts` | Full Gemini swarm read of both files; fix truncated endings; resolve terminal mock method |
| **W-7 Tester** | Validate W-3 fixes | ADMIN-001–003, ENT-001, INT-001 | Same 5 spec files | `npx jest --testPathPattern="admin\|tenant\|ledger\|payment\|fluidpay"` → assert PASS |
| **W-4 Builder** | Fix Category C (real DB leaks) + remaining | DEV-001 (80% coverage), AUD-001, INT-002, INT-003 | `database.service.ts` → `database.integration.spec.ts`<br>`data-subject-request.service.ts` → `data-subject-request.integration.spec.ts`<br>`outbound-webhook.service.ts` → `outbound-webhook.integration.spec.ts`<br>`disclosure.service.ts` → `disclosure.integration.spec.ts` | Add `jest.mock()` for real network clients inside *each* test file's top; ensure no real I/O escapes. For `database.service.ts`: mock `pg.Pool`. |
| **W-8 Tester** | Validate W-4 fixes + Full Suite Run | DEV-001, AUD-001 | Same 4 spec files + full suite | `npx jest --config jest-swarm.config.ts --passWithNoTests --forceExit` → capture final pass rate, commit result |

---

## Batch 2 Queue (Post-Sprint, W-1–W-4 continue)

After the primary sprint above is validated, these 60+ remaining suites are queued in priority order:

| Priority | Suites | Req Coverage |
|:--------:|--------|-------------|
| 🔴 P1 | `sms`, `email`, `notification`, `push-notification` | INT-003 |
| 🔴 P1 | `payout`, `refund`, `billing-cron`, `distribution` | ADMIN-003, DRIVER-003 |
| 🟡 P2 | `audit`, `env-validation`, `feature-gate`, `config-validator` | AUD-001, DEV-001 |
| 🟡 P2 | `fleet-owner`, `enhanced-driver`, `airport-geofence`, `dispatch-enhancements` | DRIVER-004, DRIVER-005 |
| 🟢 P3 | `voice`, `metrics`, `global-monitor`, `heartbeat` | PERF-001, ARCH-003 |
| 🟢 P3 | `vip-analytics`, `fraud-detection`, `advanced-analytics`, `job-queue` | ADMIN-004, SEC-003 |

---

## Zero-Overlap Guarantee

```
W-1: driver | consent | background-check | compliance | ocr-document
W-2: dispatch | pricing | pricing-policy | realtime | trip-state-machine
W-3: admin | tenant | ledger | payment | fluidpay
W-4: database | data-subject-request | outbound-webhook | disclosure
```

No file appears in more than one worker's scope. ✅

---

## Execution Protocol (per worker)

1. **Read** full service `.ts` + full test `.spec.ts` via Gemini 2.5 Flash API
2. **Identify** the exact failure category (A, B, C, or D)
3. **Apply** minimal surgical fix (service chain reorder OR test mock terminal fix)
4. **Validate** with targeted `npx jest --testPathPattern="<suite>"` 
5. **Commit** with message: `Fix[WN]: <suite> - <root cause>`
6. **Push** to `americaneaglelogsvc/RideShare main`
7. **Report** pass/fail count delta to Tester worker

---

> **Ready for your GO?** Upon approval, I'll fire all 4 Builder workers in parallel with the Tester workers on standby.
