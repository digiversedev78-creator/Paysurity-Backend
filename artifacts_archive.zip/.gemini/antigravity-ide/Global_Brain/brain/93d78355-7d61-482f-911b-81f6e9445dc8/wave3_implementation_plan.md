# Wave 3: Full Scale Production — Implementation Plan

> **Status:** 🟡 IN PROGRESS  
> **Start:** 2026-03-13 12:08 CST  
> **Objective:** Replace ALL mock data with real API calls, wire frontend to backend

---

## Mock Data Inventory

### 🔴 Critical (Blocks Launch)

| App | File | Lines | Mock Type | Priority |
|-----|------|-------|-----------|----------|
| driver-app | `TripPage.tsx` | L69-94, L137-163 | Hardcoded trip offer object + `simulateOffer()` | **P0** |
| driver-app | `api.service.ts` | L198-223 | Mock login fallback | **P0** |
| driver-app | `api.service.ts` | L252-280 | Mock profile fallback | **P0** |
| driver-app | `api.service.ts` | L297-304 | Mock status update | **P0** |
| driver-app | `api.service.ts` | L313-320 | Mock location update | **P0** |
| driver-app | `api.service.ts` | L328-344 | Mock dashboard fallback | **P0** |
| rider-app | `api.service.ts` | L181-229 | Mock vehicle recommendations fallback | **P1** |

### 🟡 Important (Deferred Launch OK)

| App | File | Lines | Mock Type | Priority |
|-----|------|-------|-----------|----------|
| driver-app | `EarningsPage.tsx` | Various | Mock earnings data | **P2** |
| driver-app | `FleetOwnerPage.tsx` | Various | Mock fleet data | **P2** |
| driver-app | `ScheduledRidesPage.tsx` | Various | Mock scheduled rides | **P2** |
| driver-app | `AirportQueuePage.tsx` | Various | Mock queue positions | **P2** |
| driver-app | `MessagingPage.tsx` | Various | Mock messages | **P2** |
| rider-app | `MessagingPage.tsx` | Various | Mock messages | **P2** |
| rider-app | `RideHistoryPage.tsx` | Various | Mock ride history | **P2** |
| rider-app | `ConsentPage.tsx` | Various | Mock consent data | **P3** |
| rider-app | `SupportPage.tsx` | Various | Mock FAQs | **P3** |
| admin-portal | `ops-console/page.tsx` | Various | Mock ops data | **P2** |
| admin-portal | `platform-admin/page.tsx` | Various | Mock admin data | **P2** |

---

## Worker Pool Assignments

### WP-4: Driver App → Real APIs (P0) ✅ DONE
- [x] Replace `TripPage.tsx` mock offers with WebSocket-based real offers from `/dispatch-sse/offers`
- [x] Wire `handleAcceptOffer` → `PUT /dispatch/accept-trip`
- [x] Wire `handleStartTrip` → `PUT /dispatch/start-trip`
- [x] Wire `handleCompleteTrip` → `PUT /dispatch/complete-trip`
- [x] Remove mock login fallback, integrate Supabase Auth
- [x] Wire `getProfile` to `GET /driver/profile` (remove mock fallback)
- [x] Wire `getDashboard` to real driver stats endpoint
- [x] Wire `updateStatus` to `PUT /driver/status`
- [x] Wire `updateLocation` to `POST /driver/location`

### WP-5: Rider App → Real APIs (P1) 🟡 PARTIAL
- [x] Remove mock vehicle recommendations in `processPassengerRequirements`
- [ ] Wire `BookingPage` to use real `dispatchRide` after booking
- [x] Add auth token to rider API service (Supabase JWT)
- [x] Wire `RideHistoryPage` to `GET /rider/trips` (with Supabase fallback)
- [ ] Wire `SupportPage` to `GET /rider/faqs`

### WP-6: Admin Portal → Real APIs (P2)
- [ ] Wire `ops-console` to real tenant analytics
- [ ] Wire `platform-admin` to real platform metrics
- [ ] Wire `owner-console` to real fleet owner data

### WP-7: Auth Layer — Supabase for All Apps ✅ DONE
- [x] Driver app: Supabase `signInWithPassword` + store JWT
- [x] Rider app: Supabase `signInWithPassword` + store JWT
- [ ] Admin portal: Supabase `signInWithPassword` + role check
- [x] Token refresh middleware for all apps (auto-refresh enabled)

### WP-8: Real-time — WebSocket/SSE
- [ ] Driver: SSE stream for new ride offers
- [ ] Rider: SSE stream for trip status updates
- [ ] Driver: Location heartbeat via WebSocket
- [ ] Admin: Real-time ops dashboard

### WP-9: Payment Integration
- [ ] Wire `payment.controller.ts` → FluidPay webhooks
- [ ] Complete fare calculation in `pricing.service.ts`
- [ ] Wire `payout.service.ts` → driver bank transfers

### WP-10: Polish & E2E
- [ ] Loading skeletons for all pages
- [ ] Error boundary components
- [ ] Accessibility audit (ARIA, focus management)
- [ ] Daily Golden Thread E2E run
- [ ] Browser screenshot verification

---

## Execution Order

```
Phase 1 (Now):     WP-4 + WP-7 (Driver real APIs + Auth)
Phase 2 (Next):    WP-5 + WP-8 (Rider real APIs + Real-time)
Phase 3 (Then):    WP-6 + WP-9 (Admin + Payments)
Phase 4 (Final):   WP-10 (Polish + verification)
```
