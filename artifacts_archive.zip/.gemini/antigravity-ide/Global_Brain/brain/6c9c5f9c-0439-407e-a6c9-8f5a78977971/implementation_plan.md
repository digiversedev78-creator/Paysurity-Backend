# Implementation Plan - Fix DriverProfileManagement.py Lint Errors

Address all lint errors identified in `DriverProfileManagement.py` to satisfy Pyre's strict typing requirements.

## Proposed Changes

### [Component Name] DriverProfileManagement.py

#### [MODIFY] [DriverProfileManagement.py](file:///c:/Users/Detaimfc/Downloads/AEL%20Solutions/DriverProfileManagement.py)

- **Fix Dataclass Initialization (Unpacking Errors):**
    - Replace `DriverProfile(**driver_data)` on line 186 with explicit keyword arguments to avoid union type ambiguity.
    - Replace `DriverDocument(..., **doc_data)` on line 238 with explicit keyword arguments.
- **Fix Datetime Type Mismatch:**
    - On line 279, ensure `drivers_license_expiry` is always a `datetime` object. Since it's a required field validated earlier, I will use a direct access and cast or provide a sensible default if the validation logic is bypassed (though it's unlikely here).
- **Fix Enum Iteration:**
    - Use `list(DriverStatus)` and `list(VehicleClass)` on lines 458 and 464 to ensure Pyre sees them as iterable.
- **Fix Rounding Issue:**
    - Use `int(avg_experience * 10 + 0.5) / 10.0` or similar logic to avoid the `round` overload issue on line 481.
- **Fix List Slicing:**
    - Add explicit type annotations to `initial_drivers` (line 554) and `expiring_docs` (line 706) to allow slicing.
- **Fix Null Checks:**
    - Add an `if updated_driver:` check on line 623 to prevent `NoneType` attribute access.
- **Fix Success Rate Calculation:**
    - Fix line 675 to use `bool(doc)` instead of just `doc` so that `doc_success` is a boolean, preventing type pollution of `passed_tests`.

## Verification Plan

### Automated Tests
- Run the internal test harness: `python DriverProfileManagement.py`
- Run the unit tests: `python -m unittest test_AEL_DRV_001.py`

### Manual Verification
- Verify that the lint errors in the IDE are cleared.
