# PaySurity Omni-Channel Platform: Investor Demo Script

**Host:** CEO, PaySurity
**Objective:** Demonstrate the absolute separation of concerns, multi-tenant POS architecture, and live cloud database integration to prospective tenants (House of Biryani, GGrand Tobacco, etc.).

---

## Part 1: The Tenant-Admin Merchant Dashboard
**Visual:** The screen opens on the PaySurity Merchant Login portal.
**Voiceover:** 
> "Welcome to the core of the Merchant experience. What you are about to see is not a generic mockup. We are logging into the exact portal that the owner of House of Biryani uses to manage their POS, Payroll, and Digital Wallets from their phone or back office. Watch closely."

*(The agent types `admin@houseofbiryanirestaurant.com` and signs in. The screen loads the real dashboard.)*

> "Instantly, PaySurity recognizes the unique Tenant footprint. If you look at the left-hand navigation rail, you'll see the exact 'House of Biryani' branding loaded securely from our Google Cloud PostgreSQL cluster."

### Screen Recording: Live Tenant Data Verification
*(The video below physically traces the UI fetching real data from the remote Cloud Database)*

![Tenant Admin Database Trace Demo](file:///C:/Users/ullah/.gemini/antigravity/brain/4aa8c2c5-4b47-4f95-9bfb-3985dee77cc3/tenant_admin_demo_1774295425917.webp)

**Voiceover (Continuing over video):**
> "We navigate directly to the Tenant Settings. Because the system is natively tethered to the cloud, there is zero data-leakage from other tenants. The Business Name, Address, and Phone Number populate flawlessly for *this specific restaurant*. We then click into the Payroll module—instantly rendering active employee wage data. If this was our tobacco retailer, the system mathematically strips out tip-pooling and table-management, replacing it with Age-Gated barcode parsers."

---

## Part 2: The E-Commerce Microsites (Edge Router)
**Visual:** The browser switches tabs to `https://houseofbiryanirestaurant.com`.
**Voiceover:**
> "But the Tenant Admin dashboard is only half the battle. Your customers demand high-fidelity digital storefronts."

*(The screen renders the deep red House of Biryani consumer portal with the full menu.)*

> "This is a live, Server-Side Rendered Next.js portal. Because House of Biryani is an F&B tenant, the Edge Router automatically loads 'Chicken Dum Biryani' and 'Chicken 65' natively. If we change the DNS header and hit this exact same underlying infrastructure as 'GGrand Tobacco Hub'..."

*(The screen flips instantly to a deep blue Tobacco Hub storefront.)*

> "...it instantly pivots to Age-Gated Retail, pulling Marlboro Red Cartons and JUUL hardware. One master codebase. Infinite, isolated storefronts. Completely frictionless for the merchant."

---

## Part 3: The Super Admin Command Center
**Visual:** The screen switches to the PaySurity Admin Terminal (`paysurity-admin-111328865246.us-central1.run.app`).
**Voiceover:**
> "Finally, how do we manage these thousands of isolated merchants? We don't use their dashboard. We use the Super Admin Platform."

*(The screen shows the Global Telemetry and MDM Terminal).*

> "This is the PaySurity control room. From here, our IT sub-admins can securely oversee the health of all 4 tenants simultaneously. If Tawakkul Restaurant's physical POS hardware goes offline, we execute remote MDM terminal commands to globally flash their devices. If a transaction spikes risk metrics, our PayFactor engine isolates the threat here, completely invisible to the restaurants trying to run their lunch rush."

> "End-to-end, Omni-channel, and physically tethered to the Google Cloud."
