# PaySurity: Staging & Market Readiness Execution Plan
**Author:** Unified Leadership & Engineering Team (CEO, CIO, UX Director, Full-Stack Dev)
**Date:** 2026-03-24
**Objective:** Propel PaySurity from a development-stable backend to a visually flawless, data-rich, and heavily vetted staging environment ready for aggressive investor demonstration.

---

## 1. UX & Graphics Translation (The "Wow" Factor)
The fundamental promise of PaySurity is dynamic multi-tenancy. Investors must see this in the UI instantly.
**Tactical Steps:**
*   **Dynamic Theming Provider:** Wrap the `merchant-dashboard` `layout.tsx` with a React Context `ThemeProvider`.
*   **CSS Variable Overrides:** When the system receives the JWT bearing the `tenant_id`, the frontend will apply brand-specific colors (`--ps-accent`, `--ps-bg-card`) directly to the DOM root.
    *   *BistroBeest:* Crimson Red / Slate Navy UI.
    *   *Tawakkul:* Emerald Green / Gold UI.
*   **Impact:** Zero code changes required per client; infinite scalability proven visually within 5 seconds of login.

## 2. Full-Stack Data Seeding (The Illusion of Life)
A dashboard returning `$0.00` kills investor momentum. Staging requires the illusion of an active 7-day business week.
**Tactical Steps:**
*   **Automated Lifecycle Seeder:** We will deploy `apps/api/src/db/seed/demo-seeder.ts`.
*   **Data Profile:** 
    *   Injects 145 highly realistic, time-staggered `pos_engine.orders`.
    *   Mix of "COMPLETED", "PROCESSING", and "REFUNDED" statuses to perfectly map to the UI Pie Chart matrices.
    *   Simulates `crm.customers` creation.
*   **Impact:** The Analytics Dashboard (now wired to raw Drizzle SQL) will natively render rich, dense charts without any manual QA data entry.

## 3. The 8-Domain Verification Matrix (QA Testing Strategy)
Before the link is shared, the Full-Stack Engineering team will dry-run the "Golden Path" to guarantee the Double-Entry Ledger and compliance guardrails hold.
**Tactical Steps:**
*   **The Split-Tender Gauntlet:** Programmatically push a JSON payload split across `Card` and `Gift Card`.
*   **Ledger Verification:** Ensure the `wallets` table does *not* auto-increment (which we patched out in Phase 4). Confirm it correctly logs to the T+1 `settlement_batches` queue.
*   **KDS WebSockets:** Monitor port 4000 to ensure the POS event `order.created` successfully broadcasts the ticket to the kitchen display.
*   **Compliance:** Verify the immutable digital signature is appended to the PCI Audit archive.

## 4. The "Zero-Downtime" Build Audit (CIO Pipeline Check)
Because we aggressively rewired the API (restored 9 orphaned modules, parameterized SQL injections, added Drizzle Analytics queries), we must guarantee Type-Safety before triggering the Vercel/Cloud Run staging pipelines.
**Tactical Steps:**
*   **Local Monorepo Build:** Force `npx tsc --noEmit` and `npm run build` across both the API and the React Dashboard.
*   **Lint Enforcement:** Catch any broken Next.js static generation dependencies or NestJS circular module references.

---
### Execution Phase Initialized
The Next Strategically Aligned Tactical Step is **in motion right now**:
1. Triggering full TypeScript compilation checks against the `apps/api` to verify the new Analytics implementation.
2. Rapidly mapping the Next.js `ThemeProvider` hook for the multi-tenant UI execution.
