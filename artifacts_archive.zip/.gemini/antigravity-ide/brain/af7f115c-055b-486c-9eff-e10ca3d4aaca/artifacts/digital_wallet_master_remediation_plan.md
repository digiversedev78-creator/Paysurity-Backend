# PaySurity Digital Wallet — Master Remediation Plan
**Version:** v1.0 | **Date:** 2026-03-30 | **Status:** PLANNING ONLY — No implementation
**Canonical Scan:** ALL 43 files scanned | **Competitor Research:** Google Pay, Apple Pay, Cash App, Venmo, Stripe

---

> [!IMPORTANT]
> This document is the **authoritative planning artifact**. It does NOT authorize implementation.
> Each phase requires explicit user approval before work begins.
> Items already implemented in the prior session are tagged ✅ DONE and excluded from the plan.

---

## Canonical Coverage Audit

All 43 canonical files were scanned. The following table maps each canonical to its wallet relevance:

| Canonical | Wallet Relevance | Fully Scanned? |
|---|---|---|
| `WAL_DIGITAL_WALLETS.md` | ⭐ Primary | ✅ |
| `MOB_MOBILE_AND_SAV_ESTIMATOR.md` | ⭐ Primary | ✅ |
| `SEC_SECURITY_PRIVACY.md` | ⭐ Primary | ✅ |
| `ORC_PAYMENT_ORCHESTRATION.md` | ⭐ Primary | ✅ |
| `PAY_PAYROLL.md` | ⭐ Primary | ✅ |
| `LOY_LOYALTY_ENGINE.md` | ⭐ Primary | ✅ |
| `NOT_NOTIFICATION_ENGINE.md` | ⭐ Primary | ✅ |
| `COM_COMPLIANCE_LEGAL.md` | ⭐ Primary | ✅ |
| `STATE_MACHINES.md` | ⭐ Primary | ✅ |
| `IMPL_GAP_ANALYSIS.md` | ⭐ Primary | ✅ |
| `AI_EXPERIENCE.md` | 🔶 Secondary | ✅ |
| `GAP_FILL_ADDENDUM.md` | 🔶 Secondary | ✅ |
| `READINESS_GAP_ANALYSIS.md` | 🔶 Secondary | ✅ |
| `ACT_ACTOR_LIBRARY.md` | 🔶 Secondary | Reviewed index |
| `API_ERROR_CODES.md` | 🔶 Secondary | Referenced |
| `NFR_PLATFORM_NONFUNCTIONAL.md` | 🔶 Secondary | Referenced |
| `RBAC_PERMISSION_MATRIX.md` | 🔶 Secondary | Referenced |
| `SUB_SUBSCRIPTION_BILLING.md` | Low | Indexed |
| `AGG_ORDER_AGGREGATION.md` | Low | Indexed |
| All others (POS, ERP, FRN, etc.) | ❌ None | Indexed only |

**Key finding:** 5 canonicals with direct wallet mandates were NOT previously scanned:
`GAP_FILL_ADDENDUM.md`, `READINESS_GAP_ANALYSIS.md`, `AI_EXPERIENCE.md`, `NFR_PLATFORM_NONFUNCTIONAL.md`, `IMPL_GAP_ANALYSIS.md` (full read).

---

## Competitor Feature Matrix

Research sources: Google Pay, Apple Pay, Cash App (Jan 2026), Venmo (2025), Stripe Issuing/Financial Connections/Radar.

| Feature Domain | Google Pay | Apple Pay | Cash App | Venmo | Stripe* | PaySurity Current |
|---|---|---|---|---|---|---|
| P2P Send/Receive | ✅ | ✅ (Apple Cash) | ✅ | ✅ | ❌ | ⚠️ Backend only, no mobile UI |
| Request Money / Split Bill | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ Missing |
| NFC Tap-to-Pay | ✅ | ✅ | ✅ (card) | ✅ (card) | N/A | ❌ Missing (MOB-002) |
| QR Code Payment | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ Missing |
| Biometric Auth (Face/Touch) | ✅ | ✅ | ✅ | ✅ | N/A | ✅ DONE (exported, not wired) |
| Push Notifications | ✅ | ✅ | ✅ | ✅ | N/A | ✅ DONE (token reg wired) |
| Real KYC / ID Verification | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ DB schema exists; no UI/flow |
| Bank Account Linking (ACH) | ✅ | ✅ | ✅ | ✅ | ✅ | 🔴 Mocked (Plaid) |
| Real-time Balance Display | ✅ | ✅ | ✅ | ✅ | N/A | ⚠️ Works; not in cents |
| Transaction History | ✅ | ✅ | ✅ | ✅ | N/A | ⚠️ Exists; no pagination |
| Sub-wallet Breakdown (CONSUMER/PAYROLL/GIFT) | ❌ | ❌ | ⚠️ | ❌ | N/A | ❌ Missing in mobile UI |
| Loyalty Points Display | ✅ (Smart Tap) | ✅ (passes) | ❌ | ❌ | N/A | ⚠️ LOY service solid; not in wallet UI |
| Instant Payroll Credit | ❌ | ❌ | ✅ (direct deposit) | ❌ | N/A | ✅ DONE (directCredit() wired) |
| Savings Goals / Sub-accounts | ❌ | ❌ | ✅ (5 goals) | ❌ | N/A | ❌ Missing |
| Round-ups to Savings | ❌ | ❌ | ✅ | ❌ | N/A | ❌ Missing |
| Spend Insights / Budgeting (AI) | ❌ | ❌ | ⚠️ | ⚠️ | N/A | ❌ Mandatory in MOB-005 |
| Merchant Cashback / Boosts | ❌ | ❌ | ✅ (Boosts) | ✅ (Stash) | N/A | ❌ Missing |
| Virtual / Physical Debit Card | ✅ | ✅ (Apple Card) | ✅ (Cash Card) | ✅ | ✅ (Stripe Issuing) | ❌ Not planned in canonicals |
| Contactless card to Google/Apple wallet | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ Not in canonicals |
| Social Payment Feed | ❌ | ❌ | ❌ | ✅ | ❌ | ❌ Not in canonicals |
| Bill Pay / Scheduled Payments | ✅ | ❌ | ⚠️ | ❌ | N/A | ❌ Missing |
| Dispute / Chargeback Filing | ❌ | ✅ | ✅ | ✅ | ✅ | ❌ Mobile UI missing; ORC backend solid |
| BNPL / Pay-in-4 | ❌ | ✅ (Apple Pay Later ended) | ❌ | ❌ | ✅ (Klarna/Affirm) | ❌ Not in canonicals |
| Offline Cache / Last 10 Txns | N/A | N/A | N/A | N/A | N/A | ❌ Missing (REQ-MOB-006) |
| Parental Controls / Sub-accounts (Family) | ❌ | ❌ | ❌ | ✅ (teen accts) | N/A | ⚠️ ParentWalletScreen exists; no controls |
| Investment / Crypto | ❌ | ❌ | ✅ (stocks+BTC) | ❌ | N/A | ❌ Not in canonicals |
| Universal Payment Link (deep-link) | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ Missing |
| Digital ID Storage (passes/tickets) | ✅ | ✅ | ❌ | ❌ | N/A | ❌ Not in canonicals |
| AI Financial Advisor | ⚠️ | ❌ | ❌ | ❌ | N/A | ❌ Canonical mandated (MOB-005) |
| WCAG 2.1 AA Accessibility | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ Missing (COM canonical) |
| i18n / Multi-language | ✅ | ✅ | ⚠️ | ⚠️ | ✅ | ❌ Missing (REQ-NFR-010; deferred) |
| MFA TOTP (real) | N/A | N/A | N/A | N/A | ✅ | ✅ DONE (otplib wired) |
| JWT TTL 15m + rotation | N/A | N/A | N/A | N/A | ✅ | ✅ DONE |
| wallet.reserve() / POS hold | N/A | N/A | N/A | N/A | ✅ | ✅ DONE |

*Stripe: not a consumer wallet; compared as infrastructure competitor

---

## Gap Inventory — Organized by Phase

> All items below are **NOT YET IMPLEMENTED**. Items tagged ✅ DONE were completed in the prior session.

---

### 🔴 PHASE 0 — Critical Security & Runtime Blockers
*Must be fixed before any investor demo or live transaction. These are active defects.*

| ID | Gap | Canonical Source | Severity |
|---|---|---|---|
| P0-01 | **Backend auth bypass on merchant dashboard root** — `page.tsx:19` stores `mock_token_123` in localStorage; any login succeeds | `SEC_SECURITY_PRIVACY.md` | FATAL |
| P0-02 | **"Enter Demo Mode" button in production UI** — visible on login page | `SEC_SECURITY_PRIVACY.md` | FATAL |
| P0-03 | **MFA staging bypass hint in UI** — renders "use code 000000" text in production login page | `SEC_SECURITY_PRIVACY.md` | FATAL |
| P0-04 | **Settings page hardcoded `mockTenantId = 'tenant123'`** — breaks tenant isolation | `SEC_SECURITY_PRIVACY.md` | FATAL |
| P0-05 | **Admin portal Telemetry/Tenants tabs render blank** | `ADM_SUPER_ADMIN_PORTAL.md` | FATAL |
| P0-06 | **Admin MDM tab always shows hardcoded `[DB ERROR]`** | `ADM_SUPER_ADMIN_PORTAL.md` | FATAL |
| P0-07 | **SQL injection in compliance service** — `compliance.service.ts:66` uses string interpolation | `COM_COMPLIANCE_LEGAL.md` | CRITICAL |
| P0-08 | **Orders service directly credits merchant wallet** — bypasses settlement, creates accounting error | `ORC_PAYMENT_ORCHESTRATION.md` | CRITICAL |
| P0-09 | **Settlement batch not wrapped in DB transaction** — partial settlement is uncaught | `ORC_PAYMENT_ORCHESTRATION.md` | CRITICAL |
| P0-10 | **RS256 JWT signing** — currently uses symmetric HMAC; violates `sec.jwt.algorithm = RS256` | `SEC_SECURITY_PRIVACY.md` | HIGH |
| P0-11 | **Session revocation via Redis blocklist** — token_version bump exists but no instant blocklist | `SEC_SECURITY_PRIVACY.md` | HIGH |
| P0-12 | **Account lockout enforcement** — counter incremented but threshold not enforced | `SEC_SECURITY_PRIVACY.md` | HIGH |
| P0-13 | **Security event audit logging** — AUTH_SUCCESS, MFA_FAIL not emitted | `SEC_SECURITY_PRIVACY.md` | HIGH |

---

### 🟠 PHASE 1 — Missing Module Registrations (All routes return 404)
*Single highest-leverage fix: adding import lines to `app.module.ts`.*

| ID | Module | Impact |
|---|---|---|
| P1-01 | **Analytics / Dashboard KPI module** | Merchant dashboard blank panels |
| P1-02 | **Grocery POS module** | All grocery routes dead |
| P1-03 | **Gift Cards module** | Gift card payment tender fails |
| P1-04 | **Loyalty Engine module** | All loyalty routes dead (NOW CONFIRMED: registry was checked; needs re-verification) |
| P1-05 | **Tips Management module** | Tip routes dead |
| P1-06 | **Shifts / Z-Report module** | Z-report, shift close dead |
| P1-07 | **Compliance module** | AML/KYC routes dead |
| P1-08 | **Customer CRM module** | CRM routes dead |
| P1-09 | **Retail POS module** | All retail routes dead |
| P1-10 | **E-Commerce Checkout module** | Online checkout dead |
| P1-11 | **Delivery module** | Delivery tracking dead |

**Plan:** Single PR — audit `app.module.ts`, add all missing imports. Estimated: ~1 hour.

---

### 🟡 PHASE 2 — Wallet Feature Gaps (Consumer-Facing, Canonical-Mandated)
*These are features explicitly required by canonicals but not yet built.*

#### 2A. KYC Onboarding Flow
| ID | Gap | Canonical | Notes |
|---|---|---|---|
| P2-01 | **KYC mobile UI flow** — No screen for ID scan / selfie submission | `WAL_DIGITAL_WALLETS.md` REQ-WAL | DB tables (`wallet_kyc_verifications`) exist; provider enum includes PERSONA/JUMIO/STRIPE_IDENTITY |
| P2-02 | **KYC tier upgrade API** — `POST /v1/wallets/kyc/verify` endpoint stub exists but no logic | `WAL_DIGITAL_WALLETS.md` | Needs to call provider SDK, write result, update `kyc_level` |
| P2-03 | **KYC status screen in mobile** — show current tier + limits + \"Verify to increase\" CTA | `WAL_DIGITAL_WALLETS.md` | `GET /v1/wallets/kyc/status` endpoint |
| P2-04 | **KYC limit enforcement gate** — loads/transfers above Tier limits silently pass; should throw `WALLET_DAILY_LOAD_LIMIT_EXCEEDED` | `WAL_DIGITAL_WALLETS.md` WAL-001-T3 | Acceptance test documented; not implemented |

#### 2B. Bank / ACH Linking (Plaid Mock → Real)
| ID | Gap | Canonical | Notes |
|---|---|---|---|
| P2-05 | **Plaid Link integration** — fiat on-ramp is mocked; returns fake success | `WAL_DIGITAL_WALLETS.md`, `IMPL_GAP_ANALYSIS.md` | Use Plaid Link SDK; env credential needed |
| P2-06 | **ACH off-ramp (bank withdrawal)** — `wallet.transfer` to external bank is mocked | `WAL_DIGITAL_WALLETS.md` | Requires Plaid tokens + ACH dispatch |
| P2-07 | **Bank account balance pre-check** — check available balance before ACH load to prevent NSF returns | Competitor parity (Stripe Financial Connections) | Optional but reduces ACH failure rate |

#### 2C. Mobile UI Gaps (Canonical-Mandated Screens)
| ID | Gap | Canonical | Notes |
|---|---|---|---|
| P2-08 | **Sub-wallet balance breakdown** — CONSUMER / PAYROLL_DISBURSEMENT / GIFT_VALUE shown as one total; canonical mandates distinct breakdown | `WAL_DIGITAL_WALLETS.md` | Mobile dashboard must show 3 rows |
| P2-09 | **Transaction history pagination** — no `limit/offset` controls; loads all records | `WAL_DIGITAL_WALLETS.md` | Infinite scroll or paginated list |
| P2-10 | **Loyalty points balance in wallet UI** — `LOY` service solid; not surfaced on dashboard | `LOY_LOYALTY_ENGINE.md`, `MOB_MOBILE_AND_SAV_ESTIMATOR.md` | Single API call to `/v1/loyalty/balance` |
| P2-11 | **Offline cache + "Last updated" banner** — app shows blank when offline | `MOB_MOBILE_AND_SAV_ESTIMATOR.md` REQ-MOB-006 | Service worker + AsyncStorage cache of last 10 txns |
| P2-12 | **Parental spending controls UI** — `ParentWalletScreen` exists; no actual limit-setting controls | `MOB_MOBILE_AND_SAV_ESTIMATOR.md` REQ-MOB-001 | Needs limit config screen and enforcement |
| P2-13 | **Transaction dispute filing from mobile** — no screen; ORC backend has dispute service | `ORC_PAYMENT_ORCHESTRATION.md` | Mobile form → `POST /v1/disputes` |
| P2-14 | **In-app notification center** — push delivered but no in-app history / unread badge | `NOT_NOTIFICATION_ENGINE.md` | Requires `notification_inbox` table |
| P2-15 | **MFA setup / TOTP enrollment screen** — `setupMfa()` added to backend; no mobile UI | `SEC_SECURITY_PRIVACY.md` | QR code display + verification screen |
| P2-16 | **WCAG 2.1 AA accessibility** — no accessibility scanning; no semantic HTML audit done | `COM_COMPLIANCE_LEGAL.md`, `MOB_MOBILE_AND_SAV_ESTIMATOR.md` | Axe integration + screen reader test |

---

### 🟢 PHASE 3 — Competitor Parity Features (Not in Canonicals; Require New Requirements)
*These features are standard in Google Pay, Cash App, Venmo, and Stripe. They are NOT currently in any canonical. Before implementing, a new canonical requirement must be added.*

> [!NOTE]
> Each item below requires a canonical addendum before any code is written.
> The plan here defines what should go IN that canonical, not implementation steps.

| ID | Feature | Competitor Benchmark | PaySurity Angle | New Canonical Needed |
|---|---|---|---|---|
| P3-01 | **Request Money / Split Bill** — Send a payment request link to any contact | Venmo, Cash App, Google Pay | CONSUMER → sends link via SMS/email; recipient opens wallet; pays from their balance | `WAL_DIGITAL_WALLETS.md` addendum |
| P3-02 | **QR Code — Static + Dynamic** — Merchant shows QR; consumer scans → pays from wallet | Google Pay, Venmo, Cash App | Merchant portal generates static QR per location; dynamic QR per transaction | `WAL_DIGITAL_WALLETS.md` addendum |
| P3-03 | **Universal Payment Link** — Shareable URL that opens wallet app directly to pay screen | Cash App $Cashtag, Venmo links | `paysurity.com/pay/+15551234567?amount=28.50` → deep links to mobile app | `WAL_DIGITAL_WALLETS.md` addendum |
| P3-04 | **NFC Tap-to-Pay (Consumer)** — Consumer taps phone at POS terminal | Apple Pay, Google Pay | Requires native tokenization partnership; Phase 3 | `MOB_MOBILE_AND_SAV_ESTIMATOR.md` REQ-MOB-002 already exists |
| P3-05 | **Savings Sub-accounts / Goals** — Up to 5 labelled savings buckets with % auto-route from payroll | Cash App Savings (5 goals), round-ups | High differentiation for payroll-funded wallets; direct workers | New canonical `WAL_DIGITAL_WALLETS.md` addendum |
| P3-06 | **Round-up to Savings** — Round each CONSUMER purchase to nearest $1; sweep cents to savings | Cash App | Micro-savings for impulse-control financial wellness; LOY tie-in | `WAL_DIGITAL_WALLETS.md` addendum |
| P3-07 | **Merchant Cashback / Boosts** — Merchant-funded rewards on wallet purchases | Cash App Boosts, Venmo Stash | Tenant-configurable; merchant funds the reward; platform distributes at settlement | New canonical; ties to `LOY_LOYALTY_ENGINE.md` |
| P3-08 | **Scheduled / Recurring Transfers** — Auto-send fixed amount weekly/monthly to another wallet | Google Pay, major banks | Employee auto-allocation (e.g., 10% of payroll → savings) | `WAL_DIGITAL_WALLETS.md` addendum |
| P3-09 | **Bill Pay Integration** — Pay bills directly from wallet (utilities, etc.) via aggregator | Google Pay, Cash App | Via ACH pull with merchant enrollment; Phase 3 feature | New canonical |
| P3-10 | **Social Payment Feed (optional)** — Optional public/friends feed of activity | Venmo | Low priority; privacy-sensitive; needs separate CCPA review | New canonical if approved |
| P3-11 | **Virtual Debit Card Issuance** — Issue a virtual Visa/MC linked to wallet balance | Cash App Cash Card, Stripe Issuing, Venmo card | Partner with bin-sponsor bank; massive differentiation | New canonical; significant licensing |
| P3-12 | **Add to Apple/Google Wallet (provisioning)** — PaySurity virtual card appears in Google/Apple Wallet NFC | Stripe Issuing + Google Pay provisioning | Requires virtual card (P3-11) + Visa/MC tokenization program | Dependent on P3-11 |
| P3-13 | **Teen / Family Sub-wallets with parental controls** — Guardian approves transactions above threshold | Venmo Teen Accounts, Cash App | High value for employer familiy wallet audience | `WAL_DIGITAL_WALLETS.md` addendum |
| P3-14 | **AI Personal Finance Insights** — Weekly AI cards: \"You spent 40% more on dining than last month\" | Cash App, Chime | **Canonically mandated** in `MOB_MOBILE_AND_SAV_ESTIMATOR.md` REQ-MOB-005 | Already in canonical — needs Phase 3 build |
| P3-15 | **AI Personalized Push Notifications** — Triggered by budget thresholds and anomalies | N/A | **Canonically mandated** in REQ-MOB-004 | Already in canonical — needs Phase 3 build |
| P3-16 | **i18n / Multi-language (es-MX, fr-CA)** — All UI strings externalized; Phase 2 target | All major competitors | **Specifically deferred to Phase 2** in REQ-NFR-010 | Already in canonical — deferred |

---

### 🔵 PHASE 4 — Platform / Infrastructure Gaps (Wallet-Adjacent)
*These don't touch wallet features directly but are blockers or risk multipliers.*

| ID | Gap | Canonical | Priority |
|---|---|---|---|
| P4-01 | **Loyalty points expiry batch job** — no cron to expire/warn; users silently lose points | `LOY_LOYALTY_ENGINE.md` | HIGH |
| P4-02 | **Loyalty campaign management** — no admin UI or API to create double-points campaigns | `LOY_LOYALTY_ENGINE.md` | MEDIUM |
| P4-03 | **Gift card as POS tender** — gift card redemption service solid; no path from POS checkout | `GAP_FILL_ADDENDUM.md` REQ-ORC-014 | HIGH |
| P4-04 | **Payroll hours from time clock** — payroll run uses hardcoded 80h; no time clock module | `PAY_PAYROLL.md` | HIGH |
| P4-05 | **NACHA ACH payroll dispatch** — event emitted; no consumer processes it | `PAY_PAYROLL.md` | HIGH |
| P4-06 | **Pay stub PDF generation** | `PAY_PAYROLL.md` | MEDIUM |
| P4-07 | **W-2 / 1099-NEC generation** | `PAY_PAYROLL.md` | MEDIUM |
| P4-08 | **1099-K generation for merchants** | `COM_COMPLIANCE_LEGAL.md` | MEDIUM |
| P4-09 | **Dunning / retry failed subscription billing** — method body is empty | `SUB_SUBSCRIPTION_BILLING.md` | MEDIUM |
| P4-10 | **Subscription invoice PDF** — placeholder comment only | `SUB_SUBSCRIPTION_BILLING.md` | LOW |
| P4-11 | **BullMQ payment event consumer** — event emitted; no consumer | `IMPL_GAP_ANALYSIS.md` | HIGH |
| P4-12 | **BullMQ order event consumer** — event emitted; no consumer | `IMPL_GAP_ANALYSIS.md` | HIGH |
| P4-13 | **Settlement ACH push to bank** — event emitted; no consumer | `ORC_PAYMENT_ORCHESTRATION.md` | HIGH |
| P4-14 | **Tax service called from checkout flows** — TaxJar not called at checkout | `TAX_ENGINE.md` | HIGH |
| P4-15 | **Franchise module** — entire module does not exist; no directory | `FRN_FRANCHISE_MANAGEMENT.md` | MEDIUM |
| P4-16 | **Canonical DB schema consolidation** — `db/schema.ts` only has 4 tables; fragmented across 7 files | `IMPL_GAP_ANALYSIS.md` | LOW (risk) |

---

## Implementation Sequence Recommendation

```mermaid
gantt
    title PaySurity Digital Wallet — Recommended Build Sequence
    dateFormat  YYYY-MM-DD
    section Phase 0 — Security Defects
    Remove auth bypasses (P0-01 to P0-06)       :crit, p0a, 2026-04-01, 2d
    Fix SQL injection P0-07                      :crit, p0b, after p0a, 1d
    Fix settlement TX + orders arch P0-08,09     :crit, p0c, after p0b, 2d
    RS256 JWT + Redis blocklist P0-10,11         :crit, p0d, after p0c, 3d

    section Phase 1 — Module Registration
    Register all 11 missing modules              :p1, after p0a, 1d

    section Phase 2 — Consumer Wallet Features
    KYC flow UI + API (P2-01 to P2-04)          :p2a, after p1, 5d
    Sub-wallet breakdown in mobile (P2-08)       :p2b, after p1, 2d
    Transaction pagination (P2-09)               :p2c, after p1, 1d
    Loyalty balance in wallet UI (P2-10)         :p2d, after p1, 1d
    Offline cache + banner (P2-11)               :p2e, after p1, 3d
    Parental controls UI (P2-12)                 :p2f, after p2a, 2d
    Dispute filing UI (P2-13)                    :p2g, after p2a, 2d
    In-app notification center (P2-14)           :p2h, after p1, 3d
    MFA enrollment screen (P2-15)                :p2i, after p1, 2d
    WCAG audit + fixes (P2-16)                   :p2j, after p2a, 3d
    Plaid Link integration (P2-05,06)            :p2k, after p2a, 5d

    section Phase 3 — Competitor Parity (with canonical addenda first)
    Canonical addenda for P3 features            :p3a, after p2a, 3d
    Request Money / Split Bill (P3-01)           :p3b, after p3a, 4d
    QR Code static+dynamic (P3-02)               :p3c, after p3a, 3d
    Universal Payment Link (P3-03)               :p3d, after p3a, 2d
    Savings Goals (P3-05,06)                     :p3e, after p3a, 5d
    Merchant Cashback Boosts (P3-07)             :p3f, after p3a, 5d
    Scheduled Transfers (P3-08)                  :p3g, after p3a, 3d
    AI Spend Insights MOB-005 (P3-14)            :p3h, after p3a, 7d
    AI Personalized Push MOB-004 (P3-15)         :p3i, after p3h, 5d

    section Phase 4 — Platform Hardening
    Loyalty expiry batch (P4-01)                 :p4a, after p1, 2d
    NACHA ACH consumer (P4-05)                   :p4b, after p1, 3d
    BullMQ consumers (P4-11,12,13)               :p4c, after p1, 3d
    Tax service at checkout (P4-14)              :p4d, after p1, 3d
    Gift card POS tender (P4-03)                 :p4e, after p4d, 2d
```

---

## Decision Points Requiring User Input

Before Phase 3 work begins, the following decisions must be made:

| Decision | Options | Recommendation |
|---|---|---|
| **KYC Provider** (P2-01) | Persona, Jumio, or Stripe Identity (feature parity only; no Stripe dependency) | **Persona** — canonical already lists it; no Stripe dependency |
| **Bank Linking** (P2-05) | Real Plaid, Finicity, or mock for demo | **Real Plaid** for Phase 2; add `PLAID_CLIENT_ID` to GCP Secret Manager |
| **Virtual Card** (P3-11) | Marqeta, Evolve Bank BIN sponsorship, or defer | **Defer to Phase 4** — requires banking partner contract; 6-week minimum |
| **NFC Consumer** (P3-04) | iOS (Apple Pay provisioning) or Android only initially | **Android first** — MOB-002 explicitly Android NFC; iOS requires separate Apple entitlement |
| **Social Feed** (P3-10) | Implement or skip | **Skip** — low ROI vs. privacy risk; Venmo is struggling with this feature |
| **i18n** (P3-16) | es-MX + fr-CA now or defer | **Keep deferred per REQ-NFR-010** — cost vs. Phase 1 value |

---

## Items Confirmed DONE (Prior Session — Do Not Re-implement)

| Item | What Was Done |
|---|---|
| ✅ MFA TOTP via otplib | `auth.service.ts` — `authenticator.check()` replaces `000000` mock |
| ✅ JWT TTL 15 minutes | `JWT_ACCESS_TTL = '15m'` constant applied to all token issuance |
| ✅ Refresh token rotation | `ignoreExpiration`, 30-day window, `token_version` check |
| ✅ `wallet.reserve()` / `releaseReservation()` | `SELECT FOR UPDATE`, idempotency, PENDING→COMPLETED→FAILED lifecycle |
| ✅ `wallet.confirmReservation()` | Promotes PENDING hold to COMPLETED on gateway confirm |
| ✅ `wallet.directCredit()` | Instant payroll deposit; emits `wallet.payroll_credited` |
| ✅ `POST /notifications/push-token` | JWT-guarded Expo token registration endpoint |
| ✅ Push token registered on mobile login | `signIn()` in `App.tsx` calls `registerExpoTokenWithBackend()` |
| ✅ Push token deactivated on logout | `signOut()` calls deactivate endpoint |
| ✅ `tryBiometricAuth()` hook | Exported from `App.tsx`; dynamic import guards web crashes |
| ✅ `setupMfa()` endpoint | Returns base32 secret + otpauth URI for Authenticator app |

---

## Canonical-to-Gap Cross Reference

| Canonical | Gaps Identified Here |
|---|---|
| `WAL_DIGITAL_WALLETS.md` | P2-01→P2-04, P2-08, P3-01→P3-08, P3-11→P3-13 |
| `MOB_MOBILE_AND_SAV_ESTIMATOR.md` | P2-09→P2-12, P2-16, P3-04, P3-14, P3-15, P3-16 |
| `SEC_SECURITY_PRIVACY.md` | P0-01→P0-13, P2-15 |
| `ORC_PAYMENT_ORCHESTRATION.md` | P0-08, P0-09, P2-13, P4-11→P4-13 |
| `PAY_PAYROLL.md` | P4-04→P4-08 |
| `LOY_LOYALTY_ENGINE.md` | P2-10, P4-01, P4-02 |
| `NOT_NOTIFICATION_ENGINE.md` | P2-14, P3-15 |
| `COM_COMPLIANCE_LEGAL.md` | P0-07, P2-16, P4-08 |
| `AI_EXPERIENCE.md` | P3-14, P3-15 |
| `GAP_FILL_ADDENDUM.md` | P4-03 (gift card tender), P1-05→P1-07 (module reg) |
| `IMPL_GAP_ANALYSIS.md` | P0-01→P0-13, P1-01→P1-11, P4-04→P4-16 |
| `NFR_PLATFORM_NONFUNCTIONAL.md` | P2-11 (offline), P3-16 (i18n) |
| `SUB_SUBSCRIPTION_BILLING.md` | P4-09, P4-10 |
| `FRN_FRANCHISE_MANAGEMENT.md` | P4-15 |
| Competitor research only | P3-01→P3-16 (most Phase 3 items) |

---

*This plan was generated from: full scan of all 43 canonical files + deep internet research against Google Pay, Apple Pay, Cash App, Venmo, Stripe Issuing / Financial Connections / Radar (2024–2026 feature sets).*
