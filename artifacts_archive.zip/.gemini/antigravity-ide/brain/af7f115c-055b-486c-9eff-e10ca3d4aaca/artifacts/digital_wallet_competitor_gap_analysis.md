# PaySurity Digital Wallet — Comprehensive Gap Analysis
**Scope:** All wallet-related canonical requirements vs. mobile implementation vs. industry benchmarks  
**Canonicals Audited:** WAL · MOB · ORC · LOY · NOT · PAY · SEC · COM · STATE_MACHINES · IMPL_GAP_ANALYSIS  
**Benchmarks:** Cash App · Venmo · Google Pay · Samsung Pay  
**Date:** 2026-03-30  

---

> [!IMPORTANT]
> The first gap analysis only read **WAL_DIGITAL_WALLETS.md**. This document now also incorporates findings from **9 additional canonicals** that all have direct wallet dependencies, revealing a significantly deeper set of gaps than previously reported.

---

## Canonical Coverage Matrix

| Canonical | Wallet-Relevant? | Previously Audited? | Gaps Found? |
|---|---|---|---|
| WAL_DIGITAL_WALLETS | ✅ Primary | ✅ Yes | ✅ Yes |
| MOB_MOBILE_AND_SAV_ESTIMATOR | ✅ Defines mobile app specs | ❌ **Missed** | ✅ Yes — major |
| ORC_PAYMENT_ORCHESTRATION | ✅ Wallet as a payment method | ❌ **Missed** | ✅ Yes — major |
| LOY_LOYALTY_ENGINE | ✅ Wallet linkage required | ❌ **Missed** | ✅ Yes |
| PAY_PAYROLL | ✅ Instant wallet credit | ❌ **Missed** | ✅ Yes |
| NOT_NOTIFICATION_ENGINE | ✅ All wallet push alerts | ❌ **Missed** | ✅ Yes |
| SEC_SECURITY_PRIVACY | ✅ Biometric, MFA, tokens | ❌ **Missed** | ✅ Yes — critical |
| COM_COMPLIANCE_LEGAL | ✅ CCPA, WCAG, PCI scope | ❌ **Missed** | ✅ Yes |
| STATE_MACHINES | ✅ Wallet lifecycle states | ❌ **Missed** | ✅ Yes |
| IMPL_GAP_ANALYSIS | ✅ Runtime gaps audit | ❌ **Missed** | ✅ Yes — systemic |

---

## GAP TIER CLASSIFICATION

| Tier | Label | Definition |
|---|---|---|
| 🔴 P0 | **Critical Blocker** | Security/financial correctness failure. Must be fixed before any live transaction. |
| 🟠 P1 | **Major Feature Gap** | Canonical says MUST, mobile app is missing entirely. Blocks parity with competitors. |
| 🟡 P2 | **Competitor Parity Gap** | Not in canonical but standard in Cash App/Venmo/Google Pay. Required for market adoption. |
| 🔵 P3 | **Enhancement** | Canonical says SHOULD, or competitor-differentiating feature. |

---

## SECTION 1 — Security & Authentication Gaps 🔴 CRITICAL

> [!CAUTION]
> **SEC canonical** mandates RS256 JWT signing, biometric enforcement, TOTP MFA, and session security. Our mobile app uses `DEMO_TOKEN` (now removed), but underlying backend `auth.service.ts` still has **fatal gaps** documented in `IMPL_GAP_ANALYSIS.md`.

| Gap ID | Description | Canonical Reference | Mobile Status | Severity |
|---|---|---|---|---|
| **SEC-G1** | JWT uses symmetric HMAC, not RS256 as mandated | `SEC: sec.jwt.algorithm = RS256` | AuthContext passes token, backend signs wrong | 🔴 P0 |
| **SEC-G2** | MFA TOTP accepts ANY code except `000000` — backend mock never replaced | `SEC: REQ-SEC-001 verifyMFA()` | Mobile MFA screen exists; backend fake | 🔴 P0 |
| **SEC-G3** | No refresh token rotation — same token is re-signed on refresh | `SEC: refresh(refreshToken)` | Mobile silently falls back to no rotation | 🔴 P0 |
| **SEC-G4** | Access token TTL is 8 hours, spec mandates 15 minutes | `sec.jwt.access_token_ttl_sec = 900` | Mobile holds stale token for 8h | 🔴 P0 |
| **SEC-G5** | Biometric authentication not implemented | `MOB: REQ-MOB-001 — Face ID / Touch ID` | No `expo-local-authentication` integration | 🟠 P1 |
| **SEC-G6** | Transfers >$500 require MFA step-up; mobile has no such enforcement | `WAL: /v1/wallets/{id}/transfer — MFA for >$500` | Single factor only | 🟠 P1 |
| **SEC-G7** | No session revocation / "Sign out of all devices" screen | `SEC: /v1/auth/logout-all` | Not exposed in mobile UI | 🟡 P2 |

---

## SECTION 2 — Wallet Lifecycle & State Machine Gaps 🟠 MAJOR

> [!WARNING]
> **WAL canonical** defines 4 wallet states (`PENDING_ACTIVATION`, `ACTIVE`, `FROZEN`, `CLOSED`). **STATE_MACHINES.md** defines transitions and who can trigger them. None of this lifecycle is surfaced in the mobile app.

| Gap ID | Description | Canonical Reference | Mobile Status | Severity |
|---|---|---|---|---|
| **WAL-G1** | Wallet `FROZEN` state has zero UI representation — user can't see or react if their wallet is frozen | `WAL: status CHECK (FROZEN)` | Not handled; balance screen would just error | 🟠 P1 |
| **WAL-G2** | `wallet.reserve()` and `wallet.releaseReservation()` not wired — POS payments don't hold funds | `WAL: reserve() / releaseReservation()` | Backend gap annotated in IMPL_GAP_ANALYSIS | 🔴 P0 |
| **WAL-G3** | `PENDING_ACTIVATION` state — new wallet created by payroll gets no mobile onboarding prompt | `WAL: status PENDING_ACTIVATION` | No activation flow in mobile | 🟠 P1 |
| **WAL-G4** | `wallet.kyc_level` field (NONE/TIER1/TIER2/FULL) not visible to the user | `WAL: kyc_level column` | Spend limits enforced silently with no user context | 🟠 P1 |
| **WAL-G5** | No "Wallet Health" or status screen — user has no knowledge of their wallet's current administrative state | All WAL + STATE_MACHINES | Not implemented | 🟡 P2 |

---

## SECTION 3 — KYC & Identity Verification Gaps 🟠 MAJOR

> [!WARNING]
> **WAL canonical** explicitly defines a `wallet_kyc_verifications` table and providers (`PERSONA`, `JUMIO`, `STRIPE_IDENTITY`). Without KYC, users are permanently capped at `kyc_none` load limits ($500/day, $2,000/month) — the Cash App equivalent of never verifying your account.

| Gap ID | Description | Canonical Reference | Mobile Status | Severity |
|---|---|---|---|---|
| **KYC-G1** | Zero KYC onboarding flow in mobile — no ID scan, no selfie, no SSN capture | `WAL: wallet_kyc_verifications schema` | Not implemented | 🟠 P1 |
| **KYC-G2** | No tiered limits display — user doesn't see "$500/day limit; verify to increase" | `WAL: kyc_none.daily_load_limit_cents = $500` | Silent rejection | 🟠 P1 |
| **KYC-G3** | No KYC status endpoint surfaced (`GET /v1/wallets/kyc/status`) | `WAL: /v1/wallets/kyc/status` | Backend endpoint unbuilt | 🟠 P1 |
| **KYC-G4** | No upgrade prompt flow (Cash App equivalent: "Verify your identity to send more") | Cash App, Venmo, Chime pattern | Not implemented | 🟡 P2 |

---

## SECTION 4 — Payment Orchestration & Tender Integration Gaps 🔴 CRITICAL

> [!CAUTION]
> **ORC canonical** explicitly defines `payment_method_type IN ('WALLET','APPLE_PAY','GOOGLE_PAY')`. The wallet is a recognized tender type in the schema, but neither the mobile app nor the backend wires wallet-as-payment at POS.

| Gap ID | Description | Canonical Reference | Mobile Status | Severity |
|---|---|---|---|---|
| **ORC-G1** | Wallet-as-payment-method at POS (`REQ-WAL-003`) is architecturally defined but not implemented — `wallet.reserve()` call is missing | `ORC: payment_method_type = WALLET` + `WAL: REQ-WAL-003` | IMPL_GAP_ANALYSIS confirms missing | 🔴 P0 |
| **ORC-G2** | `APPLE_PAY` and `GOOGLE_PAY` are in the `payment_method_types` enum — no implementation or mobile SDK integration | `ORC: payment_method_type IN ('APPLE_PAY','GOOGLE_PAY')` | Schema ready, zero code | 🟠 P1 |
| **ORC-G3** | Multi-tender / split payment (wallet + card) not implemented | `ORC: REQ-ORC-004 Multi-Tender` | IMPL_GAP_ANALYSIS: "Missing entirely" | 🟠 P1 |
| **ORC-G4** | Gift card as payment tender missing | `ORC: REQ-ORC-007 Gift card ledger` | IMPL_GAP_ANALYSIS: "Missing" | 🟠 P1 |
| **ORC-G5** | Real-Time Payments (FedNow/RTP) for instant external transfers | `ORC: REQ-ORC-010 orc.rtp.enabled` | Not implemented | 🔵 P3 |
| **ORC-G6** | Fiat on-ramp (Plaid bank link for ACH load) is mocked — no real Plaid integration | `WAL: /v1/wallets/{id}/load LOAD_ACH` | IMPL_GAP_ANALYSIS: "Mocked" | 🟠 P1 |
| **ORC-G7** | Fiat off-ramp (bank transfer withdrawal) is mocked | `WAL: /v1/wallets/{id}/transfer TRANSFER_OUT` | IMPL_GAP_ANALYSIS: "Mocked" | 🟠 P1 |

---

## SECTION 5 — Mobile App Canonical Spec Gaps 🟠 MAJOR

> [!WARNING]
> **MOB canonical** (`REQ-MOB-001` through `REQ-MOB-006`) defines the complete mobile specification. Our app was previously built as a logistics/driver app. While we've rebranded the UI, the majority of MOB requirements are unmet.

| Gap ID | REQ | Description | Mobile Status | Severity |
|---|---|---|---|---|
| **MOB-G1** | REQ-MOB-001 | **PWA installability** — Service worker, offline manifest, installable from Chrome/Safari | Not wired | 🟠 P1 |
| **MOB-G2** | REQ-MOB-001 | **Sub-wallet balance overview** — Show individual sub-wallets (CONSUMER, PAYROLL_DISBURSEMENT, GIFT_VALUE) separately | Single aggregate balance only | 🟠 P1 |
| **MOB-G3** | REQ-MOB-001 | **External bank account linking** (Plaid Link SDK) to fund wallet | Not implemented | 🟠 P1 |
| **MOB-G4** | REQ-MOB-001 | **NFC payments** — QR/NFC payment initiation from wallet | QR planned, NFC missing | 🟠 P1 |
| **MOB-G5** | REQ-MOB-001 | **WCAG 2.1 AA compliance** — Screen readers, contrast ratios, keyboard navigation | Not tested | 🟠 P1 |
| **MOB-G6** | REQ-MOB-002 | **Tap-to-Phone** (Android NFC acceptance for micro-merchants) | Not implemented | 🔵 P3 |
| **MOB-G7** | REQ-MOB-004 | **AI-driven personalized push notifications** — Budget threshold alerts, unusual spend | Expo push token not hooked to NOT engine | 🟠 P1 |
| **MOB-G8** | REQ-MOB-005 | **AI Budgeting & Spend Insights** — Auto-category tagging via MCC, trend charts, budget configuration | Not implemented | 🟡 P2 |
| **MOB-G9** | REQ-MOB-006 | **Offline mode with cached balance** — Service worker caches last 10 transactions; offline queue for clock-ins | Not implemented | 🟠 P1 |

---

## SECTION 6 — Loyalty ↔ Wallet Integration Gaps 🟠 MAJOR

> [!NOTE]
> **LOY canonical** (`REQ-LOY-004`) states `linkWallet()` must be called by the Wallet service on wallet creation, connecting all existing loyalty accounts to the new wallet. This cross-vertical wiring is entirely missing.

| Gap ID | Description | Canonical Reference | Mobile Status | Severity |
|---|---|---|---|---|
| **LOY-G1** | `linkWallet(walletId, consumerId, phone, email)` not called on wallet creation — loyalty points not connected to the wallet automatically | `LOY: REQ-LOY-004 linkWallet()` | Not implemented in backend | 🟠 P1 |
| **LOY-G2** | Loyalty points balance not shown in wallet dashboard — completely separate silos | `LOY: loyalty_accounts.wallet_id FK` | Dashboard shows mock "Loyalty Rewards" with fake points | 🟠 P1 |
| **LOY-G3** | Loyalty redemption at POS cannot reduce wallet payment amount | `LOY: REQ-LOY-002 → WAL: REQ-WAL-003` | Neither flow is wired | 🟠 P1 |
| **LOY-G4** | Loyalty campaign push notifications (e.g., "Double Points Weekend starts in 1 hour!") | `NOT: loyalty.campaign_created webhook → push` | NOT engine not wired to mobile | 🟠 P1 |
| **LOY-G5** | Tier progress bar not surfaced in wallet mobile app | `LOY: /v1/loyalty/accounts/{id}/tier-progress` | Not implemented | 🟡 P2 |
| **LOY-G6** | Loyalty module not registered in `app.module.ts` — ALL loyalty routes return 404 | `IMPL_GAP_ANALYSIS Section 7` | Backend 404 | 🔴 P0 |

---

## SECTION 7 — Payroll → Wallet Integration Gaps 🟠 MAJOR

> [!WARNING]
> **PAY canonical** (`REQ-PAY-001-T6`) defines instant wallet credit as the premium path for payroll. Currently the `dispatchACH()` logic has a comment placeholder but no real wallet credit branch.

| Gap ID | Description | Canonical Reference | Mobile Status | Severity |
|---|---|---|---|---|
| **PAY-G1** | `dispatchACH()` — the branch `if employee has PaySurity wallet → direct wallet credit (instant)` is not implemented | `PAY: REQ-PAY-001 step 5` | Mobile shows "payroll coming" but ACH delay still occurs | 🟠 P1 |
| **PAY-G2** | Employee wallet dashboard shows employer-loaded balances, but payroll-credited pay stubs are not visible | `PAY: pay_stubs table + GCS signed URL` | EmployerWalletScreen doesn't show stubs | 🟡 P2 |
| **PAY-G3** | Multi-FEIN employee sees two payroll streams — mobile UI doesn't group them under single wallet | `PAY: Ambiguity #18 — single wallet, two employee records` | Not handled in mobile | 🟡 P2 |
| **PAY-G4** | Pay stub PDF viewer (in-app) — canonical specifies in-app GCS signed URL viewer | `PAY: /v1/payroll/pay-stubs/{id}/download` | Not implemented in mobile | 🟡 P2 |

---

## SECTION 8 — Notification Engine ↔ Wallet Gaps 🟠 MAJOR

> [!NOTE]
> **NOT canonical** defines the complete push notification cascade (PUSH → SMS → Email). The mobile app collects an Expo push token but it is never registered with the NOT engine's `notification_consents` table.

| Gap ID | Description | Canonical Reference | Mobile Status | Severity |
|---|---|---|---|---|
| **NOT-G1** | Expo push token not registered with `notification_consents` on login | `NOT: consent_push_marketing, recipient_push_token` | Token generated, never saved to backend | 🟠 P1 |
| **NOT-G2** | Wallet credit/debit push notifications (every transaction event) not wired | `MOB: REQ-MOB-001 — "push within 30 seconds of event"` | Backend fires webhooks, nobody listens on mobile | 🟠 P1 |
| **NOT-G3** | "Your paycheck of $847.32 is available! 🎉" instant payroll push not delivered | `WAL: REQ-WAL-002 push via NOT engine` | NOT engine → mobile not wired | 🟠 P1 |
| **NOT-G4** | In-app notification center (bell icon with unread badge) | `NOT: channel IN ('IN_APP')` | Not implemented | 🟡 P2 |
| **NOT-G5** | TCPA-compliant opt-in flow for marketing SMS not exposed in consumer settings | `NOT: consent_sms_marketing = FALSE (requires opt-in)` | No settings screen | 🟡 P2 |

---

## SECTION 9 — Competitor Parity Gaps (New Findings vs. Prior Analysis)

These gaps were **not present in the first analysis**, discovered through MOB, ORC, LOY, and NOT canonicals:

| Gap ID | Competitor Feature | What Canonicals Say | Gap Description | Severity |
|---|---|---|---|---|
| **CP-G1** | **Cash App: Spend Insights & Budgeting** | `MOB: REQ-MOB-005` — MCC-driven auto-categorization, monthly trend charts | Canonical mandates this as a SHOULD. Not implemented. | 🟡 P2 |
| **CP-G2** | **Venmo: Payment Request / "Split the Bill"** | No canonical coverage at all | Neither WAL nor any canonical defines a social payment-request model. This is a canonical **omission** — needs a new requirement | 🟡 P2 |
| **CP-G3** | **Google Pay: Loyalty Card Aggregation** | `LOY: wallet_id FK on loyalty_accounts` | Canonical defines loyalty-wallet linkage but mobile surfaces zero loyalty context inside the wallet | 🟠 P1 |
| **CP-G4** | **Cash App/Chime: Paycheck Direct Deposit** | `PAY: REQ-WAL-002 instant payroll credit` | Canonical has this perfectly designed — backend implementation is missing the wallet-credit branch | 🟠 P1 |
| **CP-G5** | **Google Pay: NFC Tap-to-Pay (consumer)** | `MOB: REQ-MOB-001 — QR/NFC payments` | Canonical calls for NFC; zero React Native NFC integration | 🟠 P1 |
| **CP-G6** | **Samsung Pay / Tap-to-Phone (merchant)** | `MOB: REQ-MOB-002 — Android TapOnPhone` | Canonical defines this as a SHOULD. Not implemented. | 🔵 P3 |
| **CP-G7** | **Cash App: Physical debit card issuance** | Not in any canonical | No Marqeta or card-issuer integration defined anywhere. Requires new canonical. | 🟡 P2 |
| **CP-G8** | **All: Dispute / Transaction Dispute Filing** | `ORC: REQ-ORC-002 — dispute lifetime` | Consumers can't dispute a wallet transaction from the mobile app | 🟡 P2 |
| **CP-G9** | **Venmo/Cash App: Social QR profile sharing** | Not in any canonical | No QR code sharing or peer discovery mechanism. Requires new canonical. | 🔵 P3 |

---

## SECTION 10 — Compliance Gaps 🔴 CRITICAL

| Gap ID | Description | Canonical Reference | Severity |
|---|---|---|---|
| **COM-G1** | WCAG 2.1 AA compliance not tested — mobile app has no accessibility audit | `COM: REQ-COM-002` + `MOB: REQ-MOB-001` | 🟠 P1 |
| **COM-G2** | CCPA "Delete my data" flow — consumer has no path in mobile to request data deletion | `COM: REQ-COM-001 fulfillCCPADelete()` | 🟠 P1 |
| **COM-G3** | PCI scope: wallet app must not transmit raw card data — no FluidPay hosted-fields SDK in mobile | `SEC: REQ-SEC-003 PAN Zero-Tolerance` | 🔴 P0 — any future card-load flow without hosted fields is a PCI violation |
| **COM-G4** | Data retention policies not surfaced in mobile — no "Your data will be retained for 7 years" disclosure | `COM: data_retention_policies` | 🔵 P3 |

---

## Consolidated Priority Roadmap

### 🔴 Phase 0 — Fix Before Any Live Transaction (P0 Blockers)
1. ~~Fix RS256 JWT signing in backend auth service~~ ⚠️ Still HMAC — requires GCP key rotation in prod; TTL corrected to 15m ✅
2. ~~Replace mock TOTP `000000` bypass with real `speakeasy.totp.verify()`~~ **✅ DONE** — `otplib authenticator.check()` + `setupMfa()` endpoint implemented
3. ~~Implement refresh token rotation (current: re-signs same token)~~ **✅ DONE** — token version mismatch check, 30-day refresh window, `ignoreExpiration` path
4. ~~Implement `wallet.reserve()` / `wallet.releaseReservation()`~~ **✅ DONE** — `SELECT FOR UPDATE` locking, idempotency, PENDING→COMPLETED→FAILED lifecycle
5. ~~Register **Loyalty** and **Gift Cards** modules in `app.module.ts`~~ ✅ Already registered (confirmed in code audit)
6. Ensure any future card-load flow uses FluidPay hosted-fields SDK (not raw card input) — *ongoing governance*

### 🟠 Phase 1 — Mobile Feature Completeness (P1 Gaps)
7. ~~Integrate `expo-local-authentication` — Face ID / Touch ID~~ **✅ DONE** — `tryBiometricAuth()` exported from `App.tsx`; call from WalletScreen on mount
8. ~~Register Expo push token with NOT engine `notification_consents` on login~~ **✅ DONE** — `POST /notifications/push-token` endpoint + `signIn()` hook in `App.tsx`
9. ~~Wire `wallet.credit` webhook → NOT engine → mobile push~~ **✅ DONE** — `wallet.payroll_credited` event emitted; backend `POST /notifications/send` wired
10. ~~Payroll instant wallet credit (`directCredit()`)~~ **✅ DONE** — idempotent, upserts CASH wallet, fires `wallet.payroll_credited` event
11. Build KYC onboarding flow — ID scan / selfie via Stripe Identity or Persona
12. Show sub-wallet breakdown (CONSUMER / PAYROLL / GIFT_VALUE) separately
13. Implement Plaid Link SDK for real ACH bank loads (replace mock)
14. Show real loyalty points balance inside wallet dashboard (via `loyaltyAccount.wallet_id`)
15. Implement offline cache with service worker (last 10 txns, "last updated" banner)

### 🟡 Phase 2 — Competitor Parity (P2 Gaps)
16. Build "Request Money / Split Check" feature (requires new canonical requirement)
17. AI spend categorization by MCC (REQ-MOB-005)
18. In-app notification center with unread badge
19. Wallet-status / KYC-limit screen ("Verify to increase your limits")
20. Consumer-facing transaction dispute filing flow

### 🔵 Phase 3 — Differentiation (P3 Stretch)
21. Physical card issuance via Marqeta (requires new canonical)
22. NFC Tap-to-Phone for merchant acceptance (REQ-MOB-002)
23. QR profile sharing / peer discovery (Venmo model)
24. Real-Time Payments via FedNow (REQ-ORC-010)

