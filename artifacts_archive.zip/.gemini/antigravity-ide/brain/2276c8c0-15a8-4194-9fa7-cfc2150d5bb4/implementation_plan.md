# Module Consolidation Recommendation Matrix

Following the deep read-only audit of `apps/api/src/modules/`, here is the definitive matrix of conflicting module clusters outlining their wired status, V1 production logic presence, and recommended actions.

## 1. admin vs admin-portal
* **Wired into `app.module.ts`**: `admin-portal` is explicitly imported as `AdminPortalModule` (Phase 2).
* **V1 Production Logic**: `admin-portal` contains active role guards and tenant-admin logic. `admin` contains `log-aggregation` and automated test runners which appear disjointed from standard architecture.
* **Recommended Action**: Retain `admin-portal`. Migrate valuable isolated code (like `log-aggregation`) into `admin-portal` or `services/`. Delete the root `admin` folder.

## 2. affiliate vs affiliates
* **Wired into `app.module.ts`**: `affiliates` is explicitly imported as `AffiliatesModule`.
* **V1 Production Logic**: `affiliates` contains the core domain structure and logic.
* **Recommended Action**: Delete the singular `affiliate` directory (likely legacy). Keep `affiliates`. Update any lingering relative imports if needed.

## 3. api-keys vs api-platform vs apikeys
* **Wired into `app.module.ts`**: None are directly instantiated in the root execution context.
* **V1 Production Logic**: Logic is fragmented. `apikeys` lacks proper naming convention.
* **Recommended Action**: Consolidate everything into a single `api-keys` (hyphenated convention) module and wire it exclusively through the active `SecurityModule` or `AuthModule`. Delete the other two.

## 4. audit vs audit-log
* **Wired into `app.module.ts`**: `audit-log` is wired globally as `AuditLogModule`.
* **V1 Production Logic**: `audit-log.service.ts` explicitly injects `DATABASE` and executes core Drizzle ORM tracking queries.
* **Recommended Action**: Delete `audit`. Retain `audit-log` as the canonical source. 

## 5. employee vs employees
* **Wired into `app.module.ts`**: Neither is root-wired; likely decoupled or partially imported within `PayrollModule`.
* **V1 Production Logic**: `employee/clock.service.ts` actively injects `NodePgDatabase`, containing live timesheet/clock logic. `employees` contains overlapping generic domains.
* **Recommended Action**: Consolidate all timesheet/clock logic into the pluralized `employees` module to parallel `merchants`/`users` concepts, or fold them tightly under `PayrollModule` if it is strictly payroll-bound.

## 6. menu vs menu-manager
* **Wired into `app.module.ts`**: Features are typically consumed by `RestaurantModule`. 
* **V1 Production Logic**: `restaurant/menu.service.ts` has the core active logic. `menu-manager` and `menu` act as disjointed bloat.
* **Recommended Action**: Delete standalone `menu` and `menu-manager` folders. Ensure `RestaurantModule` and `KdsModule` strictly handle menu entities.

## 7. merchant vs merchant-onboarding vs merchants
* **Wired into `app.module.ts`**: `merchant` (singular) is explicitly imported as `MerchantModule`.
* **V1 Production Logic**: `merchant/merchant.service.ts` handles active V1 injection and schema interactions.
* **Recommended Action**: Delete `merchants` and `merchant-onboarding`. Migrate any strict onboarding steps directly into `merchant` directory. 

## 8. notification vs notifications
* **Wired into `app.module.ts`**: `notification` is wired explicitly as `NotificationModule` (TCPA gates + templates).
* **V1 Production Logic**: `notification` executes the active delivery log logic.
* **Recommended Action**: Delete the plural `notifications` directory. Adopt singular `notification` globally.

## 9. operations vs ops
* **Wired into `app.module.ts`**: Neither are wired directly in the active build context.
* **V1 Production Logic**: `operations/operations-metrics.service.ts` has disjointed query logic. 
* **Recommended Action**: Merge useful metric aggregators into standard analytics or global event loops. Delete `ops`.

## 10. settlement vs settlement-batch
* **Wired into `app.module.ts`**: `settlement` is fully wired as `SettlementModule`.
* **V1 Production Logic**: Both inject `DATABASE`! `settlement` handles real `NodePgDatabase` interactions. `settlement-batch` contains loosely typed `@Optional` injections and redundant cron jobs.
* **Recommended Action**: Fold batching cron operations directly into `settlement` as standard NestJS `@Cron` tasks within a dedicated `settlement-batch.service.ts`. Delete `settlement-batch` as an independent module.

**Note:** Other minor redundancies noticed include `subscription/subscriptions` and `webhook/webhooks`. They require the exact same deduplication rule (keep the root-wired variant and destroy the floating legacy directory).
