# 🔍 FORENSIC DIAGNOSTIC REPORT
## Target: `http://localhost:4003/DEMO0APRIL12026`
**Classification:** Confidential Internal · Read-Only Audit · Phase 8.1
**Conducted:** 2026-04-07 · Antigravity Forensic Engine

---

## STEP 1 — PORT MAPPING: CONFIRMED

| Port | Application | Package Name | Location |
|:-----|:-----------|:-------------|:---------|
| 4000 | NestJS API | `@paysurity/api` | `apps/api` |
| **4001** | Merchant Dashboard | `@paysurity/merchant-dashboard` | `apps/merchant-dashboard` |
| 4002 | *(unassigned)* | — | — |
| **4003** | **Public Website** | **`@paysurity/public-website`** | **`apps/public-website`** |
| **4004** | Admin Portal | `@paysurity/admin-portal` | `apps/admin-portal` |

**Port 4003 = `apps/public-website`** (Next.js 14, Tailwind 3.x)

---

## STEP 2 — ROUTE LOCATION: CONFIRMED

**Route path:** `apps/public-website/src/app/DEMO0APRIL12026/`

| File | Size | Status |
|:-----|:-----|:-------|
| `page.tsx` | 16,450 bytes | ✅ EXISTS — 333 lines |
| `layout.tsx` | 299 bytes | ✅ EXISTS — transparent passthrough layout (bypasses root navbar) |

The route **exists and is intact**. The layout is a bare Fragment (`<>{children}</>`) — a deliberate design to prevent the public website's nav/header from appearing on the demo hub.

---

## STEP 3 — ASSET AUDIT: FULL LINK INVENTORY

The page defines **15 outbound links** organized across **6 persona categories**.

---

### CATEGORY 1 — PaySurity.com (2 links · Port 4003)

| # | Name | Destination | Route File Exists? | Verdict |
|:--|:-----|:-----------|:-------------------|:--------|
| 1 | PaySurity Public Website | `http://localhost:4003` | `apps/public-website/src/app/page.tsx` (33,559 bytes) | ✅ **INTACT** |
| 2 | Merchant Sign-Up | `http://localhost:4003/apply` | `apps/public-website/src/app/apply/page.tsx` (10,719 bytes) | ✅ **INTACT** |

---

### CATEGORY 2 — Consumer-Facing Storefronts (6 links · Port 4003)

| # | Name | Destination | Route / File Exists? | Verdict |
|:--|:-----|:-----------|:---------------------|:--------|
| 3 | House of Biryani — Storefront | `http://localhost:4003/restaurant/house-of-biryani` | `apps/public-website/src/app/restaurant/house-of-biryani/page.tsx` | ✅ **INTACT** |
| 4 | House of Biryani — Full Menu | `http://localhost:4003/restaurant/house-of-biryani/menu` | `apps/public-website/src/app/restaurant/house-of-biryani/menu/` | ✅ **INTACT** |
| 5 | House of Biryani — Catering | `http://localhost:4003/restaurant/house-of-biryani/catering` | `apps/public-website/src/app/restaurant/house-of-biryani/catering/` | ✅ **INTACT** |
| 6 | Tawakkul Grocers | `http://localhost:4003/microsites/tawakkul.html` | `apps/public-website/public/microsites/tawakkul.html` | ⚠️ **PARTIAL — SEE NOTE A** |
| 7 | Grand Tobacco Hub | `http://localhost:4003/microsites/tobacco.html` | `apps/public-website/public/microsites/tobacco.html` | ❌ **MISSING — SEE NOTE B** |
| 8 | Ashiana Collections | `http://localhost:4003/microsites/ashiana.html` | `apps/public-website/public/microsites/ashiana.html` | ✅ **INTACT** |

> **NOTE A — Tawakkul:** The `public/microsites/` directory contains `tawakkul_banner.png` and `tawakkul_hero.png` image assets, but **no `tawakkul.html` file** was found. The link will 404 at runtime. The interactive POS version exists at `public/microsites/pos/tawakkul.html` (a different path than linked).
>
> **NOTE B — Grand Tobacco:** The file is listed as `tobacco.html` in the demo link, but the actual filename on disk is `grandtobacco.html`. A `tobacco_hero.png` exists but no `tobacco.html`. This link will 404. The correct URL would be `http://localhost:4003/microsites/grandtobacco.html`.

**Full inventory of `public/microsites/` directory:**
```
ashiana.html         ✅  (linked as ashiana.html — MATCHES)
ashiana_banner.png   ✅
ashiana_hero.png     ✅
biryani_banner.png   ✅
biryani_hero.png     ✅
grandtobacco.html    ✅  (linked as tobacco.html — NAME MISMATCH)
grandtobacco_banner.png ✅
onboarding-kit.html  ✅  (not linked from demo hub)
ps-ai.js             ✅  (AI assistant script)
tawakkul_banner.png  ✅
tawakkul_hero.png    ✅
tobacco_hero.png     ✅
pos/ashiana.html     ✅  (sub-directory POS terminals)
pos/biryani.html     ✅
pos/grandtobacco.html ✅
pos/tawakkul.html    ✅  (this is the correct Tawakkul destination)
pos/pos-engine.js    ✅
pos/pos.css          ✅
```

---

### CATEGORY 3 — Consumer Financial App (1 link · Port 8081)

| # | Name | Destination | Status | Verdict |
|:--|:-----|:-----------|:-------|:--------|
| 9 | Digital Wallet App | `http://localhost:8081` | React Native / Expo web — **not a Next.js app**; runs only when `expo start --web` is active | ⚠️ **CONDITIONAL** — App exists at `apps/digital-wallet/` but requires `expo start --web` to serve on 8081. Not a persistent dev server. |

---

### CATEGORY 4 — Tenant-Admin: Merchant Dashboard (9 links · Port 4001)

| # | Name | Destination | Route Exists? | Verdict |
|:--|:-----|:-----------|:--------------|:--------|
| 10 | Merchant Dashboard | `http://localhost:4001/dashboard` | `apps/merchant-dashboard/src/app/dashboard/page.tsx` | ✅ **INTACT** |
| 11 | Menu / Product Management | `http://localhost:4001/dashboard/menu` | `apps/merchant-dashboard/src/app/dashboard/menu/` | ✅ **INTACT** |
| 12 | HoB Microsite Admin | `http://localhost:4001/dashboard/microsite/hob` | `apps/merchant-dashboard/src/app/dashboard/microsite/hob/` | ✅ **INTACT** |
| 13 | Order Management | `http://localhost:4001/dashboard/orders` | `apps/merchant-dashboard/src/app/dashboard/orders/` | ✅ **INTACT** |
| 14 | Employee Management | `http://localhost:4001/dashboard/employees` | `apps/merchant-dashboard/src/app/dashboard/employees/page.tsx` | ✅ **INTACT** — rebuilt in Phase 7.5 |
| 15 | Analytics & Reports | `http://localhost:4001/dashboard/analytics` | `apps/merchant-dashboard/src/app/dashboard/analytics/` | ✅ **INTACT** |
| 16 | Loyalty Program | `http://localhost:4001/dashboard/loyalty` | `apps/merchant-dashboard/src/app/dashboard/loyalty/` | ✅ **INTACT** |
| 17 | Catering Orders | `http://localhost:4001/dashboard/catering` | `apps/merchant-dashboard/src/app/dashboard/catering/` | ✅ **INTACT** |
| 18 | E-Commerce Products *(NEW badge)* | `http://localhost:4001/dashboard/ecom/products` | `apps/merchant-dashboard/src/app/dashboard/ecom/products/` | ✅ **INTACT** |

---

### CATEGORY 5 — Tenant Employee / POS Terminals (3 links · Port 4001)

| # | Name | Destination | Route Exists? | Verdict |
|:--|:-----|:-----------|:--------------|:--------|
| 19 | POS Restaurant — BistroBeast | `http://localhost:4001/pos` | `apps/merchant-dashboard/src/app/pos/` | ✅ **INTACT** |
| 20 | POS Retail — RetailPro | `http://localhost:4001/retail-pos` | `apps/merchant-dashboard/src/app/retail-pos/` | ✅ **INTACT** |
| 21 | Grocery POS | `http://localhost:4001/grocery-pos` | `apps/merchant-dashboard/src/app/grocery-pos/` | ✅ **INTACT** |

---

### CATEGORY 6 — Enterprise Command Center (1 link · Port 4004)

| # | Name | Destination | Route Exists? | Verdict |
|:--|:-----|:-----------|:--------------|:--------|
| 22 | Super Admin God-View | `http://localhost:4004` | `apps/admin-portal/src/app/page.tsx` | ✅ **INTACT** — significantly upgraded in Phase 7.7 |

---

## STEP 4 — SUMMARY VERDICT

### Overall Status

| Category | Links | Intact | Broken | Conditional |
|:---------|:------|:-------|:-------|:------------|
| Public Website (Port 4003) | 2 | 2 | 0 | 0 |
| Consumer Storefronts (Port 4003) | 6 | 4 | **2** | 0 |
| Digital Wallet (Port 8081) | 1 | 0 | 0 | **1** |
| Merchant Dashboard (Port 4001) | 9 | 9 | 0 | 0 |
| POS Terminals (Port 4001) | 3 | 3 | 0 | 0 |
| Admin Portal (Port 4004) | 1 | 1 | 0 | 0 |
| **TOTAL** | **22** | **19** | **2** | **1** |

---

### 🔴 BROKEN LINKS (2) — Require Fix

| # | Link Text | Broken URL | Root Cause | Correct URL |
|:--|:----------|:-----------|:-----------|:------------|
| B1 | Grand Tobacco Hub | `/microsites/tobacco.html` | File is named `grandtobacco.html` on disk — name mismatch | `/microsites/grandtobacco.html` |
| B2 | Tawakkul Grocers | `/microsites/tawakkul.html` | No `tawakkul.html` in `public/microsites/` — only in `/pos/` sub-dir | `/microsites/pos/tawakkul.html` |

### ⚠️ CONDITIONAL LINK (1)

| # | Link Text | URL | Condition |
|:--|:----------|:----|:----------|
| C1 | Digital Wallet App | `http://localhost:8081` | Requires `expo start --web` to be running in `apps/digital-wallet/`. Not a persistent server. Only works during active Expo web session. |

### ✅ UNAFFECTED BY PHASE 7.x SPRINTS

All 9 Merchant Dashboard route links and all 3 POS terminal links are untouched. The Phase 7.5–7.7 sprints only **added** new routes (`gift-cards`, `kds`, `settlements`, `payroll`, admin portal pages); they did not overwrite or delete any pre-existing routes.

---

## STEP 5 — QUICK-START CTAs (Header Callouts)

The demo hub has 3 additional hardcoded quick-start links in the page header (outside the JOURNEYS array):

| CTA | URL | Status |
|:----|:----|:-------|
| ▶ Start here: House of Biryani → Full Menu | `http://localhost:4003/restaurant/house-of-biryani/menu` | ✅ **INTACT** |
| 🍽️ POS Restaurant Demo → | `http://localhost:4001/pos` | ✅ **INTACT** |
| 🏪 POS Retail Demo → | `http://localhost:4001/retail-pos` | ✅ **INTACT** |
| 🛍️ E-Commerce Demo → | `http://localhost:4001/dashboard/ecom/products` | ✅ **INTACT** |

---

*End of Forensic Report — Phase 8.1 · No files were modified during this investigation.*
