# Admin Portal Hardening & Premium Design Refresh

The PaySurity Admin Portal (God Mode) currently lacks the premium aesthetic found on the public website. This plan addresses the "unstyled" state by implementing a high-fidelity command center UI.

## Phase 1: Foundation & Layout
- [ ] **Standardize CSS Variables:** Update `globals.css` to ensure all custom properties are synchronized with the `tailwind.config.js`.
- [ ] **Global Grid Pattern:** Add a subtle radial-gradient grid pattern to the background (similar to the homepage) to add depth.
- [ ] **Sidebar Refinement:** Add active state indicators (red glow) and hover effects to navigation items.
- [ ] **Scanline Overlay:** Refine the `scanlines` overlay to be more subtle and interactive.

## Phase 2: Component Hardening
- [ ] **Metric Cards:**
    - Add background glow based on the metric type (success/warning/error).
    - Use glassmorphism (`backdrop-blur-xl`) for the cards.
    - Implement a "flicker-in" animation on mount to simulate a high-tech terminal boot.
- [ ] **Audit Feed (Event Rows):**
    - Improve spacing and typography.
    - Add "Trace Link" indicators for troubleshooting.
    - Ensure PQC signatures are visually distinct and selectable.
- [ ] **Tabs & Filters:**
    - Design a more premium tab switcher with a sliding underline indicator.
    - Standardize input fields (Search, Filter) with the 'God Mode' aesthetic (monospace, thin borders, red focus).

## Phase 3: Interactive Polish
- [ ] **Real-time Heartbeat:** Add a more visual representation of system health (e.g., a tiny EKG-style sparkline).
- [ ] **Underwriting Registry:** Modernize the list view with better status badges and "hover-to-reveal" actions.

## Phase 4: Verification
- [ ] Run `pnpm dev` and verify via browser subagent.
- [ ] Verify responsive behavior (Admin portal is primarily desktop-first but should be usable on tablets).
