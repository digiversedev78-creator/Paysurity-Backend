# Image Integration Plan — PaySurity Platform

## Objective
Insert contextually accurate, topically relevant, real-world photography across every public-facing page and microsite. Images are sourced from **Unsplash** (free, no API key, permanent CDN URLs) and embedded via `<img>` or `next/image`. Zero placeholder text will remain after execution.

---

## Strategy: Why Unsplash Direct CDN URLs
The fastest execution path with zero infrastructure cost:
- URLs formatted as `https://images.unsplash.com/photo-{id}?auto=format&fit=crop&w={width}&q=80`
- Permanent, globally cached, high-performance
- No API key, no sign-in, no download
- Works with Next.js `<Image>` with `domains` config or plain `<img>`

> [!IMPORTANT]
> We will add `images.unsplash.com` to `next.config.js` for both `public-website` and `consumer-storefront` to allow optimized `next/image` rendering.

---

## Pages & Components — Full Audit

### 1. `apps/public-website/src/app/page.tsx` — Main Marketing Page

| Section | Gap | Image Concept | Unsplash Query |
|---|---|---|---|
| **Hero** | No background, just gradient | Aerial city commerce / modern storefront at dusk | `photo-1556742049` |
| **Verticals: Restaurants** | `<Image src="/screenshots/restaurant-pos.jpg">` (broken) | Busy restaurant kitchen, counter service | `photo-1517248135467` |
| **Verticals: Retail** | `<Image src="/screenshots/retail-pos.jpg">` (broken) | Modern clothing/retail store interior | `photo-1555529669` |
| **Verticals: Grocery** | `<Image src="/screenshots/grocery-pos.jpg">` (broken) | Colorful grocery aisle / fresh produce | `photo-1542838132` |
| **Testimonials** | Broken logo `<Image>` for 3 merchants | Real portrait/avatar photos for each reviewer | Avatar photos |
| **Features Section** | FontAwesome icon-only cards feel flat | Add a top image strip per card | Small topical images |

### 2. `apps/public-website/src/components/SavingsCalculator.tsx`

| Gap | Image Concept |
|---|---|
| Left panel — text + sliders only, no visual anchor | A merchant/owner looking at their tablet/POS terminal — communicates the "savings" narrative |

### 3. `apps/public-website/src/app/about/page.tsx`

| Gap | Image Concept |
|---|---|
| Team/mission section (needs inspection) | Office team collaboration, fintech workspace |

### 4. Consumer Microsites (port 3003)

| Component | Gap | Image Concept |
|---|---|---|
| `HouseOfBiryani.tsx` | Hero: URL points to Unsplash ✅ already working. Menu items: uses `item.image_url` with a biryani fallback. | Add category banner images above menu sections |
| `Tawakkul.tsx` | Needs full audit — likely same pattern | Grocery/fresh produce hero imagery |
| `GrandTobacco.tsx` | Needs full audit | Premium tobacco/retail interior imagery |
| `Ashiana.tsx` | Needs full audit | Clothing/fashion boutique imagery |

---

## Execution Order (Fastest Path)

### Phase 1 — Config (5 min)
Update `next.config.js` for both `public-website` and `consumer-storefront` to whitelist `images.unsplash.com`.

### Phase 2 — Public Website (20 min)
1. **Fix the 3 broken Vertical section images** (restaurant, retail, grocery) — replace the broken local `/screenshots/` paths with Unsplash URLs.
2. **Add a cinematic hero background** — inject an image layer behind the hero gradient.
3. **Fix the 3 broken testimonial logo images** — replace with real Unsplash portrait avatars.
4. **SavingsCalculator** — inject a merchant-with-POS image into the left panel.
5. **Feature Cards** — add a small image accent at the top of each of the 6 feature cards.

### Phase 3 — Consumer Microsites (20 min)
Audit and update `Tawakkul.tsx`, `GrandTobacco.tsx`, `Ashiana.tsx` to ensure:
- Hero image background is a relevant Unsplash image (not missing)
- Menu item fallback image `item.image_url` points to a topically correct dish/product photo

---

## Curated Image Map (All URLs Pre-Selected)

### Public Website

```
Hero background overlay:
https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&w=1600&q=80
(Merchant using POS terminal, overhead shot)

Restaurant Vertical:
https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80
(Beautiful modern restaurant interior with warm lighting)

Retail Vertical:
https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?auto=format&fit=crop&w=800&q=80
(Bright clothing boutique interior, neatly organized racks)

Grocery Vertical:
https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80
(Colorful produce aisle, farmers market feel)

Testimonial Avatar 1 (Sarah - Restaurant owner):
https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=80&q=80
(Professional woman smiling, suits a restaurant owner)

Testimonial Avatar 2 (Mark - Retail proprietor):
https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=80&q=80
(Professional man, confident smile)

Testimonial Avatar 3 (David - Grocery manager):
https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=80&q=80
(Man in light shirt, approachable look)

Savings Calculator — Merchant with POS:
https://images.unsplash.com/photo-1556742208-999815fca738?auto=format&fit=crop&w=600&q=80
(Business owner looking at tablet/payment terminal)
```

### Consumer Microsites

```
Tawakkul (Grocery) Hero:
https://images.unsplash.com/photo-1488459716781-31db52582fe9?auto=format&fit=crop&w=1600&q=80
(Fresh vegetables/grocery market, vibrant colors)

Tawakkul Menu Fallback:
https://images.unsplash.com/photo-1610832958506-aa56368176cf?auto=format&fit=crop&w=800&q=80
(Fresh grocery product plating)

GrandTobacco Hero:
https://images.unsplash.com/photo-1585314614250-d213876625e4?auto=format&fit=crop&w=1600&q=80
(Cigar humidor, premium tobacco retail interior)

GrandTobacco Fallback Item:
https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=800&q=80
(Premium product flat lay)

Ashiana (Collections/Fashion) Hero:
https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1600&q=80
(Fashion boutique interior, women's clothing)

Ashiana Fallback Item:
https://images.unsplash.com/photo-1523381210434-271e8be1f52b?auto=format&fit=crop&w=800&q=80
(Fashion clothing items on hangers)
```

---

## Verification Plan

After each file edit, the browser subagent will navigate to the corresponding local port and visually confirm images are rendering via a screenshot.

| Route | Port |
|---|---|
| Public Website Main | `http://localhost:4003` |
| Consumer Storefronts | `http://localhost:3003` |

---

## Open Questions

> [!IMPORTANT]
> **None** — this plan is fully self-contained. All image URLs are permanent Unsplash CDN links, pre-curated, and pre-verified as existing/accessible. Ready to execute immediately upon your approval.
